"""One diagnostic trial: original USB criteria, metadata-only xHCI tracing from actual boot."""
import hashlib,inspect,json,pathlib,runpy,subprocess,sys,textwrap
ROOT=pathlib.Path('/home/ubuntu/github/usbip-client');sys.path.insert(0,str(ROOT/'scripts/qemu_arm64'))
import arm_vm
output=pathlib.Path(sys.argv[sys.argv.index('--output')+1]).resolve()
known=json.loads(pathlib.Path('/tmp/rustusb-arm64-local-hid-xhci-20261026/xhci-events.json').read_text())
names=[r['name'] for r in known if r['name'].startswith(('usb_xhci_ep_','usb_xhci_xfer_','usb_xhci_slot_','usb_xhci_port_')) or r['name'] in ['usb_xhci_queue_event','usb_xhci_reset','usb_xhci_run','usb_xhci_stop']]
assert names and all('fetch_trb' not in n for n in names)
events=output.with_name(output.name+'.boottrace-events.txt');events.write_text('\n'.join(names)+'\n')
source=textwrap.dedent(inspect.getsource(arm_vm.ArmVm.boot));anchor="    (self.out/'qemu-command.json').write_text"
assert source.count(anchor)==1
added="    if self.usb:args+=['-trace','events="+str(events)+",file='+str(self.out/'boot-xhci-trace.log')]\n"
generated=source.replace(anchor,added+anchor,1);compile(generated,'ARM boot with metadata trace','exec')
namespace=dict(vars(arm_vm));exec(compile(generated,'ARM boot with metadata trace','exec'),namespace);arm_vm.ArmVm.boot=namespace['boot']
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
paths=[pathlib.Path(__file__),events,ROOT/'scripts/qemu_arm64/arm_vm.py',ROOT/'scripts/qemu_arm64/usb.py'];frozen={str(p):sha(p) for p in paths};head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT).strip()
output.with_name(output.name+'.boottrace.generated.py').write_text(generated)
output.with_name(output.name+'.boottrace-composition.json').write_text(json.dumps({'scope':'Diagnostic-only QEMU metadata tracing from boot; no original runner/guest/acceptance/timeout change','head':head,'original_boot_sha256':hashlib.sha256(source.encode()).hexdigest(),'generated_boot_sha256':hashlib.sha256(generated.encode()).hexdigest(),'frozen':frozen,'events':names},indent=2)+'\n')
try:runpy.run_path(str(ROOT/'scripts/qemu_arm64/usb.py'),run_name='__main__')
finally:
 guards={'method_events_original_source':all(sha(p)==h for p,h in frozen.items()),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==head,'clean':not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT).strip()}
 if output.exists():
  inherited=output/'arm-verdict.json';body=json.loads(inherited.read_text()) if inherited.exists() else None
  (output/'boot-trace-verdict.json').write_text(json.dumps({'diagnostic':True,'guards':guards,'inherited_arm_verdict_sha256':sha(inherited) if body else None,'passed':bool(body and body['passed']) and all(guards.values()),'original_verdict_not_rewritten':True},indent=2)+'\n')
 assert all(guards.values())

import hashlib,importlib.util,json,pathlib,re,shutil,subprocess,urllib.parse
R=pathlib.Path('/home/ubuntu/github/usbip-client');O=pathlib.Path('/tmp/rustusb-import-power-docs-20261026');sha=lambda b:hashlib.sha256(b).hexdigest()
names=subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines()+['docs/research/native-import-power-validation.md'];names=sorted(set(names));snapshot={}
for n in names:
 p=R/n;q=O/'sources'/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);snapshot[n]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
spec=importlib.util.spec_from_file_location('sitecheck',R/'scripts/check-site.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);checks=0;errors=[]
for n in names:
 p=R/n
 if p.suffix!='.md':continue
 for target in re.findall(r'\]\(([^)\s]+)\)',p.read_text()):
  u=urllib.parse.urlsplit(target)
  if u.scheme or u.netloc:continue
  q=(p.parent/urllib.parse.unquote(u.path)).resolve() if u.path else p
  checks+=1
  if not q.is_relative_to(R) or not q.exists():errors.append((n,target,'missing'));continue
  if u.fragment and q.suffix=='.md' and u.fragment not in m.markdown_ids(q):errors.append((n,target,'anchor'))
assert not errors,errors
commands=[]
for label,argv in [('site',['python3','scripts/check-site.py']),('node',['node','--check','website/app.js']),('diff',['git','diff','--check'])]:
 with (O/(label+'.log')).open('wb') as f:p=subprocess.run(argv,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 commands.append({'name':label,'argv':argv,'actual_exit':p.returncode});assert p.returncode==0
software=json.loads(pathlib.Path('/tmp/rustusb-native-import-power-software-20261026/summary.json').read_text());unchanged=[];changed=[]
for n,s in software['inputs'].items():
 b=(R/n).read_bytes();(unchanged if sha(b)==s['sha256'] and len(b)==s['bytes'] else changed).append(n)
assert set(changed).issubset(set(names)),changed
elfs={}
for n,s in software['binaries'].items():
 b=(R/n).read_bytes();assert sha(b)==s['sha256'] and len(b)==s['bytes'];elfs[n]=s
base=json.loads((R/'docs/evidence/tui-interactions-docs-20261025/summary.json').read_text())['global_skill_unchanged'];skill=pathlib.Path('/home/ubuntu/.agents/skills/readme-site')
for n,s in base.items():
 b=(skill/n).read_bytes();assert len(b)==s['bytes'] and sha(b)==s['sha256']
assert pathlib.Path('/home/ubuntu/.codex/skills/readme-site').resolve()==skill
site=[]
for p in sorted((R/'website').rglob('*')):
 if not p.is_file():continue
 n=str(p.relative_to(R/'website'));assert (O/'preview/usbip-client'/n).read_bytes()==p.read_bytes();site.append({'path':n,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
assert (R/'docs/research/native-import-power-design.md').read_text().startswith('---\nstatus: proposed\n')
for n,s in snapshot.items():assert sha((R/n).read_bytes())==s['sha256']
stop=json.loads((O/'preview-stop.json').read_text());stop['actual_owner_exit']=130;stop['expected_interrupt']=True;(O/'preview-stop.json').write_text(json.dumps(stop,indent=2)+'\n')
result={'result':'PASS','documentation_sources':snapshot,'local_documentation_targets':checks,'commands':commands,'same_software_inputs':len(unchanged),'changed_inputs_are_documentation_only':changed,'three_host_elfs_unchanged':elfs,'site_sources':site,'global_skill_unchanged':base,'global_skill_codex_symlink':str(skill),'scope':'Local text/link/integrity checks; browser observations separately recorded. No new Rust/USB/hardware execution.'};(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'result':'PASS','sources':len(snapshot),'local_targets':checks,'unchanged_inputs':len(unchanged),'documentation_only_changes':len(changed),'site_files':len(site),'skill_files':len(base)}))

import functools,http.server,pathlib,shutil
R=pathlib.Path('/home/ubuntu/github/usbip-client');O=pathlib.Path('/tmp/rustusb-import-power-docs-20261026/preview');O.mkdir();shutil.copytree(R/'website',O/'usbip-client');(O/'nojs').mkdir();(O/'nojs/usbip-client').symlink_to('../usbip-client',target_is_directory=True)
class Handler(http.server.SimpleHTTPRequestHandler):
 def end_headers(self):
  if self.path.startswith('/nojs/'):self.send_header('Content-Security-Policy',"script-src 'none'")
  super().end_headers()
http.server.ThreadingHTTPServer(('127.0.0.1',8879),functools.partial(Handler,directory=str(O))).serve_forever()

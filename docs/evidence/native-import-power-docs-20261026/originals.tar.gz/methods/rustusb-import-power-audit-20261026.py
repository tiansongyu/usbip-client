"""Read-only exact-byte audit independent of the collector implementation."""
import hashlib,io,json,pathlib,subprocess,tarfile
R=pathlib.Path('/home/ubuntu/github/usbip-client');D=R/'docs/evidence/native-import-power-20261026';O=pathlib.Path('/tmp/rustusb-import-power-docs-20261026');O.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();rows=json.loads((D/'originals-manifest.json').read_text())['files'];body=json.loads((D/'summary.json').read_text());raw=(D/'originals.tar.gz').read_bytes();assert sha(raw)==body['archive']['sha256'];count=0;source=[];rounds=0;proofs=0
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
 assert archive.getnames()==[r['path'] for r in rows]
 for r in rows:
  b=archive.extractfile(r['path']).read();assert len(b)==r['bytes'] and sha(b)==r['sha256'];assert r['path'].startswith('executed-source/') or not any(x.startswith('.') for x in pathlib.PurePosixPath(r['path']).parts);count+=1
  if r['path'].startswith('executed-source/'):
   source.append((r['path'].removeprefix('executed-source/'),b));continue
  if r['path']=='methods/rustusb-import-power-collection-20261026.log':
   assert b==b''
   assert pathlib.Path(r['original']).read_text()==json.dumps({k:body[k] for k in ['archive','privacy']})+'\n'
  else:assert pathlib.Path(r['original']).read_bytes()==b,r['path']
  if r['path'].startswith('installed/') and '/client-probe-' in r['path']:
   j=json.loads(b);c=j['cycle'];assert j['rx_bytes']==j['tx_bytes']==35;assert [1,c+1,1] in j['events'] and [1,c+1,0] in j['events'];rounds+=1
 for case in body['installed_cases']:
  if case['summary']['passed']:proofs+=case['summary']['client_root_proofs']+case['summary']['server_root_proofs']
args=''.join(body['executed_head']+':'+n+'\n' for n,b in source).encode();data=subprocess.check_output(['git','cat-file','--batch'],cwd=R,input=args);stream=io.BytesIO(data)
for n,b in source:
 header=stream.readline().split();assert header[1]==b'blob';assert stream.read(int(header[2]))==b,n;assert stream.read(1)==b'\n'
assert stream.read()==b'';assert len(source)==738 and rounds==24 and proofs==104
for r in json.loads((D/'manifest.json').read_text())['files']:
 b=(D/r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
result={'result':'PASS','members':count,'original_tmp_bytes_verified':count-len(source)-1,'collector_late_stdout_captured_empty':1,'executed_source_blobs_verified':len(source),'exact_installed_rounds':rounds,'root_summary_proofs':proofs,'scope':'Same-author raw integrity/selected I/O cross-check, not independent security audit or new USB execution','archive_sha256':sha(raw)};(O/'raw-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

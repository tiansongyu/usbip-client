"""Read-only exact-source HTTP publication checks; Pages marker is not an asset."""
from pathlib import Path
import datetime,hashlib,json,subprocess,urllib.request
ROOT=Path('/home/ubuntu/github/usbip-client')
OUT=Path('/tmp/rustusb-arm64-publication-96a93c38-20261026')
HEAD='96a93c38172c9646cae688524b276ee7f3ba1bdb'
checks=[]
def check(url,source):
 expected=subprocess.check_output(['git','show',HEAD+':'+source],cwd=ROOT)
 req=urllib.request.Request(url,headers={'User-Agent':'RustUSB-publication-verification','Cache-Control':'no-cache'})
 with urllib.request.urlopen(req,timeout=30) as r:
  b=r.read();status=r.status;final_url=r.url
 assert status==200 and b==expected,(url,status)
 checks.append({'url':url,'source':source,'status':status,'final_url':final_url,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'exact_pinned_source':True})
for source in subprocess.check_output(['git','ls-tree','-r','--name-only',HEAD,'website'],cwd=ROOT,text=True).splitlines():
 relative=source.removeprefix('website/')
 if relative=='.nojekyll':continue
 check('https://tiansongyu.github.io/usbip-client/'+('' if relative=='index.html' else relative),source)
for source in ['README.md','docs/research/arm64-installed-validation.md','docs/debian-installation.md']:
 check('https://raw.githubusercontent.com/tiansongyu/usbip-client/'+HEAD+'/'+source,source)
(OUT/'http.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':HEAD,'checks':checks,'all_exact':True,'scope':'Seven deployed runtime assets and three pinned GitHub source documents; no hidden .nojekyll HTTP assertion.'},indent=2)+'\n')
print(json.dumps({'source_head':HEAD,'exact_HTTP200_checks':len(checks)}))

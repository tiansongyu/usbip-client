# Same-source ARM64 upgrade packages

The E61 design permits an audited repack rather than relabeling binaries or
retaining a misleading old build receipt. Use each matching Ubuntu CI package
pair as the first installation. Derive a strictly higher Debian revision by
changing only control Version and the GUI's exact base-version Depends. Preserve
all original payload bytes, modes, ownership, links, maintainer scripts and other
control files. Independently compare every original/derived data/control tar
member and record original CI/ZIP/build/package/binary identities and new hashes.
The new receipt explicitly says repacked, not rebuilt, and cannot replace the
original CI receipt. Test old/new package lifecycle of the same source; do not
claim a protocol or code migration. The host can archive an actual ARM ELF without
executing it; aarch64 execution must still happen inside the real ARM guest.

This is independent input preparation in /tmp while existing ARM OS preparation
owners retain frozen repository source. Integrate the method and update the
tracked design only after every original live preparation owner is terminal.

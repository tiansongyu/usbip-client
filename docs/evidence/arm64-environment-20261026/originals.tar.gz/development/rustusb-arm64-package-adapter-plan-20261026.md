# ARM64 cold installation adapter

Keep original qemu_package guest assertions and their existing ordinary-user GUI,
cooperative fsync upgrade, reboot, remove/purge and preservation checks. Compose
exact original host source anchors rather than change original amd64 method.
Launch virt-6.2/cortex-a72/TCG with private persistent firmware variables and
explicit ARM identity checks. Compile the original fsync-gate.c using actual ARM
guest GCC before product installation; record AArch64 header/source/library hash.
Do not load an amd64 interposer into an ARM process or change its C source.

The ARM host wrapper waits for actual SSH/QEMU completion, reporting observation
intervals rather than treating an interval as termination or killing a still-live
cleanup solely for that reason. These are host observation-policy adaptations,
not a claim of byte-identical original runner code. Guest product assertions,
GUI budgets and gate predicates stay unchanged. Preserve all actual failures.
If the original guest GUI budget fails under TCG, investigate/report it; do not
silently relax a timing assertion into a passing result.

Use each original signed-checksum ARM image for the cold case. Native CI0316
original packages are first; independently audited control-only same-source
derived revisions are second. Product-free prepared disks are only for later
USB data cases and do not substitute for cold-install evidence.

Prototype work may be prepared in /tmp while existing preparation owners run;
tracked design/method integration and commit happen only after all original
preparation owners reach terminal state, preserving their clean-source guards.

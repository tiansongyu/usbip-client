"""Verify original signed checksums before downloading actual ARM64 disks."""
from pathlib import Path
import concurrent.futures,hashlib,json,shutil,subprocess,urllib.request
OUT=Path('/tmp/rustusb-arm64-images-20261026');OUT.mkdir()
def one(release,version,date):
 out=OUT/release;out.mkdir();base='https://cloud-images.ubuntu.com/releases/'+release+'/release-'+date+'/'
 name='ubuntu-'+version+'-server-cloudimg-arm64.img'
 for f in ['SHA256SUMS','SHA256SUMS.gpg']:shutil.copyfile(Path('/tmp/rustusb-package-images-20261025')/release/f,out/f)
 with (out/'gpgv.log').open('wb') as log:subprocess.run(['gpgv','--keyring','/usr/share/keyrings/ubuntu-cloudimage-keyring.gpg',str(out/'SHA256SUMS.gpg'),str(out/'SHA256SUMS')],stdout=log,stderr=subprocess.STDOUT,check=True)
 lines=[l.split() for l in (out/'SHA256SUMS').read_text().splitlines() if l.split()[-1].lstrip('*')==name];assert len(lines)==1;expected=lines[0][0]
 h=hashlib.sha256();size=0;partial=out/(name+'.part')
 with urllib.request.urlopen(base+name,timeout=60) as response,partial.open('xb') as f:
  assert response.status==200
  while b:=response.read(1024*1024):f.write(b);h.update(b);size+=len(b)
 assert h.hexdigest()==expected
 partial.rename(out/name)
 receipt={'release':release,'architecture':'arm64','date':date,'url':base+name,'filename':name,'sha256':expected,'bytes':size,'signature_verified':True,'signed_checksum_source':'Exact previously acquired dated official signed files, independently reverified for ARM64 entry'}
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
 return receipt
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda x:one(*x),[('jammy','22.04','20261020'),('noble','24.04','20261017')]))
(OUT/'summary.json').write_text(json.dumps(results,indent=2)+'\n')

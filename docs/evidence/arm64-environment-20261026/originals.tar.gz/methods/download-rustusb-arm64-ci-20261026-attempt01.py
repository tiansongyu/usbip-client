"""Download fixed public CI artifacts without emitting temporary capabilities."""
from pathlib import Path
import concurrent.futures,hashlib,json,urllib.request,zipfile
ROOT=Path('/home/ubuntu/github/usbip-client');OUT=Path('/tmp/rustusb-arm64-ci-artifacts-20261026')
metadata=json.loads((ROOT/'docs/evidence/framed-close-publication-0316de76-20261026/receipt.json').read_text())['artifact_metadata_only']['artifacts']
def one(release):
 data=json.loads((OUT/'.private'/ (release+'-download.json')).read_text())['structuredContent'];row=next(r for r in metadata if r['id']==data['artifact_id'])
 out=OUT/release;out.mkdir();p=out/'artifact.zip';uri=data['file_uri'];local=Path(uri)
 if local.is_file():b=local.read_bytes()
 else:
  url=data['structuredContent']['download_url']
  with urllib.request.urlopen(url,timeout=60) as response:b=response.read()
 digest=hashlib.sha256(b).hexdigest();assert row['digest']=='sha256:'+digest and len(b)==row['size_in_bytes'];p.write_bytes(b)
 with zipfile.ZipFile(p) as archive:
  files=archive.namelist();assert len(files)==3 and all(Path(n).name==n and (n.endswith('.deb') or n.startswith('build-')) for n in files)
  for name in files:(out/name).write_bytes(archive.read(name))
 receipt={'release':release,'content_head':'0316de7638c68b9360ec719194e9e0c4ae0fe454','artifact_id':row['id'],'artifact_name':row['name'],'zip_sha256':digest,'zip_bytes':len(b),'api_digest_verified':True,'members':[{'path':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in sorted(out.iterdir()) if f.name!='artifact.zip']}
 (out/'download-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'release':release,'artifact_id':row['id'],'zip_bytes':len(b),'sha256':digest,'api_digest_verified':True}),flush=True)
 return receipt
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(one,['jammy','noble']))
(OUT/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import hashlib,json
r=Path('/tmp/rustusb-storage-arrival-linux-20261026');m=json.loads((r/'manifest.json').read_text());p=Path('/tmp/rustusb-storage-linux-20261026');a=json.loads((p/'manifest.json').read_text())['sources'];q=Path('/tmp/rustusb-storage-usb-20261026');b=json.loads((q/'sources.json').read_text());new=[];missing=[]
for x in m['sources']:
 if 'error' not in x:continue
 v,path=x['version'],x['path'];c=next((s for s in a if s.get('tag')==v and s.get('path')==path and 'sha256' in s),None)
 if c:f=p/'sources'/v/path;url=c['url'];sha=c['sha256']
 else:
  c=next((s for s in b if s.get('path')==f'linux-{v}/{path}' and s.get('status')=='ok'),None)
  if c:f=q/c['path'];url=c['url'];sha=c['sha256']
  else:missing.append((v,path));continue
 raw=f.read_bytes();assert hashlib.sha256(raw).hexdigest()==sha;t=r/'sources'/v/path;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(raw)
 new.append(dict(version=v,commit=x['commit'],path=path,url=url,commit_url=x['url'],sha256=sha,bytes=len(raw),reused_from=str(f),license=next((l.strip() for l in raw.decode(errors='replace').splitlines()[:35] if 'SPDX-License-Identifier:' in l),'See original file notices and kernel COPYING')))
m['sources']+=new;(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print({'reused':len(new),'still_missing':missing})

from pathlib import Path
import urllib.request,hashlib,json,base64,concurrent.futures
r=Path('/tmp/rustusb-storage-arrival-linux-20261026');m=json.loads((r/'manifest.json').read_text());revs=json.loads((r/'revisions.json').read_text());tasks=[]
for x in m['sources']:
 if 'error' in x and not (r/'sources'/x['version']/x['path']).exists():tasks.append((x['version'],x['path']))
tasks += [(v,p) for v in revs for p in ['drivers/usb/core/urb.c','drivers/usb/core/config.c']]
def get(t):
 v,p=t;c=revs[v];u=f'https://kernel.googlesource.com/pub/scm/linux/kernel/git/torvalds/linux/+/{c}/{p}?format=TEXT'
 try:
  encoded=urllib.request.urlopen(u,timeout=45).read();b=base64.b64decode(encoded,validate=True);f=r/'sources'/v/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
  return dict(version=v,commit=c,path=p,url=u,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),license=next((l.strip() for l in b.decode(errors='replace').splitlines()[:35] if 'SPDX-License-Identifier:' in l),'See original file notices and kernel COPYING'))
 except Exception as e:return dict(version=v,commit=c,path=p,url=u,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:new=list(pool.map(get,tasks))
m['sources']+=new;(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print({'fetched':sum('sha256' in x for x in new),'errors':[{'version':x['version'],'path':x['path'],'error':x['error']} for x in new if 'error' in x]})

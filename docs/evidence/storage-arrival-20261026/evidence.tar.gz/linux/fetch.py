from pathlib import Path
import urllib.request,hashlib,json,concurrent.futures,datetime
r=Path('/tmp/rustusb-storage-arrival-linux-20261026');revs={'v5.15':'8bb7eca972ad531c9b149c0a51ab43a417385813','v6.8':'e8f897f4afef0031fe618a8e94127a0934896aba'}
paths=['COPYING','LICENSES/preferred/GPL-2.0','LICENSES/exceptions/Linux-syscall-note','Documentation/process/license-rules.rst','Documentation/usb/authorization.rst','Documentation/ABI/testing/sysfs-bus-usb','Documentation/admin-guide/kernel-parameters.txt','drivers/usb/core/sysfs.c','drivers/usb/core/driver.c','drivers/usb/core/generic.c','drivers/usb/core/hub.c','drivers/usb/core/message.c','drivers/usb/core/devio.c','drivers/usb/core/usb.c','drivers/usb/core/hcd.c','drivers/usb/core/usb.h','include/linux/usb.h','include/linux/usb/hcd.h','include/uapi/linux/usbdevice_fs.h','drivers/usb/usbip/stub_dev.c','drivers/usb/usbip/stub_rx.c','drivers/usb/usbip/stub_main.c','drivers/usb/usbip/stub.h','tools/usb/usbip/libsrc/usbip_host_driver.c','tools/usb/usbip/src/usbip_bind.c','tools/usb/usbip/src/usbip_unbind.c']
def get(t):
 v,p=t;u=f'https://raw.githubusercontent.com/torvalds/linux/{revs[v]}/{p}'
 try:
  raw=urllib.request.urlopen(u,timeout=40).read();f=r/'sources'/v/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw)
  return dict(version=v,commit=revs[v],path=p,url=u,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),license=next((l.strip() for l in raw.decode(errors='replace').splitlines()[:35] if 'SPDX-License-Identifier:' in l),'See original file notices and kernel COPYING'))
 except Exception as e:return dict(version=v,commit=revs[v],path=p,url=u,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:results=list(pool.map(get,[(v,p) for v in revs for p in paths]))
(r/'manifest.json').write_text(json.dumps({'date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':results},indent=2)+'\n');(r/'revisions.json').write_text(json.dumps(revs,indent=2)+'\n')
print({'files':sum('sha256' in x for x in results),'failures':[x for x in results if 'error' in x]})

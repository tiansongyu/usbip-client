import hashlib,json,re,subprocess,tarfile
from pathlib import Path
ROOT=Path('/home/ubuntu/github/usbip-client');TMP=Path('/tmp')
OUT=TMP/'rustusb-storage-arrival-audit-20261026';OUT.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
RUNS=['jammy','jammy-fixed','noble','jammy-flush','noble-flush','jammy-flush-lun0','noble-flush-lun0','jammy-normal-final','noble-normal-final']
proof={'scope':'same-author read-only audit of original results, Git inputs and offline synthetic files; no new USB run or independent security audit','runs':[],'research':{},'source_checks':{}}
cache={}
def check_source(head,inputs):
 if head in cache:assert cache[head]==inputs;return
 process=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 for name,expected in inputs.items():
  process.stdin.write((head+':'+name+'\n').encode());process.stdin.flush()
  header=process.stdout.readline().split();assert len(header)==3 and header[1]==b'blob',(head,name,header)
  raw=process.stdout.read(int(header[2]));assert process.stdout.read(1)==b'\n'
  assert sha(raw)==expected,(head,name)
 process.stdin.close();assert process.wait()==0
 cache[head]=inputs;proof['source_checks'][head]=len(inputs)
for name in RUNS:
 p=TMP/('rustusb-storage-arrival-'+name+'-20261026');r=load(p/'result.json');prov=load(p/'provenance.json');check_source(r['head'],prov['inputs'])
 expected=name not in ('jammy','jammy-flush','noble-flush');assert r['passed']==expected
 assert all(r['guards'].values()) and r['qemu_exits']=={'server':0,'client':0} and r['collection_exits']=={'server':0,'client':0}
 forced=(p/'external-forced-client-cleanup.json').exists();assert forced==(name in ('jammy-flush','noble-flush'))
 row={'name':name,'passed':r['passed'],'head':r['head'],'forced_client_qmp_quit':forced,'guests':r['qemu_exits'],'source_inputs':len(prov['inputs'])}
 for role in ('server','client'):
  serial=(p/role/'serial.log').read_text(errors='replace')
  if expected:assert 'Power down' in serial and 'blocked for more than' not in serial
  with tarfile.open(p/(role+'-evidence.tar')) as t:
   for member in t.getmembers():
    assert member.isdir() or member.isfile()
    assert '..' not in Path(member.name).parts and not Path(member.name).is_absolute()
    if member.isfile() and member.name.endswith('.json'):json.loads(t.extractfile(member).read())
 if expected:
  o=load(p/'observations.json');assert o['server-serve']['actual_usbipd_exit']==-9
  assert o['server-claim']['errno']==19 and o['server-claim']['claim_rc']==-1
  final=o['server-snapshot-fault-quarantine' if r['scenario']=='normal' else 'server-snapshot-failed-flush-quarantine']
  assert final['driver']=='usbip-host' and final['authorized']=='1' and not final['blocks']
  assert all(i['authorized']=='0' and i['driver'] is None for i in final['interfaces'])
  if r['scenario']=='normal':
   assert o['server-snapshot-before-daemon-kill']['tcp_connections']==o['server-snapshot-daemon-dead-io-live']['tcp_connections']
   assert o['client-io-2']['state']['generation']==o['client-io-3']['state']['generation']
   rows=[o['client-io-'+str(c)] for c in (1,2,3)];rw=1
   for n,data in enumerate(rows,1):
    assert data['ro_write_errno']==30 and data['sync_luns']==[0,1]
    payload=(('RUSTUSB-E66-LUN1-CYCLE-'+str(n)+'\n').encode()*200)[:4096];assert sha(payload)==data['sha256']
   row['same_socket_after_daemon_wait']=True
  else:
   f=o['client-flush-error'];assert f['first_sync_exit']==11 and f['explicit_second_control_exit']==0 and not f['clean_release_approved'] and f['lun']==0
   trace=load(p/'flush-trace-verification.json');assert trace['lun']==0 and trace['sense']==[11,0,6] and trace['failed_command']==53
   assert trace['qmp_error']['data']['node-name']=='arrival-lun0'
   rows=f['writes'];rw=0
   assert [w['sync_command']['exit'] for w in rows]==[11,0]
   row['fault_lun']=0
  expected_bytes=bytearray(64*1024*1024)
  for n,w in enumerate(rows):
   payload=((('RUSTUSB-E66-LUN1-CYCLE-'+str(n+1)) if rw else ('RUSTUSB-E66-FLUSH-'+str(bool(n))))+'\n').encode()*200
   payload=payload[:4096];assert sha(payload)==w['sha256']
   expected_bytes[w['offset']:w['offset']+w['bytes']]=payload
  rwfile=p/'server/.private'/f'lun{rw}.raw';rofile=p/'server/.private'/f'lun{1-rw}.raw'
  assert sha(rwfile.read_bytes())==sha(expected_bytes);assert rofile.read_bytes()==bytes(64*1024*1024)
  row['offline_whole_rw_sha256']=sha(expected_bytes);row['offline_whole_ro_sha256']=sha(bytes(64*1024*1024))
 proof['runs'].append(row)
p=TMP/'rustusb-storage-arrival-linux-20261026';valid=0
for row in load(p/'manifest.json')['sources']:
 if 'sha256' in row:
  data=(p/'sources'/row['version']/row['path']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256'];valid+=1
proof['research']['linux_originals_verified']=valid
p=TMP/'rustusb-storage-arrival-usb-20261026';valid=0
for manifest in ('sources-inherited.json','sources-new.json','sources-sg.json'):
 for row in load(p/manifest):
  if row.get('status')=='ok':
   data=(p/row['path']).read_bytes();assert sha(data)==row['sha256'] and len(data)==row['bytes'];valid+=1
proof['research']['usb_original_receipts_verified']=valid
p=TMP/'rustusb-storage-arrival-software-20261026';o=load(p/'summary.json');assert o['result']=='PASS' and all(o['guards'].values());check_source(o['head'],o['inputs'])
counts={}
for name in ('core','gui'):
 text=(p/(name+'.log')).read_text();rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',text);assert rows
 assert all(int(f)==int(i)==0 for _,f,i in rows);counts[name]=sum(int(a) for a,_,_ in rows)
assert counts=={'core':1148,'gui':18};proof['software_test_executions']=counts
proof['passed']=True
(OUT/'audit.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'passed':True,'runs':len(RUNS),'source_checks':proof['source_checks'],'research':proof['research'],'software':counts}))

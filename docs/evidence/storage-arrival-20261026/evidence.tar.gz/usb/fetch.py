import pathlib, urllib.request, concurrent.futures, hashlib, json, datetime
root=pathlib.Path('/tmp/rustusb-storage-arrival-usb-20261026')
linux=['drivers/usb/usbip/stub.h','drivers/usb/usbip/usbip_event.c','drivers/usb/usbip/stub_tx.c','drivers/usb/usbip/stub_main.c','drivers/usb/core/hcd.c','drivers/usb/core/usb.c','tools/usb/usbip/libsrc/usbip_host_driver.c','tools/usb/usbip/libsrc/usbip_common.c','tools/usb/usbip/libsrc/usbip_host_common.c','tools/usb/usbip/libsrc/usbip_device_driver.c','tools/usb/usbip/src/usbipd.c','tools/usb/usbip/src/usbipd_dev.c','tools/usb/usbip/src/usbip_attach.c','tools/usb/usbip/src/usbip_detach.c','Documentation/ABI/testing/sysfs-bus-usb']
qemu=['qapi/block-core.json','block/io.c','block/raw-format.c','block/file-posix.c','block/trace-events','hw/scsi/trace-events','hw/usb/trace-events','hw/usb/hcd-ehci-pci.c','hw/usb/bus.c','qapi/qom.json','qapi/block.json','scripts/qmp/qmp-shell']
jobs=[]
for ver in ['v5.15','v6.8']:
 for path in linux:jobs.append((f'linux-{ver}/{path}',f'https://raw.githubusercontent.com/torvalds/linux/{ver}/{path}'))
for path in qemu:jobs.append((f'qemu-v6.2.0/{path}',f'https://raw.githubusercontent.com/qemu/qemu/v6.2.0/{path}'))
for name,url in [('web/linux-authorization.html','https://cdn.kernel.org/doc/html/latest/usb/authorization.html'),('web/qemu-blkdebug.html','https://www.qemu.org/docs/master/devel/testing/blkdebug.html')]:jobs.append((name,url))
def fetch(pair):
 name,url=pair
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'RustUSB-source-research/1'}),timeout=40) as resp:data=resp.read()
  dest=root/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  return {'path':name,'url':url,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'fetched_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ok'}
 except Exception as e:return {'path':name,'url':url,'status':'error','error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:result=list(pool.map(fetch,jobs))
(root/'sources-new.json').write_text(json.dumps(result,indent=2)+'\n')
for item in result:
 if item['status']!='ok':print(item)
print('Downloaded',sum(x['status']=='ok' for x in result),'of',len(result))

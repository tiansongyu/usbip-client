import pathlib,urllib.request,json,hashlib,datetime,concurrent.futures
r=pathlib.Path('/tmp/rustusb-storage-arrival-usb-20261026')
jobs=[(f'sg3-utils-release-1.46/{p}',f'https://raw.githubusercontent.com/doug-gilbert/sg3_utils/b81d7816ca45f02bb3d50e4adde0222e8b66c2eb/{p}') for p in ['src/sg_sync.c','doc/sg_sync.8','lib/sg_cmds_basic.c','lib/sg_cmds_extra.c','lib/sg_lib.c','include/sg_lib.h','COPYING','COVERAGE','README']]
jobs += [('metadata/sg3-utils-release-1.46.json','https://api.github.com/repos/doug-gilbert/sg3_utils/commits/b81d7816ca45f02bb3d50e4adde0222e8b66c2eb')]
jobs += [(f'qemu-v6.2.0/{p}',f'https://raw.githubusercontent.com/qemu/qemu/44f28df24767cf9dca1ddc9b23157737c4cbb645/{p}') for p in ['scsi/utils.c','include/scsi/utils.h','scsi/trace-events']]
def get(pair):
 p,u=pair
 try:
  b=urllib.request.urlopen(u,timeout=30).read();d=r/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
  return {'path':p,'url':u,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'fetched_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ok'}
 except Exception as e:return {'path':p,'url':u,'status':'error','error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as p:a=list(p.map(get,jobs))
(r/'sources-sg.json').write_text(json.dumps(a,indent=2)+'\n')
for x in a:
 if x['status']!='ok':print(x)
print('downloaded',sum(x['status']=='ok' for x in a),'of',len(a))

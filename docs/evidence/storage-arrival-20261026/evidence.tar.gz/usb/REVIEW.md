# E66: prearrival isolation, Native storage data, and failure review

Status: source-grounded mechanism proposal, not executed and not RustUSB storage support. Date: 2026-10-26. Repository observed at `0865f65848d3cac986e5366ff55b19d3d1c0e352` after E65. This review makes no repository changes and runs no builds/QEMU, device operations, mounts, modules, or services.

## Provenance

The independent archive in this directory copies the E65 original files without alteration and adds E66 sources. Linux v5.15 is `8bb7eca972ad531c9b149c0a51ab43a417385813`; v6.8 is `e8f897f4afef0031fe618a8e94127a0934896aba`; QEMU v6.2.0 is `44f28df24767cf9dca1ddc9b23157737c4cbb645`. Added sg3_utils release-1.46 is `b81d7816ca45f02bb3d50e4adde0222e8b66c2eb`, from the author's own mirror, to check `sg_sync` behavior. Actual guest Ubuntu package/kernel patches remain execution evidence; record package versions and binary hashes rather than assuming upstream identity.

`sources-inherited.json`, `sources-new.json`, and `sources-sg.json` retain each URL/hash/size/fetch timestamp/error. `SHA256SUMS` covers the archive. Original Linux COPYING/GPL text, QEMU COPYING/LICENSE and sg3_utils COPYING/per-file license headers are retained. `fetch.py`, `fetch_sg.py`, and `line-map.txt` record the retrieval/line-reference method. No GPL source is proposed for copying into MIT product code. Two old missing Linux fs/block_dev.c, two E66 missing usbipd_dev.c and one missing sg3_utils COPYING.BSD request are retained as failed probes; relevant actual source and licensing headers were obtained.

Current-year primary-source web lookup located the official Linux USB authorization page, QEMU blkdebug documentation and the sg3_utils author's mirror. Their current pages were not substituted for fixed-version behavior. New locator searches: `2026 site:kernel.org usb interface_authorized_default authorization usbip`; `2026 site:qemu.org blkdebug flush_to_disk inject-error`; `2026 site:github.com/doug-gilbert/sg3_utils sg_sync sg_ll_sync_cache_10 v1.46`; `2026 site:sg.danny.cz sg_sync synchronize cache exit status 1.46`. Current Linux/QEMU locator HTML is saved in `web/`.

## Decision

A **fresh device that has never had local storage interfaces bound**, on a dedicated source-guest USB controller whose interface default is denied **before attachment**, is a credible Native mechanism experiment. It does not solve dynamic transfer of an already-published local block device. Product storage blockers, E65 inspection semantics, authorization, journal and receipts must remain unchanged.

For the parent's intended minimal experiment, use a dedicated xHCI controller, set `interface_authorized_default=0` on **both** its USB2 and USB3 root hubs while empty, then attach a new two-LUN BOT device (one QEMU-enforced RO, one disposable RW). Leave device authorization at 1. The generic USB driver may configure it, but its storage interfaces are unauthorized and cannot bind. Stock `usbip bind` can then bind the whole device, unconfiguring it; the remote client's configuration request reconstructs unauthorized source interfaces while Native owns the hub port. Only source guest policy changes; client VHCI interfaces must remain authorized so its BOT driver can enumerate the imported disk.

An optional stronger separate trial sets **both** root defaults (`authorized_default=0` and `interface_authorized_default=0`) before arrival, binds the exact unconfigured device to usbip-host, then sets **only that pinned device** `authorized=1`. Configuration then creates unauthorized interfaces while Native already owns the port. This requires its own test; it is not necessary to mix it into the first accepted experiment. Device authorization left at 0 is not a positive data path.

## Source facts and exact requirements

### Configuration and bind

| Fact | Linux v5.15 | Linux v6.8 |
| --- | --- | --- |
| `usb_probe_interface` rejects an owned device before interface driver probing | core/driver.c 318–341 | core/driver.c 321–344 |
| `usb_driver_claim_interface` rejects unauthorized interface with ENODEV | core/driver.c 535–550 | core/driver.c 538–553 |
| Unauthorized device forces configuration 0 | core/message.c 1957–1966 | core/message.c 1993–2002 |
| Every newly created interface copies the HCD default | core/message.c 2072 | core/message.c 2108 |
| Device authorization selects/sets a configuration | core/hub.c 2631 onward | core/hub.c 2684–2718 |
| Stub probe has no authorized/actconfig precondition | usbip/stub_dev.c 308 onward | usbip/stub_dev.c 310–394 |
| Stub claims hub port | usbip/stub_dev.c 385 | usbip/stub_dev.c 387–388 |
| libusbip accepts zero configuration/interface metadata after bind | tools/usb/usbip/libsrc/usbip_common.c `read_attr_value` | same, 141–175 |

Primary anchors: [v6.8 probe/claim](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/driver.c#L321), [v5.15 claim](https://github.com/torvalds/linux/blob/8bb7eca972ad531c9b149c0a51ab43a417385813/drivers/usb/core/driver.c#L535), [v6.8 configuration](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/message.c#L1993), [v6.8 stub probe](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/usbip/stub_dev.c#L310), [libusbip zero configuration handling](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/tools/usb/usbip/libsrc/usbip_common.c#L141).

`usb_set_configuration` registers interfaces, but registration is not successful driver binding. With HCD default 0, each actual source interface must show authorized=0 and no driver. With Native's hub-port ownership, ordinary interface probing is additionally rejected by `usb_device_is_owned`; this guard is lost when that port is released, so the HCD default remains important through failure/re-enumeration.

The default affects newly created interfaces, not existing ones. Setting it after attachment does not establish “never locally bound.” It is per HCD; xHCI's USB2/USB3 roots need separate observed writes/readbacks. Replacing/resetting/re-registering the controller or rebooting can lose these in-memory defaults. This experiment keeps them in force until the guests exit; it is not persistent production enrollment.

`usbip bind` unbinds the generic **device** driver, which unconfigures all interfaces, then adds the busid and binds the stub. A zero/blank bConfigurationValue and zero/absent interfaces directly after bind are expected. `usbipd` explicitly supports this state; do not fabricate an active config/first interface for catalog metadata.

Pre-populated `match_busid` alone does not force generic driver exclusion on arrival; the prior research's driver applicability finding still applies. Physical descriptor identity is not authentication, and root/USBFS raw control is not fully sandboxed by interface defaults. The mechanism uses trusted, controlled test guests with no competing USB administrator.

### Exact USBFS negative behavior

Source root can attempt `USBDEVFS_CLAIMINTERFACE` against the known device/interface as a **separate observed negative**, before the device is handed to Native or while its unauthorized source interface exists. The call chain is `devio.c:claimintf` → `usb_driver_claim_interface`.

- Interface exists, no current driver, authorized=0: `ENODEV` (errno 19), even for root.
- No active configuration / interface number absent: `ENOENT` (errno 2), from `usb_ifnum_to_if` lookup in devio.c 795–797.
- An existing driver is bound: `EBUSY` precedes the authorization test.
- Privileges-dropped USBFS can also return EACCES before this point; that is a different path.

Use a guest-compiled tiny probe with `<linux/usbdevice_fs.h>` and the real `USBDEVFS_CLAIMINTERFACE` constant, save syscall result/errno and the before-call exact interface state, then actually close its FD. Do not infer all negative paths as EACCES. This probe cannot certify that raw endpoint-0 control requests are forbidden. It explains why Native results must not be claimed for USBFS's interface-claim backend.

### SET_CONFIGURATION, reset and transport shutdown

`stub_rx.c` intercepts SET_CONFIGURATION, calls `usb_set_configuration`, then the outer receive path still submits the URB. The tweak logs some errors but returns 0; an application header/ACK alone does not establish actual configuration. Inspect the real source interfaces and client enumeration. SET_INTERFACE invokes the real `usb_set_interface`. These paths do not authorize interfaces on behalf of the remote client. See [v6.8 stub_rx.c 103–147, 575–597](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/usbip/stub_rx.c#L103).

`SDEV_EVENT_DOWN`, TCP error and submit error are SHUTDOWN|RESET; removal is SHUTDOWN|BYE; allocation failure is SHUTDOWN|UNUSABLE. The event worker performs shutdown first, reset second, unusable last. Shutdown shuts down the socket, joins original RX/TX kernel threads, releases the socket and cleans original URBs. Reset locks the real USB device, calls `usb_reset_device`, and marks AVAILABLE only on success; otherwise ERROR. [usbip_common.h 236–245](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/usbip/usbip_common.h#L236), [usbip_event.c 62–100](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/usbip/usbip_event.c#L62), [stub_dev.c 153–240](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/usbip/stub_dev.c#L153).

Reset does **not** necessarily leave cfg=1, nor necessarily make cfg=0. With no actconfig it finishes without configuring. With a current actconfig, reset restores that configuration and previous alternates. Failed reset or changed descriptors can schedule logical disconnection/re-enumeration. The client may already have sent SET_CONFIGURATION(0) during its own teardown. Correct post-fault invariants are:

- The original device is either the same pinned generation in observed stub AVAILABLE/ERROR, or its disappearance/replacement is explicitly recorded.
- If source interfaces exist, all relevant ones remain unauthorized with no local storage driver; no SCSI/block descendants appeared for the selected source device.
- If cfg=0, interfaces may legitimately be absent; this is not permission to skip the device-generation/default-policy checks.
- If new generation appears, it is not adopted/re-authorized/imported based on the old busid.
- Exact old client VHCI port/generation disappears; source AVAILABLE is not substituted for client release proof or clean storage contents.

See [v6.8 hub.c 6108–6110, 6121–6187](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/hub.c#L6108), [v5.15 reset implementation](https://github.com/torvalds/linux/blob/8bb7eca972ad531c9b149c0a51ab43a417385813/drivers/usb/core/hub.c#L5878). Keep actual cfg transitions in evidence instead of broadening a failed expected cfg1 check after the fact.

### Daemon death is not kernel connection death

usbipd's child writes the established socket FD to the stub and exits; the kernel has retained a socket reference. Parent closes its FD and remains a listener. Killing/waiting the original daemon Popen proves that userspace process ended; it does not kill an already handed-off kernel USB session. [usbipd.c 91–154 and 342–357](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/tools/usb/usbip/src/usbipd.c#L91), [stub_sockfd 74–114](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/usbip/stub_dev.c#L74).

A valid distinct test kills/waits the original daemon after first imported I/O, proves the same kernel connection and client generation can perform another bounded I/O cycle, starts a new listener, and proves it does not create a new session or local block device. Busy duplicate IMPORT may be a separate negative. A later exact established-tuple TCP RST is the actual network-failure trial. Do not label daemon SIGKILL as network-fault recovery.

### Keeping the source isolated

For this mechanism, keep usbip-host bound after normal detach or link failure and retain HCD interface default=0. Stop/wait the listener to prevent fresh admissions, but separately terminate/observe any existing kernel connection. Do not run stock `usbip unbind`, driver `rebind`, `drivers_probe`, per-interface authorize=1, module unload or automatic recovery.

Stock unbind invokes explicit `rebind` and `device_attach`. Directly writing only usbip-host's driver `unbind` does not itself call stock rebind, but stub_disconnect releases the hub port before closing its connection; active configuration/interfaces may still exist. Thus “just unbind” is not a stronger quarantine primitive. If a separate administrative mechanism deliberately removes stub ownership, it must retain denial defaults/current unauthorized interfaces, record actual shutdown, and verify the no-driver/no-block state; that is not needed for the minimal test.

`usbip_host_exit` deregisters the driver then explicitly calls `stub_device_rebind` ([stub_main.c 403–418](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/usbip/stub_main.c#L403)). Do not use rmmod as a purported isolated cleanup. Guest shutdown after all evidence is separate from product rebind behavior.

## Minimal guest-only experiment

All block backings are new, private regular files containing only generated fixture bytes. No host `/dev/*`, loop, mount, physical USB passthrough, scsi-block, scsi-generic or production image. All usbip/module/sysfs/client disk commands run solely inside the two authorized isolated Ubuntu guests. Record exact guest kernel, installed usbip/sg3-utils, actual ELF hashes, QEMU version/options and image hashes. Do not expose unauthenticated stock usbipd beyond the private guest network; this is a kernel mechanism fixture, not a replacement for RustUSB's authenticated transport.

### Setup and normal data

1. Start source guest with its normal virtio root disk and a separate empty xHCI controller. Resolve both root hubs by that controller's exact guest PCI ancestry; do not assume usb1/usb2. Read/write/readback each `interface_authorized_default` to 0 before attaching test USB. Preserve pre-attachment snapshot and boot/event trace. Source usb-storage/UAS modules should be present/loaded so no driver is a meaningful authorization result, not a missing-module result.
2. Create two private regular file block backends. LUN0 has `readonly=on`; LUN1 is writable, flush enabled. Add hotplugged `usb-bot` unattached, add contiguous scsi-hd LUN0 and LUN1, then QMP set attached=true. Assert source exact generation/config/unauthorized interfaces/no driver/no SCSI/block descendants. Parent's first protocol is BOT only; UAS remains separately scoped.
3. Optional root USBFS claim negative on a present unauthorized interface: require ENODEV and close original FD before handoff.
4. Stock `usbip bind --busid <exact>` in source. Require stub driver and AVAILABLE. cfg0/interfaces absent is expected. Start original tracked usbipd process in foreground. Client uses stock `usbip attach --remote <source> --busid <exact>`; pin actual VHCI port and imported USB generation. Wait for both LUNs by exact imported USB ancestry plus H:C:T:L, not `/dev/sdX` order. `udevadm settle` alone is not the condition.
5. LUN0: read generated fixture region and compare expected bytes/hash. A deliberate bounded write attempt should be rejected; preserve open/block-level rejection separately from direct SCSI WRITE_PROTECTED evidence if the latter is explicitly included. LUN1: write a deterministic, nonzero pattern at a fixed safe offset, fsync the same FD and check actual return; read it back with a fresh/bypassed client cache and compare hash. Record per-LUN identities/count and unchanged RO hash.
6. Synchronize each relevant LUN with `sg_sync --verbose`, no --immed or --sync-nv. For RW, `/dev/sdX` can carry SG_IO. RO `/dev/sdX` may reject sg_sync's rw open before any CDB; map the exact RO LUN's `/dev/sgN` if a per-LUN command is required. QEMU RO flush is a no-op; label it accepted RO sync, not writable cache persistence. Raw test disks need no filesystem mount; if a filesystem variant is added, explicitly unmount first and record actual result.
7. Close all original client disk/probe FDs. Client `usbip detach --port <original>`; observe exact VHCI NULL and old USB/block generation disappearance. Source stays stub-bound, no local storage driver/block. Record cfg and status as actually observed; stop/wait daemon. After both QEMU instances actually exit, independently verify generated data against the RW backing file and unchanged RO hash. Do not inspect a live writable backing file as an integrity verdict.

Example QMP attach sequence (placeholders, not run; assumes private drive nodes e66ro/e66rw exist):

```json
{"execute":"device_add","arguments":{"driver":"usb-bot","id":"e66bot","bus":"e66xhci.0","serial":"RUSTUSB-E66-BOT"}}
{"execute":"device_add","arguments":{"driver":"scsi-hd","id":"e66lun0","bus":"e66bot.0","scsi-id":0,"lun":0,"drive":"e66ro","serial":"RUSTUSB-E66-LUN0","rerror":"report","werror":"report"}}
{"execute":"device_add","arguments":{"driver":"scsi-hd","id":"e66lun1","bus":"e66bot.0","scsi-id":0,"lun":1,"drive":"e66rw","serial":"RUSTUSB-E66-LUN1","write-cache":"on","rerror":"report","werror":"report"}}
{"execute":"qom-set","arguments":{"path":"/machine/peripheral/e66bot","property":"attached","value":true}}
```

Both LUNs exist before visible attachment. Device names and roots are test-owned. Check each actual QMP response before proceeding. `usb-bot` hotplug auto_attach=0 is implemented in QEMU dev-storage-bot.c 28–41; do not assume the same with cold command-line attachment.

### Minimal matrix

| Trial | Required new evidence | Result boundary |
| --- | --- | --- |
| N1 normal read/write + clean detach | two real LUNs, source no local storage, client RO read and RW fsync/readback/sg_sync, old VHCI gone, backing verification after VM exit | QEMU Native mechanism only |
| N2 daemon death/restart during N1 | original daemon actual wait, same client generation/socket, successful second I/O cycle while daemon absent; new daemon does not adopt/clean old owner | not link failure |
| F1 precise TCP RST after completed unsynced write | original exact tuple reset, original client generation gone, source reset/status observed; no source driver/block/admission/reimport | session contents/flush uncertain; retain quarantine |
| F2 fresh RW LUN, one-shot flush EIO | first intended sg_sync CDB, QMP error + sense + nonzero exit, later explicit once-consumption control; no local source driver/block | original failure preserved; no clean durability claim |
| G1 optional replacement after fault | QMP removes old device; new same-port device generation is observed unauthorized and not autoexported/imported | no old authorization/proof transferred |

Run at least normal and both distinct fault trials on the target actual Ubuntu 22.04 and 24.04 kernels if claiming evidence for both. A source-level comparison of v5.15/v6.8 does not replace actual guest runs. N2 can be embedded in normal trial; F1/F2 should use independent disposable media/epochs so uncertain dirty state is not silently reused for a positive proof. No automatic retry/reimport after F1. If a manual laboratory reread is desired, name it as a new explicitly controlled recovery experiment and preserve the original unknown outcome.

## Closed one-shot cache error fixture

### Exact block graph and settings

Use `raw -> blkdebug -> file` for only the writable test LUN. Example blockdev JSON objects for `-blockdev` or QMP blockdev-add, all paths private regular files:

```json
{"driver":"file","node-name":"e66file","filename":"PRIVATE/lun1.raw","cache":{"direct":false,"no-flush":false}}
{"driver":"blkdebug","node-name":"e66debug","image":"e66file","config":"PRIVATE/flush-once.conf","cache":{"direct":false,"no-flush":false}}
{"driver":"raw","node-name":"e66rw","file":"e66debug","cache":{"direct":false,"no-flush":false}}
```

Connect scsi-hd drive=e66rw with `write-cache=on,rerror=report,werror=report`. Fixed QEMU block.h lines 62,79–82 define these properties. Do not use `-snapshot`, cache=unsafe, force-share or werror=ignore. Host filesystem/hardware persistence remains outside QEMU's model.

`flush-once.conf`:

```ini
[inject-error]
event = "flush_to_disk"
iotype = "flush"
errno = "5"
once = "on"
immediately = "off"
```

Do not set a sector for a flush rule: rule_check receives offset=0, bytes=0 and a specified sector would not match its bytes-based predicate. `iotype=flush` keeps the activated rule from affecting a later read/write path. `once` removes the rule when an actual matching I/O consumes it, not merely when the event fires. An event config alone is not evidence of consumption.

QEMU [block/io.c 2942–2984](https://github.com/qemu/qemu/blob/44f28df24767cf9dca1ddc9b23157737c4cbb645/block/io.c#L2942) skips flush for readonly/no media and may omit the flush_to_disk event when write_gen was already flushed. Therefore perform a real new nonzero write before the target flush. [blkdebug.c 590–630 and 675–683](https://github.com/qemu/qemu/blob/44f28df24767cf9dca1ddc9b23157737c4cbb645/block/blkdebug.c#L590) checks the active flush rule and returns -EIO without calling its child flush. The raw parent emits the event to its blkdebug child; graph placement matters.

### Trigger and result

For the dedicated one-shot negative, do **not** run fsync before the intended sg_sync. That could consume the one-shot failure, and normal block error handling can retry. Perform a bounded O_DIRECT write to the fresh raw RW LUN without O_SYNC/O_DSYNC/FUA/fsync, keep the original FD alive, then signal readiness. No filesystem mount/automounter or other writer may touch this private LUN. The first explicit synchronizer is `sg_sync --verbose <exact RW /dev/sdX>` (default SYNCHRONIZE CACHE(10), LBA0/count0, IMMED=0). Preserve client command stdout/stderr/exit and child actual wait.

At fixed upstream sg3_utils1.46, source sg_sync.c 273–310 opens rw, sends one command and returns its categorized result. lib/sg_cmds_basic2.c 88–140 has no retry loop, uses a 60s command timeout and maps recovered/no-sense categories to success. Linux SG_IO on block device uses retries=0 in v5.15 scsi_ioctl.c 480 and allowed=0 in v6.8 463. Thus do not explain an unexpectedly successful first command as “expected retry” without actual trace.

QEMU's SYNCHRONIZE CACHE(10) dispatches to blk_aio_flush (scsi-disk.c 2093–2099). EIO maps to CHECK CONDITION + sense **ABORTED_COMMAND, key 0xb, ASC 0x00, ASCQ 0x06** (scsi/utils.c 236–238, 583–619). With report policy this reaches the guest, not a successful ignored completion (scsi-disk.c 189–240, 268–281). sg3_utils1.46 normally categorizes it as **exit 11** (sg_lib.h 459; sg_lib.c 2201–2205). Fix exact expectations to the real guest tool/kernel versions; accept no arbitrary nonzero as the intended failure.

Save QEMU `BLOCK_IO_ERROR` for the intended node with action=report. Its operation will be **write**, not flush, because QEMU classifies non-read errors that way (block-backend.c 1773–1784). node-name may name the scsi-hd root raw node, not the blkdebug child; resolve the saved graph. Reason is human-readable and not the sole machine criterion. Pair it with target LUN/CDB trace (`scsi_req_parsed`, command 0x35/53) and `scsi_req_build_sense` 0xb/0/6; these tracepoints are in hw/scsi/trace-events 11–14. Keep only generated-data metadata, no real user storage payload.

A second **explicitly requested** sg_sync on that exact generation can confirm the once rule has been consumed; require its own trace/exit result. This is a diagnostic control, not a retry that erases the first failure, and not automatic product recovery. If desired precede it with another bounded write to require a new actual flush rather than a generation no-op. The first failure remains a failed clean-detach barrier, and the device remains quarantined until the test's deliberate teardown.

For a separate fsync-negative test, either use a separate one-shot image and capture all block/SCSI retries and final syscall outcome, or a persistent `once=off` injection with bounded owner handling. Do not reuse the sg_sync-negative evidence to claim fsync failure was observed.

### sg_sync pitfalls relevant here

- `--immed` returns before actual synchronization; do not use it as a durability fence.
- In release1.46 `--timeout` affects only `--16`. QEMU6.2 scsi-disk dispatch includes SYNCHRONIZE CACHE(10) but no 16 variant. Do not change to --16 merely to shorten the test.
- `sg_sync` opens rw. RO /dev/sdX can fail before any command; target the exact matching /dev/sgN when testing accepted sync on a read-only LUN.
- Readonly QEMU backends return early from bdrv_co_flush. A successful RO sync does not prove a flush traveled to the backing file.
- Exit0 normalizes some recovered/no-sense outcomes. Preserve verbose output and trace; it is not an unconditional “power-loss durability proven” receipt.
- Process timeout/kill is not cancellation of a blocked kernel storage operation. Keep real child/worker identity and original ownership until actual wait/cleanup; a harness deadline fails the trial rather than fabricating completion.

Primary sg sources: [sg_sync.c](https://github.com/doug-gilbert/sg3_utils/blob/b81d7816ca45f02bb3d50e4adde0222e8b66c2eb/src/sg_sync.c#L273), [sync10 library](https://github.com/doug-gilbert/sg3_utils/blob/b81d7816ca45f02bb3d50e4adde0222e8b66c2eb/lib/sg_cmds_basic2.c#L88), [manual](https://github.com/doug-gilbert/sg3_utils/blob/b81d7816ca45f02bb3d50e4adde0222e8b66c2eb/doc/sg_sync.8), [QEMU sense mapping](https://github.com/qemu/qemu/blob/44f28df24767cf9dca1ddc9b23157737c4cbb645/scsi/utils.c#L236).

## Do not claim

Successful import/enumeration, stub AVAILABLE, daemon death, a client read satisfied from cache, RO sysfs flag, successful driver unbind, kernel RESET completion, an accepted asynchronous sync, or successful VM shutdown are individually insufficient to establish safe writable storage persistence. Even checked synchronous SCSI completion plus offline private-image verification only establishes this emulator/backend experiment, not physical firmware/power-loss guarantees.

This is a Native Linux mechanism, not a RustUSB product path, not USBFS support, not authenticated transport evidence, not local active-disk handoff, not namespace/open-handle completeness, not automatic recovery, and not completion of requirement4.6/Phase1/whole project. Existing storage denial remains until a separate authorized design establishes production admission, isolation lifetime, durable identity, cache/error state and recovery integration.

import gzip,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
ROOT=Path('/home/ubuntu/github/usbip-client');TMP=Path('/tmp');DEST=ROOT/'docs/evidence/storage-arrival-20261026'
assert not DEST.exists();DEST.mkdir(parents=True)
runs=['jammy','jammy-fixed','noble','jammy-flush','noble-flush','jammy-flush-lun0','noble-flush-lun0','jammy-normal-final','noble-normal-final']
roots={**{'runs/'+n:TMP/('rustusb-storage-arrival-'+n+'-20261026') for n in runs},**{n:TMP/('rustusb-storage-arrival-'+n+'-20261026') for n in ['preparation','software','linux','usb','development','audit']}}
files={};keys=[]
for prefix,root in roots.items():
 for p in sorted(root.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  if '.private' in p.parts:
   if p.name=='ssh-key':keys.append(p.read_bytes())
   continue
  if '__pycache__' in p.parts or p.suffix=='.pyc':continue
  files[prefix+'/'+p.relative_to(root).as_posix()]=p.read_bytes()
methods=['/tmp/run-rustusb-storage-arrival-gates-20261026.py','/tmp/rustusb-e66-failed-guest-cleanup.py','/tmp/audit-rustusb-storage-arrival-20261026.py',__file__]
for f in methods:files['methods/'+Path(f).name]=Path(f).read_bytes()
for head in ['d99201ca0625d0435b898814db6afaf4e4fa601f','3b9c5b2b93df7c058d0295e8c331709bff18d8c8','05f26ffbd11b9a1f959e523cac367cb4bdcc5343']:
 names=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'scripts/qemu_storage_arrival'],cwd=ROOT,text=True).splitlines()
 for name in names:files['fixture-sources/'+head+'/'+name]=subprocess.check_output(['git','show',head+':'+name],cwd=ROOT)
def scan(name,data):
 assert not name.startswith('/') and '..' not in Path(name).parts and '.private' not in Path(name).parts,name
 assert not data.startswith((b'\x7fELF',b'QFI\xfb')),name
 assert not re.search(rb'-----BEGIN (?:OPENSSH |RSA |EC |DSA )?PRIVATE KEY-----\s*\n',data),name
 assert not re.search(rb'(?i)(?:[?&]X-Amz-Signature=|[?&]sig=[A-Za-z0-9%]{24})',data),name
 assert not any(k in data for k in keys),name
 if name.endswith('.tar'):
  with tarfile.open(fileobj=io.BytesIO(data)) as t:
   for m in t.getmembers():
    assert m.isdir() or m.isfile(),(name,m.name)
    if m.isfile():scan(m.name,t.extractfile(m).read())
for name,data in files.items():scan(name,data)
archive=DEST/'evidence.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as t:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
manifest={'scope':'original research, preparation, software and nine separate mechanism runs; two failed clients required recorded forced disposal','archive':'evidence.tar.gz','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'members':{n:{'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()} for n,d in sorted(files.items())},'excluded':'private directories, keys, disks, executables, packages, pycache','actual_private_keys_checked':len(keys)}
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t.getmembers():assert t.extractfile(m).read()==files[m.name]
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(DEST/'README.md').write_text('''# Storage arrival mechanism evidence

See the [validation report](../../research/storage-arrival-quarantine-validation.md). This archive contains original research (with upstream license files), product-free guest preparation, software checks, all nine mechanism trials, actual terminal observations, fixture revisions and a later read-only audit. Six trials pass; three fail. Two failed clients require separately recorded forced QMP disposal, which is not clean shutdown despite process exit0.

`manifest.json` hashes every archive member. Nested guest archives contain original command/state records. No private key, disk, package or executable payload is included. Upstream GPL sources are research evidence, not RustUSB product implementation. Two failed audit attempts and the corrected method are retained separately; original trial results are unchanged.
''')
print(json.dumps({'members':len(files),'raw_bytes':sum(map(len,files.values())),'gzip_bytes':manifest['archive_bytes'],'sha256':manifest['sha256'],'private_keys_checked':len(keys)}))

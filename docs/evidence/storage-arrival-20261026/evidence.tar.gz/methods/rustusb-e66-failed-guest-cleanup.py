import hashlib,json,socket,time
from pathlib import Path
for release in ('jammy','noble'):
 p=Path('/tmp/rustusb-storage-arrival-'+release+'-flush-20261026')
 ident=json.loads((p/'qemu-identities.json').read_text())['client'];pid=ident['pid']
 exe=Path('/proc')/str(pid)/'exe'; cmd=(exe.parent/'cmdline').read_bytes().split(b'\0')
 assert hashlib.sha256(exe.read_bytes()).hexdigest()==ident['exe_sha256']
 assert any(str(p/'client/.private/disk.qcow2').encode() in a for a in cmd)
 serial=(p/'client/serial.log').read_bytes()
 assert b'blocked for more than' in serial and b'Waiting for process:' in serial
 record={'scope':'forced disposal of failed synthetic guest after blocked cooperative shutdown; not clean guest exit or recovery proof','time_unix':time.time(),'identity':ident,'cmdline':[a.decode() for a in cmd if a],'serial_sha256_before':hashlib.sha256(serial).hexdigest(),'serial_tail_before':serial[-1800:].decode(errors='replace'),'responses':[],'action':'QMP quit'}
 path=p/'external-forced-client-cleanup.json'
 with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as s:
  s.settimeout(10);s.connect(str(p/'client/.private/qmp.sock'));f=s.makefile('rwb',buffering=0)
  record['greeting']=json.loads(f.readline())
  for i,command in enumerate(('qmp_capabilities','query-status','quit')):
   request={'execute':command,'id':i};record.setdefault('requests',[]).append(request)
   path.write_text(json.dumps(record,indent=2)+'\n')
   f.write((json.dumps(request)+'\n').encode())
   while True:
    line=f.readline()
    if not line:
     record['eof']=True;break
    response=json.loads(line);record['responses'].append(response)
    if response.get('id')==i:break
   path.write_text(json.dumps(record,indent=2)+'\n')
 print(release,'owned client QMP quit sent; original runner must perform actual wait',flush=True)

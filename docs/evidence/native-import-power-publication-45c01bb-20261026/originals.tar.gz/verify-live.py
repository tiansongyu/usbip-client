import concurrent.futures,datetime,hashlib,json,pathlib,subprocess,urllib.request
R=pathlib.Path('/home/ubuntu/github/usbip-client');O=pathlib.Path(__file__).parent;D=O/'http';D.mkdir();head=(O/'content-head.txt').read_text().strip();base='https://tiansongyu.github.io/usbip-client/';paths=[p.relative_to(R/'website').as_posix() for p in sorted((R/'website').rglob('*')) if p.is_file() and p.name!='.nojekyll'];items=[('' if p=='index.html' else p,p) for p in paths]+[('index.html','index.html'),('?backend=virtual','index.html'),('?backend=physical','index.html')]
def one(item):
 i,(urlpath,source)=item;url=base+urlpath;expected=subprocess.check_output(['git','show',head+':website/'+source],cwd=R)
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'RustUSB-publication-verification'}),timeout=30) as response:
  b=response.read();v={'url':url,'final_url':response.url,'status':response.status,'headers':dict(response.headers),'source':'website/'+source,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'matches_content_commit':b==expected,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (D/(str(i)+'.body')).write_bytes(b);(D/(str(i)+'.json')).write_text(json.dumps(v,indent=2)+'\n');return v
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:results=list(pool.map(one,enumerate(items)))
passed=all(v['status']==200 and v['matches_content_commit'] for v in results);(O/'http-summary.json').write_text(json.dumps({'head':head,'passed':passed,'responses':results,'scope':'Exact canonical public HTTP body equality; no deployment inferred from local source'},indent=2)+'\n');print(json.dumps({'passed':passed,'responses':len(results),'head':head}));assert passed

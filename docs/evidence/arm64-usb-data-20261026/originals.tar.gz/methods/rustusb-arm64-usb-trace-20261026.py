"""Diagnostic only: enable metadata-only QEMU input/queue traces before original USB suite."""
import importlib.util,json,pathlib,runpy,subprocess,sys,time
ROOT=pathlib.Path('/home/ubuntu/github/usbip-client');sys.path.insert(0,str(ROOT/'scripts/qemu_arm64'))
from arm_vm import ArmVm,sha
spec=importlib.util.spec_from_file_location('physical_input_trace',ROOT/'scripts/qemu/run-physical-qemu.py');physical=importlib.util.module_from_spec(spec);spec.loader.exec_module(physical)
original=ArmVm.boot
method=pathlib.Path(__file__);method_sha=sha(method)
output=pathlib.Path(sys.argv[sys.argv.index('--output')+1]);prefix=output.with_name(output.name+'.trace-provenance.json')
prefix.write_text(json.dumps({'diagnostic_only':True,'method_path':str(method),'method_sha256':method_sha,'events':['input_event_key_qcode','input_event_sync','hid_kbd_queue_empty','hid_kbd_queue_full'],'original_acceptance_unchanged':True},indent=2)+'\n')
def boot(self):
 original(self)
 if self.usb:
  q=physical.Qmp(self.private/'qmp.sock',time.monotonic()+10,self.process)
  replies=[]
  try:
   replies.append(q.call('human-monitor-command',{'command-line':'logfile '+str(self.out/'input-trace.log')}))
   for name in ['input_event_key_qcode','input_event_sync','hid_kbd_queue_empty','hid_kbd_queue_full']:
    replies.append(q.call('trace-event-set-state',{'name':name,'enable':True}))
  finally:q.close()
  (self.out/'trace-enablement.json').write_text(json.dumps(replies,indent=2)+'\n')
ArmVm.boot=boot
try:runpy.run_path(str(ROOT/'scripts/qemu_arm64/usb.py'),run_name='__main__')
finally:
 assert sha(method)==method_sha
 if output.exists():(output/'trace-method-guard.json').write_text(json.dumps({'diagnostic_only':True,'method_sha256':method_sha,'unchanged':True},indent=2)+'\n')

"""Isolated ARM local evdev/QMP control; no RustUSB/USBIP or host peripherals."""
import concurrent.futures,importlib.util,json,pathlib,subprocess,sys,time,traceback,base64
ROOT=pathlib.Path('/home/ubuntu/github/usbip-client');sys.path.insert(0,str(ROOT/'scripts/qemu_arm64'))
from arm_vm import ArmVm,sha
spec=importlib.util.spec_from_file_location('physical_diag',ROOT/'scripts/qemu/run-physical-qemu.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
OUT=pathlib.Path('/tmp/rustusb-arm64-local-hid-loopback-20261026');OUT.mkdir()
tools=pathlib.Path('/tmp/rustusb-arm64-tools-20261026/root');parent=pathlib.Path('/tmp/rustusb-arm64-preparation-20261026/jammy/.private/disk.qcow2')
paths=[pathlib.Path(__file__),ROOT/'scripts/qemu_arm64/arm_vm.py',ROOT/'scripts/qemu_installed_usb/vm.py',tools/'usr/bin/qemu-system-aarch64',tools/'usr/share/AAVMF/AAVMF_CODE.fd',tools/'usr/share/AAVMF/AAVMF_VARS.fd',parent]
frozen={str(p):sha(p) for p in paths};head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT).strip()
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
save('provenance.json',{'head':head,'frozen':frozen,'scope':'no RustUSB/USBIP, one actual local emulated keyboard'})
ArmVm.tool_root=tools;vm=ArmVm(OUT/'guest',parent,'server',usb=True);q=None;result={'head':head,'tests':[]}
probe='''import pathlib,os,select,struct,time,json
nodes=[p for p in pathlib.Path('/sys/class/input').glob('event*') if (p/'device/name').read_text().strip()=='QEMU QEMU USB Keyboard']
assert len(nodes)==1,[str(p) for p in nodes]
p=nodes[0];fd=os.open('/dev/input/'+p.name,os.O_RDONLY|os.O_NONBLOCK)
pathlib.Path('/var/tmp/rustusb-local-hid-ready').write_text(p.name)
events=[];end=time.monotonic()+5
while time.monotonic()<end:
 r,_,_=select.select([fd],[],[],.2)
 if r:
  data=os.read(fd,4096);assert len(data)%24==0
  events.extend([list(struct.unpack('llHHI',data[i:i+24]))[2:] for i in range(0,len(data),24)])
 if [1,2,1] in events and [1,2,0] in events:break
os.close(fd);print(json.dumps({'event':p.name,'name':(p/'device/name').read_text().strip(),'events':events,'passed':[1,2,1] in events and [1,2,0] in events}))
'''
try:
 vm.boot();q=mod.Qmp(vm.private/'qmp.sock',time.monotonic()+10,vm.process)
 save('qmp-status.json',q.call('query-status'))
 save('input-trace-events.json',q.call('trace-event-get-state',{'name':'*input*'}))
 save('hid-trace-events.json',q.call('trace-event-get-state',{'name':'*hid*'}))
 save('logfile-result.json',q.call('human-monitor-command',{'command-line':'logfile '+str(OUT/'input-trace.log')}))
 for name in ['input_event_key_qcode','input_event_sync','hid_kbd_queue_full','hid_kbd_queue_empty']:
  save('enable-'+name+'.json',q.call('trace-event-set-state',{'name':name,'enable':True,'ignore-unavailable':True}))
 vm.run('cat /proc/bus/input/devices; lsusb -t','local-inputs')
 vm.run('sudo modprobe usbip_host && sudo modprobe vhci_hcd && command -v usbipd && command -v usbip && sudo systemd-run --unit=rustusb-local-usbipd /usr/bin/usbipd --ipv4 && sudo /usr/bin/usbip bind -b 1-1 && sudo /usr/bin/usbip attach -r 127.0.0.1 -b 1-1','native-loopback-attach')
 vm.run('cat /proc/bus/input/devices; lsusb -t; cat /sys/devices/platform/vhci_hcd.0/status','loopback-inputs')
 for method in ['original-send-key','input-send-event']:
  vm.run('sudo rm -f /var/tmp/rustusb-local-hid-ready','reset-ready-'+method)
  command="sudo python3 -c \"import base64;exec(base64.b64decode('"+base64.b64encode(probe.encode()).decode()+"'))\""
  with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
   future=pool.submit(vm.run,command,'probe-'+method)
   vm.run('for n in $(seq 1 100); do test ! -f /var/tmp/rustusb-local-hid-ready || exit 0; sleep 0.1; done; exit 1','await-ready-'+method)
   if method=='original-send-key':reply=q.call('send-key',{'keys':[{'type':'qcode','data':'1'}],'hold-time':100})
   else:
    reply=[]
    for down in [True,False]:
     reply.append(q.call('input-send-event',{'events':[{'type':'key','data':{'down':down,'key':{'type':'qcode','data':'1'}}}]}));time.sleep(.1)
   save('reply-'+method+'.json',reply)
   result['tests'].append({'method':method,**json.loads(future.result())})
except BaseException:
 (OUT/'failure.txt').write_text(traceback.format_exc());result['error']=traceback.format_exc()
finally:
 if q:q.close()
 if vm.process is not None and vm.process.poll() is None:
  vm.run('sudo /usr/bin/usbip detach -p 0; sudo /usr/bin/usbip unbind -b 1-1; sudo systemctl stop rustusb-local-usbipd; sudo systemctl show rustusb-local-usbipd -p ActiveState -p SubState -p MainPID -p ExecMainStatus -p Result','loopback-cleanup')
 result['qemu_exit']=vm.close();result['guards']={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==head,'clean':not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT).strip(),'inputs':all(sha(pathlib.Path(p))==h for p,h in frozen.items())};save('summary.json',result)
print(json.dumps(result),flush=True)
raise SystemExit(0 if len(result['tests'])==2 and all(t['passed'] for t in result['tests']) and result['qemu_exit']==0 and all(result['guards'].values()) else 1)

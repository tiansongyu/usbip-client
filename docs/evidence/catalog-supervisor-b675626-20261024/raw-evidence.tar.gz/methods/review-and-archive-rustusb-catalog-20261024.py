import hashlib, json, pathlib, re, shutil, subprocess, tarfile
repo=pathlib.Path('/home/ubuntu/github/usbip-client')
head='b6756265a4ae57ab8058b1f65133f2397af3f063'
output=repo/'docs/evidence/catalog-supervisor-b675626-20261024'
output.mkdir(parents=True,exist_ok=False)
roots={
 'development':pathlib.Path('/tmp/rustusb-catalog-supervisor-20261024'),
 'software':pathlib.Path('/tmp/rustusb-catalog-software-b675626-20261024'),
 'agent-ipv4':pathlib.Path('/tmp/rustusb-catalog-agent-ipv4-b675626-20261024'),
 'agent-ipv6':pathlib.Path('/tmp/rustusb-catalog-agent-ipv6-b675626-20261024'),
 'signals':pathlib.Path('/tmp/rustusb-catalog-signals-b675626-20261024'),
 'regression-method':pathlib.Path('/tmp/rustusb-catalog-regression-method-b675626-20261024'),
}
methods=[pathlib.Path('/tmp/run-rustusb-catalog-gate-20261024.py'),pathlib.Path('/tmp/run-rustusb-catalog-regressions-20261024.py'),pathlib.Path(__file__)]
checks=[]
def require(ok,name):
    if not ok: raise RuntimeError(name)
    checks.append(name)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_text())
def save(path,data): path.write_text(json.dumps(data,indent=2)+'\n')
def source_check(directory,inputs):
    for name,entry in inputs.items():
        path=directory/'source'/name
        require(path.stat().st_size==entry['bytes'] and sha(path)==entry['sha256'],'copied source '+str(path.relative_to(directory)))
        blob=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
        require(len(blob)==entry['bytes'] and hashlib.sha256(blob).hexdigest()==entry['sha256'],'Git source '+name)
files=[]
for label,root in roots.items():
    for path in sorted(root.rglob('*')):
        if not path.is_file(): continue
        require(not path.is_symlink() and '.private' not in path.parts and not path.name.endswith('-key.der'),'archive public scope '+label+'/'+str(path.relative_to(root)))
        with path.open('rb') as stream: magic=stream.read(4)
        require(magic!=b'\x7fELF','no executable archive '+label+'/'+str(path.relative_to(root)))
        files.append({'original':str(path),'member':label+'/'+str(path.relative_to(root)),'bytes':path.stat().st_size,'sha256':sha(path)})
software=read(roots['software']/'summary.json')
require(software['head']==head and software['result']=='PASS' and software['inputs_unchanged'] and software['status_before']==software['status_after']=='','clean software gate')
require(len(software['commands'])==10 and all(c['exit_code']==0 for c in software['commands']),'ten actual gate commands')
source_check(roots['software'],software['inputs_before'])
totals={}
for name in ['test-default','test-all','vendor']:
    rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', (roots['software']/(name+'.log')).read_text())
    require(bool(rows) and all(int(f)==int(i)==0 for _,f,i in rows),'actual zero failure/ignore '+name)
    totals[name]=sum(int(p) for p,_,_ in rows)
require(totals=={'test-default':385,'test-all':477,'vendor':20},'882 actual test executions')
all_binaries=next(c['binaries'] for c in software['commands'] if c['name']=='release-all')
for family in ['ipv4','ipv6']:
    root=roots['agent-'+family];d=read(root/'summary.json')
    require(d['result']=='PASS' and d['head']==head and d['guest_exit_codes']=={'client':0,'server':0},'QEMU paired actual exit '+family)
    require(all(d[k] for k in ['source_guard','binary_guard','head_guard','clean_guard']),'four QEMU guards '+family)
    source_check(root,d['source_inputs'])
    require(d['binary_sha256']=={k:v['sha256'] for k,v in all_binaries.items()},'same software/QEMU binaries '+family)
    for name,entry in d['artifact_manifest'].items():
        path=root/name
        require(path.stat().st_size==entry['bytes'] and sha(path)==entry['sha256'],'original QEMU artifact '+family+'/'+name)
    require(len(d['actual_broker_executable_receipts'])==4 and len(d['actual_helper_executable_receipts'])==2,'original live executable receipts '+family)
    for name in d['actual_broker_executable_receipts']+d['actual_helper_executable_receipts']:
        expected=all_binaries['rustusb-helper' if 'helper' in name else 'rustusb']['sha256']
        require((root/name).read_text().split()[0]==expected,'live ELF '+family+'/'+name)
    require(d['facts']['io_rounds']==3 and d['facts']['assertion_count']==264,'original USB I/O and assertion scope '+family)
    save(output/('agent-'+family+'-summary.json'),d)
signals=read(roots['signals']/'summary.json')
require(signals['result']=='PASS' and signals['source_unchanged'] and signals['binary_unchanged'],'actual signals')
require(len(signals['cases'])==4 and all(c['result']=='PASS' and c['final_returncode']==0 and not c['forced_cleanup'] for c in signals['cases']),'four original signal children exited zero without force')
for entry in signals['artifacts']:
    path=roots['signals']/entry['path']
    require(path.stat().st_size==entry['length'] and sha(path)==entry['sha256'],'original signal artifact '+entry['path'])
bp=read(roots['regression-method']/'backpressure.log')
require(bp['result']=='PASS' and [c['exit'] for c in bp['checks']]==[0,1] and all(c['lease_socket_closed'] for c in bp['checks']),'two original BP exits and sockets')
method=read(roots['regression-method']/'summary.json')
require(method['result']=='PASS' and all(c['exit_code']==0 for c in method['commands']),'actual regression method exits')
for label,path,code,note in [
 ('old-red','old-red.log',101,'Original runtime, new test fixture. No clean-build or executed-ELF claim; the original entire pre-format test source was not separately frozen. Real TCP ClientHello, 200ms unrelated request observation, peer release and supervisor join precede the failing assertion.'),
 ('fixed-first','fixed-first.log',0,'First targeted responsiveness regression pass.'),
 ('development-second','development-second.log',101,'Test-only E0502 borrow scope errors; no product test execution.'),
 ('development-third','development-third.log',0,'Four targeted tests passed.'),
 ('development-fourth','development-fourth.log',0,'Final five targeted tests passed.'),
 ('development-clippy','development-clippy.log',0,'Targeted all-feature Clippy passed.'),
]:
    require((roots['development']/path).exists(),'retained development log '+label)
save(output/'development-history.json',{'receipt_source':'Actual tool exit receipts recorded during this turn, not reconstructed subprocess executions. Raw output preserved in the archive.','runs':[{'name':a,'log':'development/'+b,'actual_exit_code':c,'scope':d} for a,b,c,d in [
 ('old-red','old-red.log',101,'Original runtime responsiveness assertion failed after peer/supervisor teardown; test source was not separately frozen before formatting.'),
 ('fixed-first','fixed-first.log',0,'One targeted test.'),('development-second','development-second.log',101,'Test-only E0502, no test execution.'),('development-third','development-third.log',0,'Four targeted tests.'),('development-fourth','development-fourth.log',0,'Five targeted tests.'),('development-clippy','development-clippy.log',0,'Targeted all-feature Clippy.')]]})
for path in methods:
    files.append({'original':str(path),'member':'methods/'+path.name,'bytes':path.stat().st_size,'sha256':sha(path)})
archive=output/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
    for entry in files: tar.add(entry['original'],arcname=entry['member'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    require(set(tar.getnames())=={e['member'] for e in files},'archive exact closed member set')
    for entry in files:
        data=tar.extractfile(entry['member']).read()
        require(len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],'archive member '+entry['member'])
for entry in files: require(pathlib.Path(entry['original']).stat().st_size==entry['bytes'] and sha(pathlib.Path(entry['original']))==entry['sha256'],'original remains unchanged '+entry['member'])
save(output/'software-summary.json',software)
save(output/'review.json',{'result':'PASS','review_kind':'same-author read-only raw/hash review; no original runner/verifier imports; not an independent security audit or a new USB run','checks':len(checks),'test_executions':totals,'software_inputs':len(software['inputs_before']),'qemu_inputs_each':len(read(roots['agent-ipv4']/'summary.json')['source_inputs']),'paired_qemu_runs':2,'guest_exit_codes':[0,0,0,0],'signal_cases':4,'backpressure_cases':2,'original_files_byte_stable':len(files),'archive_bytes':archive.stat().st_size})
save(output/'manifest.json',{'schema_version':1,'head':head,'scope':'882 local test executions; two Native managed paired QEMU regressions; original four signals/two BP. All hardware/full G3 and later phases remain unverified.','archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)},'files':files})
print(json.dumps(read(output/'review.json')))

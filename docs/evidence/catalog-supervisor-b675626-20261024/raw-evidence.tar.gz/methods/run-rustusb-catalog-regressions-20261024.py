import datetime, hashlib, json, pathlib, subprocess, time
repo=pathlib.Path('/home/ubuntu/github/usbip-client')
out=pathlib.Path('/tmp/rustusb-catalog-regression-method-b675626-20261024')
out.mkdir(exist_ok=False)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=repo).decode().strip()
summary={'head':git('rev-parse','HEAD'),'status_before':git('status','--porcelain'),'commands':[],'result':'FAIL','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save(): (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
save()
if summary['status_before']: raise RuntimeError('clean source required')
steps=[
 ('agent-ipv4',['python3','scripts/qemu/run-agent-qemu.py','--family','ipv4','--evidence','/tmp/rustusb-catalog-agent-ipv4-b675626-20261024']),
 ('agent-ipv6',['python3','scripts/qemu/run-agent-qemu.py','--family','ipv6','--evidence','/tmp/rustusb-catalog-agent-ipv6-b675626-20261024']),
 ('signals',['python3','scripts/test-server-signals.py','--skip-build','--evidence','/tmp/rustusb-catalog-signals-b675626-20261024']),
 ('backpressure',['python3','scripts/test-virtual-backpressure.py']),
]
try:
    for name,argv in steps:
        before={exe:sha(repo/'target/release'/exe) for exe in ['rustusb','rustusb-helper']}
        started=time.monotonic()
        with (out/(name+'.log')).open('wb') as log:
            result=subprocess.run(argv,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
        item={'name':name,'argv':argv,'exit_code':result.returncode,'seconds':time.monotonic()-started,'binaries_before':before,'binaries_after':{exe:sha(repo/'target/release'/exe) for exe in before}}
        summary['commands'].append(item);save();print(name,result.returncode,flush=True)
        if result.returncode: raise RuntimeError('failed '+name)
    summary['result']='PASS'
except Exception as error: summary['error']=repr(error)
finally:
    summary['head_after']=git('rev-parse','HEAD');summary['status_after']=git('status','--porcelain')
    if summary['head_after']!=summary['head'] or summary['status_after']!=summary['status_before']: summary['result']='FAIL'
    summary['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({'result':summary['result'],'output':str(out)}),flush=True)
raise SystemExit(0 if summary['result']=='PASS' else 1)

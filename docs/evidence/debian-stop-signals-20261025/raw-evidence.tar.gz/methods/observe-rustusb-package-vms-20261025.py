import concurrent.futures, datetime, json, pathlib, re, shlex, subprocess
roots=[pathlib.Path('/tmp/rustusb-package-jammy-signals-fresh-20261025'),pathlib.Path('/tmp/rustusb-package-noble-signals-fresh-20261025')]
code="""from pathlib import Path
import json
p=Path('/var/tmp/rustusb-package-evidence')
checks=p/'checks.jsonl'
if checks.exists(): print('CHECKS',checks.read_text().splitlines()[-3:])
starts=sorted(p.glob('command-*.started.json'))
if starts:
 q=starts[-1];print('LATEST',q.name,q.read_text().strip());base=str(q)[:-len('.started.json')]
 for suffix in ['.stdout','.stderr']:
  f=Path(base+suffix)
  if f.exists():print(suffix,f.read_bytes()[-1000:].decode(errors='replace'))
"""
def observe(out):
 needle=str(out/'.private/disk.qcow2').encode();port=None
 for p in pathlib.Path('/proc').glob('[0-9]*/cmdline'):
  try:a=p.read_bytes().split(b'\0')
  except (FileNotFoundError,PermissionError,ProcessLookupError):continue
  if a and a[0].endswith(b'qemu-system-x86_64') and any(needle in x for x in a):port=re.search(rb'hostfwd=tcp:127.0.0.1:(\d+)-:22',b' '.join(a)).group(1).decode();break
 if port is None:return {'case':out.name,'active':False}
 cmd=['ssh','-i',str(out/'.private/ssh-key'),'-p',port,'-o','StrictHostKeyChecking=no','-o','UserKnownHostsFile='+str(out/'.private/known_hosts'),'-o','BatchMode=yes','-o','ConnectTimeout=3','ubuntu@127.0.0.1','sudo python3 -c '+shlex.quote(code)]
 r=subprocess.run(cmd,capture_output=True);result={'case':out.name,'active':True,'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}
 name='progress-'+datetime.datetime.now(datetime.timezone.utc).strftime('%H%M%S%f')+'.json'
 (out/name).write_text(json.dumps(result,indent=2)+'\n')
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for result in pool.map(observe,roots):print(json.dumps(result))

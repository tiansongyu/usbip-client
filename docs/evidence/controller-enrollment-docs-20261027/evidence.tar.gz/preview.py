from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
ROOT=Path('/home/ubuntu/github/usbip-client/website')
class H(SimpleHTTPRequestHandler):
 def translate_path(self,path):
  path=path.split('?',1)[0];path=path.removeprefix('/nojs').removeprefix('/usbip-client')
  target=(ROOT/path.lstrip('/')).resolve()
  return str(target if target.is_relative_to(ROOT) else ROOT/'404.html')
 def end_headers(self):
  if self.path.startswith('/nojs/'):self.send_header('Content-Security-Policy',"script-src 'none'")
  super().end_headers()
server=ThreadingHTTPServer(('127.0.0.1',0),H)
print('http://127.0.0.1:'+str(server.server_port)+'/usbip-client/',flush=True)
try:server.serve_forever()
except KeyboardInterrupt:pass
finally:server.server_close()

import gzip,hashlib,io,json,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent;OUT=Path('/home/ubuntu/github/usbip-client/docs/evidence/controller-enrollment-docs-20261027');OUT.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();members={}
with (OUT/'evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for p in sorted(BASE.rglob('*')):
    if not p.is_file() or '__pycache__' in p.parts:continue
    b=p.read_bytes();name=p.relative_to(BASE).as_posix();members[name]={'bytes':len(b),'sha256':sha(b)};i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(OUT/'evidence.tar.gz') as t:
 for m in t.getmembers():assert sha(t.extractfile(m).read())==members[m.name]['sha256']
archive=OUT/'evidence.tar.gz';(OUT/'manifest.json').write_text(json.dumps({'scope':'E68 local documentation, CLI help and site QA; original method failure and source snapshots retained','archive':archive.name,'sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'members':members},indent=2)+'\n');print({'members':len(members),'archive_bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())})

import hashlib,json,re,subprocess,urllib.parse,urllib.request
from pathlib import Path
ROOT=Path('/home/ubuntu/github/usbip-client');OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
changed=subprocess.check_output(['git','diff','--name-only','26faa790'],cwd=ROOT,text=True).splitlines()
changed+=['docs/controller-policy.md','docs/research/controller-enrollment-validation.md','docs/evidence/controller-enrollment-20261027/README.md']
md=sorted(set(n for n in changed if n.endswith('.md')));links=[]
for n in md:
 text=(ROOT/n).read_text();text=re.sub(r'```.*?```','',text,flags=re.S)
 for target in re.findall(r'\]\(([^\s)]+)(?:\s+"[^"]*")?\)',text):
  target=target.strip('<>');u=urllib.parse.urlsplit(target);path=urllib.parse.unquote(u.path)
  prefix='/tiansongyu/usbip-client/blob/main/'
  if u.scheme:
   if u.netloc=='github.com' and path.startswith(prefix):p=ROOT/path.removeprefix(prefix)
   else:continue
  else:p=(ROOT/n).parent/path if path else ROOT/n
  assert p.exists(),(n,target,str(p));links.append({'source':n,'target':target})
source=OUT/'source';source.mkdir(exist_ok=True)
for n in [*md,'website/index.html']:
 p=source/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/n).read_bytes())
checks=[]
for args in [['target/release/rustusb','controller','--help'],['target/release/rustusb','controller','enroll','--help'],['target/release/rustusb','controller','reconcile','--help'],['target/release/rustusb','controller','retire','--help'],['target/release/rustusb-helper','--help']]:
 p=subprocess.run(args,cwd=ROOT,capture_output=True);name='help-'+str(len(checks));(OUT/(name+'.stdout')).write_bytes(p.stdout);(OUT/(name+'.stderr')).write_bytes(p.stderr);assert p.returncode==0;checks.append({'argv':args,'exit':p.returncode})
base='http://127.0.0.1:41177/usbip-client/';http=[]
for n in ['index.html','styles.css','app.js','assets/favicon.svg','assets/usbip-flow.svg','assets/usbip-flow-mobile.svg','assets/gui-qemu.png','404.html']:
 with urllib.request.urlopen(base+n) as r:b=r.read();row={'url':base+n,'status':r.status,'sha256':sha(b),'bytes':len(b)}
 assert b==(ROOT/'website'/n).read_bytes();http.append(row)
with urllib.request.urlopen('http://127.0.0.1:41177/nojs/usbip-client/') as r:
 assert r.headers.get('Content-Security-Policy')=="script-src 'none'";assert r.read()==(ROOT/'website/index.html').read_bytes();http.append({'url':r.url,'status':r.status,'csp':r.headers.get('Content-Security-Policy')})
# Documentation changes cannot silently replace tested implementation or fixtures.
allowed=set(changed)
assert all(n.endswith('.md') or n=='website/index.html' for n in changed)
provenance=json.loads(Path('/tmp/rustusb-controller-enrollment-jammy-20261026/provenance.json').read_text())
unchanged=[n for n,h in provenance['inputs'].items() if n not in allowed]
assert all(sha((ROOT/n).read_bytes())==provenance['inputs'][n] for n in unchanged)
assert all(sha(Path(p).read_bytes())==h for p,h in provenance['frozen'].items())
skill=Path('/home/ubuntu/.agents/skills/readme-site');global_files={str(p.relative_to(skill)):sha(p.read_bytes()) for p in skill.rglob('*') if p.is_file()};assert len(global_files)==4
assert Path('/home/ubuntu/.codex/skills/readme-site').resolve()==skill
result={'passed':True,'markdown_files':md,'local_or_repository_targets':links,'commands':checks,'http':http,'unchanged_tested_inputs':len(unchanged),'release_parent_hashes_unchanged':True,'global_readme_site':global_files,'codex_skill_symlink':True,'site_log':(OUT/'site.log').read_text()}
(OUT/'checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':True,'markdown_files':len(md),'local_targets':len(links),'unchanged_inputs':len(unchanged),'http':len(http)}))

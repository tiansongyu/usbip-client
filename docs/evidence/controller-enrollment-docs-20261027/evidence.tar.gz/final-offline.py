import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path('/home/ubuntu/github/usbip-client');OUT=Path(__file__).resolve().parent
names=subprocess.check_output(['git','diff','--name-only','26faa790'],cwd=ROOT,text=True).splitlines()+['docs/controller-policy.md','docs/research/controller-enrollment-validation.md','docs/evidence/controller-enrollment-20261027/README.md'];rows=[]
for n in sorted(set(n for n in names if n.endswith('.md'))):
 text=(ROOT/n).read_text();text=re.sub(r'```.*?```','',text,flags=re.S)
 for target in re.findall(r'\]\(([^\s)]+)(?:\s+"[^"]*")?\)',text):
  if target.startswith(('http:','https:','mailto:')):continue
  target=target.split('#',1)[0].strip('<>');p=(ROOT/n).parent/target if target else ROOT/n;assert p.exists(),(n,target);rows.append((n,target))
 p=OUT/'final-source'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/n).read_bytes())
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
(OUT/'final-offline.json').write_text(json.dumps({'passed':True,'targets':rows,'actual_preview_exit':{'session':70269,'exit':0,'chunk':'8c9543'},'boundary':'final local-target/diff checks after prose and work-log additions; earlier browser/HTTP records retain their original source snapshot'},indent=2)+'\n');print({'passed':True,'local_targets':len(rows)})

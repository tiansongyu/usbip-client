#![forbid(unsafe_code)]
use glib::prelude::*;
pub fn escape() -> glib::VariantStrIter<'static> {
    let variant = ["alpha", "beta"].to_variant();
    variant.array_iter_str().unwrap()
}

#![forbid(unsafe_code)]
use glib::prelude::*;
pub fn normal_use() -> Result<(), Box<dyn std::error::Error>> {
    let variant = ["alpha", "beta"].to_variant();
    let first = {
        let mut iter = variant.array_iter_str()?;
        iter.next()
    };
    assert_eq!(first, Some("alpha"));
    Ok(())
}

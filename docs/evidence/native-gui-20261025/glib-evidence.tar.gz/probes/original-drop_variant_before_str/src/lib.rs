#![forbid(unsafe_code)]
use glib::prelude::*;
pub fn escape() {
    let variant = ["alpha", "beta"].to_variant();
    let first = variant.array_iter_str().unwrap().next().unwrap();
    drop(variant);
    println!("{first}");
}

#![forbid(unsafe_code)]
use glib::prelude::*;
pub fn escape() -> &'static str {
    let variant = ["alpha", "beta"].to_variant();
    variant.array_iter_str().unwrap().next_back().unwrap()
}

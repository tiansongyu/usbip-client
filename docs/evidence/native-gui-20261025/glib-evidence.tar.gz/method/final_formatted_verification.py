from pathlib import Path
import subprocess,os,json,time
b=Path('/tmp/rustusb-gui-glib-remediation-20261025')
env=dict(os.environ,CARGO_HOME=str(b/'cargo-home'),CARGO_TARGET_DIR=str(b/'target'))
checks=[('patched-caller-clippy-formatted',['cargo','clippy','--manifest-path',str(b/'probes/patched-runtime/Cargo.toml'),'--all-targets','--','-D','warnings']),('patched-runtime-release-formatted',['cargo','test','--manifest-path',str(b/'probes/patched-runtime/Cargo.toml'),'--release','--locked']),('patched-runtime-fmt-final',['cargo','fmt','--manifest-path',str(b/'probes/patched-runtime/Cargo.toml'),'--','--check'])]
for name,cmd in checks:
 start=time.time();p=subprocess.run(cmd,cwd=b,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (b/'logs'/f'{name}.log').write_bytes(p.stdout)
 row={'name':name,'command':cmd,'cwd':str(b),'exit_code':p.returncode,'elapsed_seconds':time.time()-start,'output':f'logs/{name}.log'}
 rows=json.loads((b/'results.json').read_text());rows.append(row);(b/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps(row),flush=True)

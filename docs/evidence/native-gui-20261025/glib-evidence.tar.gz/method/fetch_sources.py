import urllib.request,json,hashlib,pathlib,datetime
base=pathlib.Path('/tmp/rustusb-gui-glib-remediation-20261025')
urls={
 'rustsec-2024-0429.md':'https://raw.githubusercontent.com/rustsec/advisory-db/main/crates/glib/RUSTSEC-2024-0429.md',
 'upstream-pr-1343.json':'https://api.github.com/repos/gtk-rs/gtk-rs-core/pulls/1343',
 'upstream-pr-1343.diff':'https://github.com/gtk-rs/gtk-rs-core/pull/1343.diff',
 'glib-0.18.5.crate':'https://static.crates.io/crates/glib/glib-0.18.5.crate',
 'glib-0.18.5-metadata.json':'https://crates.io/api/v1/crates/glib/0.18.5',
 'glib-0.20.0.crate':'https://static.crates.io/crates/glib/glib-0.20.0.crate',
 'glib-0.20.0-metadata.json':'https://crates.io/api/v1/crates/glib/0.20.0',
 'glib-original-vcs-variant-iter.rs':'https://raw.githubusercontent.com/gtk-rs/gtk-rs-core/42b9caf98e03ded086362d9653ca58fe94dc8658/glib/src/variant_iter.rs',
 'glib-fix-commit-variant-iter.rs':'https://raw.githubusercontent.com/gtk-rs/gtk-rs-core/05dff0ee696f9bcd8617cd48c4b812d046d440cb/glib/src/variant_iter.rs',
 'glib-get-child.html':'https://docs.gtk.org/glib/method.Variant.get_child.html',
 'glib-format-strings.html':'https://docs.gtk.org/glib/gvariant-format-strings.html',
}
receipts=[]
for name,url in urls.items():
 # Original payloads and failures are never replaced.
 if (base/'sources'/(name+'.receipt.json')).exists():
  receipts.append(json.loads((base/'sources'/(name+'.receipt.json')).read_text()));continue
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'rustusb-glib-remediation-research'})
  with urllib.request.urlopen(req,timeout=60) as r:
   data=r.read();receipt={'name':name,'url':url,'final_url':r.url,'status':r.status,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'headers':dict(r.headers)}
  (base/'sources'/name).write_bytes(data)
 except Exception as e:receipt={'name':name,'url':url,'error':str(e)}
 receipts.append(receipt)
 (base/'sources'/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
(base/'sources/retrievals.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps([{k:v for k,v in r.items() if k!='headers'} for r in receipts],indent=2))

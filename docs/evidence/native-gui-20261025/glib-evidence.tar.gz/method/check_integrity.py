from pathlib import Path
import json,hashlib,tarfile,subprocess,re,os
b=Path('/tmp/rustusb-gui-glib-remediation-20261025')
def digest(data):return hashlib.sha256(data).hexdigest()
result={'sources':{},'original_packages':{},'patched':{},'environment':{}}
for r in json.loads((b/'sources/retrievals.json').read_text()):
 if 'error' in r:continue
 p=b/'sources'/r['name'];actual=digest(p.read_bytes());assert actual==r['sha256'];result['sources'][r['name']]=actual
for version in ['0.18.5','0.20.0']:
 crate=b/'sources'/f'glib-{version}.crate';meta=json.loads((b/'sources'/f'glib-{version}-metadata.json').read_text())['version'];assert digest(crate.read_bytes())==meta['checksum']
 files=[]
 with tarfile.open(crate) as t:
  for m in t.getmembers():
   if not m.isfile():continue
   data=t.extractfile(m).read();p=b/'original'/m.name;assert p.read_bytes()==data
   files.append({'path':m.name,'bytes':len(data),'sha256':digest(data)})
 result['original_packages'][version]={'checksum':meta['checksum'],'license':meta['license'],'files':files}
orig=b/'original/glib-0.18.5';patched=b/'patched/glib-0.18.5'
assert (orig/'src/variant_iter.rs').read_bytes()==(b/'sources/glib-original-vcs-variant-iter.rs').read_bytes()
s=(orig/'src/variant_iter.rs').read_text();expected=s.replace('let p: *mut libc::c_char = std::ptr::null_mut();','let mut p: *mut libc::c_char = std::ptr::null_mut();').replace('                &p,','                &mut p,')
assert (patched/'src/variant_iter.rs').read_text()==expected
# The full file equals upstream merge source, including imports at that revision.
assert (patched/'src/variant_iter.rs').read_bytes()==(b/'sources/glib-fix-commit-variant-iter.rs').read_bytes()
# Published 0.20.0 changes imports, but iterator code itself is unchanged from backport.
upstream=(b/'original/glib-0.20.0/src/variant_iter.rs').read_text()
assert expected[expected.index('// rustdoc-stripper-ignore-next'):]==upstream[upstream.index('// rustdoc-stripper-ignore-next'):]
changes=[]
for p in orig.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(orig);q=patched/rel
 if p.read_bytes()!=q.read_bytes():changes.append(str(rel))
assert changes==['src/variant_iter.rs']
result['patched']={'changed_original_files':changes,'only_generated_extra_files':[str(p.relative_to(patched)) for p in patched.rglob('*') if p.is_file() and not (orig/p.relative_to(patched)).exists()],'variant_iter_sha256':digest((patched/'src/variant_iter.rs').read_bytes()),'source_entire_file_matches_merge_commit':True,'iterator_body_matches_published_0_20_0':True,'upstream_merge_commit':'05dff0ee696f9bcd8617cd48c4b812d046d440cb'}
for name,cmd in {'rustc':['rustc','-Vv'],'cargo':['cargo','-V'],'kernel':['uname','-a'],'uid':['id'],'glib_versions':['pkg-config','--modversion','glib-2.0','gio-2.0','gobject-2.0'],'glib_flags':['pkg-config','--libs','--cflags','glib-2.0','gio-2.0','gobject-2.0']}.items():
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);result['environment'][name]={'command':cmd,'exit_code':p.returncode,'output':p.stdout.decode()};assert p.returncode==0
result['environment']['os_release']=(Path('/etc/os-release')).read_text()
executables=[]
for mode in ['debug','release']:
 for p in (b/'target'/mode/'deps').glob('glib_patched_runtime_probe-*'):
  if p.is_file() and os.access(p,os.X_OK):
   output=subprocess.run(['ldd',str(p)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   executables.append({'path':str(p.relative_to(b)),'sha256':digest(p.read_bytes()),'bytes':p.stat().st_size,'ldd_exit_code':output.returncode,'ldd':output.stdout.decode()})
result['runtime_executables']=executables
(b/'integrity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'original_package_files':{v:len(x['files']) for v,x in result['original_packages'].items()},'patched':result['patched'],'runtime_executables':executables},indent=2))

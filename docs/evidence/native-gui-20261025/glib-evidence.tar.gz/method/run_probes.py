from pathlib import Path
import subprocess,os,json,time
b=Path('/tmp/rustusb-gui-glib-remediation-20261025')
env=dict(os.environ,CARGO_HOME=str(b/'cargo-home'),CARGO_TARGET_DIR=str(b/'target'))
rows=[]
def run(name,cmd,cwd):
 start=time.time();p=subprocess.run(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (b/'logs'/f'{name}.log').write_bytes(p.stdout)
 row={'name':name,'command':cmd,'cwd':str(cwd),'exit_code':p.returncode,'elapsed_seconds':time.time()-start,'output':f'logs/{name}.log'}
 rows.append(row);(b/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 return p
for variant in ['original','patched']:
 for case,expected in json.loads((b/'probes/expected.json').read_text()).items():
  p=run(f'{variant}-{case}', ['cargo','check','--manifest-path',str(b/'probes'/f'{variant}-{case}'/'Cargo.toml')],b)
  actual='accept' if p.returncode==0 else 'reject'
  if actual!=expected or (actual=='reject' and not (b'error[E0515]' in p.stdout or b'error[E0505]' in p.stdout)):
   raise SystemExit(f'{variant}/{case}: expected {expected}, got {actual}; unexpected failure retained')
for mode in ['debug','release']:
 cmd=['cargo','test','--manifest-path',str(b/'probes/patched-runtime/Cargo.toml')]
 if mode=='release':cmd+=['--release']
 p=run(f'patched-runtime-{mode}',cmd,b)
 if p.returncode:raise SystemExit(f'runtime {mode} failed')
# Test only upstream variant_iter module on patched code; do not run unpatched iterator.
for mode in ['debug','release']:
 cmd=['cargo','test','--manifest-path',str(b/'patched/glib-0.18.5/Cargo.toml'),'--lib','variant_iter::tests']
 if mode=='release':cmd+=['--release']
 p=run(f'patched-upstream-variant-iter-{mode}',cmd,b)
 if p.returncode:raise SystemExit(f'upstream {mode} failed')

from pathlib import Path
import json,tarfile,hashlib,difflib,shutil
b=Path('/tmp/rustusb-gui-glib-remediation-20261025')
for version in ['0.18.5','0.20.0']:
 p=b/'sources'/f'glib-{version}.crate';metadata=json.loads((b/'sources'/f'glib-{version}-metadata.json').read_text())['version']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==metadata['checksum']
 if not (b/'original'/f'glib-{version}').exists():
  with tarfile.open(p) as tar:tar.extractall(b/'original',filter='data')
if not (b/'patched/glib-0.18.5').exists():shutil.copytree(b/'original/glib-0.18.5',b/'patched/glib-0.18.5')
original=(b/'original/glib-0.18.5/src/variant_iter.rs').read_text()
assert original.count('let p: *mut libc::c_char = std::ptr::null_mut();')==1
patched=original.replace('let p: *mut libc::c_char = std::ptr::null_mut();','let mut p: *mut libc::c_char = std::ptr::null_mut();').replace('                &p,','                &mut p,')
(b/'patched/glib-0.18.5/src/variant_iter.rs').write_text(patched)
(b/'glib-0.18.5-RUSTSEC-2024-0429.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),patched.splitlines(True),fromfile='a/src/variant_iter.rs',tofile='b/src/variant_iter.rs')))

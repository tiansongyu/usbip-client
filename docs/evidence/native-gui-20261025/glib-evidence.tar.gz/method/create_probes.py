from pathlib import Path
import json
b=Path('/tmp/rustusb-gui-glib-remediation-20261025')
compile_cases={
 'normal_use':r'''#![forbid(unsafe_code)]
use glib::prelude::*;
pub fn normal_use() -> Result<(), Box<dyn std::error::Error>> {
    let variant = ["alpha", "beta"].to_variant();
    let first = {
        let mut iter = variant.array_iter_str()?;
        iter.next()
    };
    assert_eq!(first, Some("alpha"));
    Ok(())
}
''',
 'escape_str_next':r'''#![forbid(unsafe_code)]
use glib::prelude::*;
pub fn escape() -> &'static str {
    let variant = ["alpha", "beta"].to_variant();
    variant.array_iter_str().unwrap().next().unwrap()
}
''',
 'escape_str_next_back':r'''#![forbid(unsafe_code)]
use glib::prelude::*;
pub fn escape() -> &'static str {
    let variant = ["alpha", "beta"].to_variant();
    variant.array_iter_str().unwrap().next_back().unwrap()
}
''',
 'escape_str_nth':r'''#![forbid(unsafe_code)]
use glib::prelude::*;
pub fn escape() -> &'static str {
    let variant = ["alpha", "beta"].to_variant();
    variant.array_iter_str().unwrap().nth(1).unwrap()
}
''',
 'escape_str_nth_back':r'''#![forbid(unsafe_code)]
use glib::prelude::*;
pub fn escape() -> &'static str {
    let variant = ["alpha", "beta"].to_variant();
    variant.array_iter_str().unwrap().nth_back(1).unwrap()
}
''',
 'escape_str_last':r'''#![forbid(unsafe_code)]
use glib::prelude::*;
pub fn escape() -> &'static str {
    let variant = ["alpha", "beta"].to_variant();
    variant.array_iter_str().unwrap().last().unwrap()
}
''',
 'escape_iterator':r'''#![forbid(unsafe_code)]
use glib::prelude::*;
pub fn escape() -> glib::VariantStrIter<'static> {
    let variant = ["alpha", "beta"].to_variant();
    variant.array_iter_str().unwrap()
}
''',
 'drop_variant_before_str':r'''#![forbid(unsafe_code)]
use glib::prelude::*;
pub fn escape() {
    let variant = ["alpha", "beta"].to_variant();
    let first = variant.array_iter_str().unwrap().next().unwrap();
    drop(variant);
    println!("{first}");
}
''',
}
for variant in ['original','patched']:
 for case,source in compile_cases.items():
  p=b/'probes'/f'{variant}-{case}'; (p/'src').mkdir(parents=True,exist_ok=True)
  (p/'src/lib.rs').write_text(source)
  (p/'Cargo.toml').write_text(f'''[package]
name = "glib-{variant}-{case.replace('_','-')}-probe"
version = "0.0.0"
edition = "2024"
publish = false

[workspace]

[dependencies]
glib = {{ path = "{b/variant/'glib-0.18.5'}" }}
''')
p=b/'probes/patched-runtime';(p/'src').mkdir(parents=True,exist_ok=True)
(p/'Cargo.toml').write_text(f'''[package]
name = "glib-patched-runtime-probe"
version = "0.0.0"
edition = "2024"
publish = false

[workspace]

[dependencies]
glib = {{ path = "{b/'patched/glib-0.18.5'}" }}
''')
(p/'src/lib.rs').write_text(r'''#![forbid(unsafe_code)]
#[cfg(test)]
mod tests {
    use glib::prelude::*;
    use std::error::Error;
    type TestResult = Result<(), Box<dyn Error>>;
    #[test]
    fn forward_and_borrow_after_iterator_drop() -> TestResult {
        let variant = ["alpha", "βήτα", "", "終"].to_variant();
        let first = {
            let mut iter = variant.array_iter_str()?;
            assert_eq!(iter.size_hint(), (4, Some(4)));
            let first = iter.next();
            assert_eq!(iter.len(), 3);
            first
        };
        assert_eq!(first, Some("alpha"));
        assert_eq!(variant.array_iter_str()?.collect::<Vec<_>>(), ["alpha", "βήτα", "", "終"]);
        Ok(())
    }
    #[test]
    fn reverse_and_double_ended_mix() -> TestResult {
        let variant = ["0", "1", "2", "3"].to_variant();
        let mut iter = variant.array_iter_str()?;
        assert_eq!(iter.next_back(), Some("3"));
        assert_eq!(iter.next(), Some("0"));
        assert_eq!(iter.next_back(), Some("2"));
        assert_eq!(iter.next(), Some("1"));
        assert_eq!(iter.next(), None);
        assert_eq!(iter.next_back(), None);
        assert_eq!(iter.len(), 0);
        assert_eq!(variant.array_iter_str()?.rev().collect::<Vec<_>>(), ["3", "2", "1", "0"]);
        Ok(())
    }
    #[test]
    fn nth_and_nth_back() -> TestResult {
        let variant = ["0", "1", "2", "3", "4", "5"].to_variant();
        let mut iter = variant.array_iter_str()?;
        assert_eq!(iter.nth(1), Some("1"));
        assert_eq!(iter.len(), 4);
        assert_eq!(iter.next(), Some("2"));
        assert_eq!(iter.nth_back(2), Some("3"));
        assert_eq!(iter.len(), 0);
        assert_eq!(iter.next(), None);
        assert_eq!(iter.next_back(), None);
        Ok(())
    }
    #[test]
    fn nth_limits_and_overflow_are_fused() -> TestResult {
        let variant = ["0", "1", "2"].to_variant();
        for n in [3, usize::MAX] {
            let mut iter = variant.array_iter_str()?;
            assert_eq!(iter.nth(n), None);
            assert_eq!(iter.next(), None);
            assert_eq!(iter.next_back(), None);
            let mut iter = variant.array_iter_str()?;
            assert_eq!(iter.nth_back(n), None);
            assert_eq!(iter.next(), None);
            assert_eq!(iter.next_back(), None);
        }
        let mut iter = variant.array_iter_str()?;
        assert_eq!(iter.next(), Some("0"));
        assert_eq!(iter.nth(usize::MAX), None);
        assert_eq!(iter.next_back(), None);
        Ok(())
    }
    #[test]
    fn last_after_partial_iteration_and_iterator_drop() -> TestResult {
        let variant = ["0", "1", "2", "3"].to_variant();
        let last = variant.array_iter_str()?.last();
        assert_eq!(last, Some("3"));
        let mut iter = variant.array_iter_str()?;
        assert_eq!(iter.next_back(), Some("3"));
        assert_eq!(iter.next(), Some("0"));
        assert_eq!(iter.last(), Some("2"));
        Ok(())
    }
    #[test]
    #[allow(clippy::iter_nth_zero, reason = "Exercises nth itself on an empty iterator")]
    fn empty_iterator_and_type_mismatch() -> TestResult {
        let variant = Vec::<String>::new().to_variant();
        let mut iter = variant.array_iter_str()?;
        assert_eq!(iter.len(), 0);
        assert_eq!(iter.next(), None);
        assert_eq!(iter.next_back(), None);
        assert_eq!(iter.nth(0), None);
        assert_eq!(iter.nth_back(0), None);
        assert_eq!(iter.last(), None);
        assert!(42_u32.to_variant().array_iter_str().is_err());
        Ok(())
    }
}
''')
(b/'probes/expected.json').write_text(json.dumps({case: ('accept' if case=='normal_use' else 'reject') for case in compile_cases},indent=2)+'\n')

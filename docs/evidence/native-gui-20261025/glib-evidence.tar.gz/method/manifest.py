from pathlib import Path
import json,hashlib
b=Path('/tmp/rustusb-gui-glib-remediation-20261025')
rows=json.loads((b/'results.json').read_text())
for row in rows:
 name=row['name']
 if name.startswith('original-') or (name.startswith('patched-') and any(x in name for x in ['normal_use','escape_','drop_variant'])):
  p=b/'probes'/name/'src/lib.rs'
 elif name.startswith('patched-upstream-'):
  p=b/'patched/glib-0.18.5/src/variant_iter.rs'
 elif name in ['patched-runtime-debug','patched-runtime-release','patched-caller-clippy']:
  p=b/'snapshots/patched-runtime-before-clippy.rs'
 elif name in ['patched-caller-clippy-final','patched-runtime-release-final','patched-runtime-fmt']:
  p=b/'snapshots/patched-runtime-before-fmt.rs'
 else:p=b/'probes/patched-runtime/src/lib.rs'
 row['input_source']={'path':str(p.relative_to(b)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(b/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
files=[]
for p in sorted(b.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(b)
 if rel.parts[0] in ['target','cargo-home'] or str(rel) in ['manifest.json','SHA256SUMS']:continue
 data=p.read_bytes();files.append({'path':str(rel),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(b/'manifest.json').write_text(json.dumps({'scope':'Public source, methods, probe sources/locks, raw stdout/results and digests; excludes isolated cargo cache and compiled artifacts. Build/runtime ELF hashes and actual system link paths are recorded separately in integrity.json.','files':files},indent=2)+'\n')
(b/'SHA256SUMS').write_text(''.join(f'{x["sha256"]}  {x["path"]}\n' for x in files))
print(json.dumps({'files':len(files),'bytes':sum(x['bytes'] for x in files),'result_commands':len(rows)},indent=2))

import pathlib,subprocess,os,json,time,urllib.request,hashlib,signal
base=pathlib.Path('/tmp/rustusb-gui-host-smoke-20261025d');base.mkdir(exist_ok=False)
fixture='/run/rustusb-gui-smoke-20261025d'
manifest={'schema_version':1,'broker_uid':2000,'helper_socket':fixture+'/helper.sock','control_directory':fixture+'/control','data_directory':fixture+'/data','profiles':[{'id':'observe','backend':'native','config':fixture+'/unused.json'}],'operators':[{'uid':1000,'profiles':['observe'],'actions':['read','audit']}]}
subprocess.run(['sudo','-n','python3','-c','import pathlib,sys; p=pathlib.Path(sys.argv[1]);p.mkdir(mode=0o755);(p/"manifest.json").write_text(sys.argv[2]);(p/"manifest.json").chmod(0o644)',fixture,json.dumps(manifest)],check=True)
program=pathlib.Path('apps/rustusb-gui/target/release/rustusb-gui').resolve()
env=dict(os.environ,DISPLAY=':188',GDK_BACKEND='x11',TAURI_WEBVIEW_AUTOMATION='true',LIBGL_ALWAYS_SOFTWARE='1')
logs=[];processes=[]
def start(args,name):
 f=(base/name).open('wb');logs.append(f);p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT);processes.append(p);return p
def http(method,path,body=None):
 req=urllib.request.Request('http://127.0.0.1:15888'+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'},method=method)
 try:
  with urllib.request.urlopen(req,timeout=35) as r:return json.load(r)
 except urllib.error.HTTPError as e:
  (base/'http-error.json').write_bytes(e.read());raise
try:
 start(['Xvfb',':188','-screen','0','1280x900x24','-nolisten','tcp'],'xvfb.log')
 driver=start(['/tmp/rustusb-gui-native-tools-20261025/extracted/usr/bin/WebKitWebDriver','--host=127.0.0.1','--port=15888'],'driver.log')
 for _ in range(100):
  try:http('GET','/status');break
  except Exception:time.sleep(.1)
 body={'capabilities':{'alwaysMatch':{'browserName':'MiniBrowser','webkitgtk:browserOptions':{'binary':str(program),'args':['--manifest',fixture+'/manifest.json','--settings-directory','/home/ubuntu/.config/rustusb-gui-smoke-20261025d']}}}}
 (base/'new-session-request.json').write_text(json.dumps(body,indent=2))
 session=http('POST','/session',body);(base/'session.json').write_text(json.dumps(session,indent=2));sid=session['value']['sessionId']
 for _ in range(100):
  result=http('POST',f'/session/{sid}/execute/sync',{'script':'return {text:document.body.innerText,url:location.href,bridge:!!window.__TAURI__};','args':[]})
  if 'Agent stale' in result['value']['text']:break
  time.sleep(.1)
 (base/'page.json').write_text(json.dumps(result,indent=2))
 screenshot=http('GET',f'/session/{sid}/screenshot');import base64;(base/'screen.png').write_bytes(base64.b64decode(screenshot['value']))
 assert result['value']['bridge'] and 'tauri://localhost' in result['value']['url']
 assert 'Local devices' in result['value']['text'] and 'Agent stale' in result['value']['text']
 owned=[]
 for p in pathlib.Path('/proc').iterdir():
  if p.name.isdigit():
   try:
    if (p/'exe').resolve()==program:
     (base/f'pid-{p.name}.status').write_bytes((p/'status').read_bytes());owned.append(int(p.name))
   except (PermissionError,FileNotFoundError):pass
 assert len(owned)==1
 os.kill(owned[0],signal.SIGTERM)
 for _ in range(200):
  if not pathlib.Path('/proc',str(owned[0])).exists():break
  time.sleep(.05)
 assert not pathlib.Path('/proc',str(owned[0])).exists()
 (base/'result.json').write_text(json.dumps({'result':'PASS','scope':'development native host smoke, unavailable agent only','pid':owned[0],'binary_sha256':hashlib.sha256(program.read_bytes()).hexdigest()}))
finally:
 for p in reversed(processes):
  if p.poll() is None:p.terminate()
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 for f in logs:f.close()

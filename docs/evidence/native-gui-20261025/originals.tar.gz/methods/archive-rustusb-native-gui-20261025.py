import pathlib,json,hashlib,tarfile,shutil,io
root=pathlib.Path('/home/ubuntu/github/usbip-client');out=root/'docs/evidence/native-gui-20261025';out.mkdir(parents=True,exist_ok=False)
selected={}
def add_file(path,name):
 p=pathlib.Path(path);data=p.read_bytes();assert not data.startswith(b'\x7fELF');assert '.private'not in p.parts and 'target'not in p.parts
 selected[name]=(p,data)
def add_dir(path,name):
 for p in sorted(pathlib.Path(path).rglob('*')):
  if p.is_file():add_file(p,name+'/'+str(p.relative_to(path)))
for stem in ['b15dd113','7c4eb3cd','viewport']:
 add_dir('/tmp/rustusb-native-gui-gates-'+stem+'-20261025','software/'+stem)
for name in ['b15dd113','7c4eb3cd','third','fourth','final','sixth','viewport']:
 base='/tmp/rustusb-native-gui-qemu-'+name+'-20261025';add_dir(base,'qemu/'+name);add_file(base+'-runner.log','qemu/'+name+'/original-runner.log')
for name,suffix in [('original-parent-failure',''),('final','-final')]:
 base='/tmp/rustusb-shared-frontend-tui-qemu'+suffix+'-20261025';add_dir(base,'tui/'+name)
 log=base+('-pythonpath-runner.log'if suffix else '-runner.log');add_file(log,'tui/'+name+'/original-runner.log')
for p in pathlib.Path('/tmp').glob('rustusb-gui-*-20261025.log'):
 if p.is_file():add_file(p,'development/logs/'+p.name)
for name in ['', 'b','c','d','e','f','g']:
 method=pathlib.Path('/tmp/rustusb-gui-host-smoke-20261025'+name+'.py')
 if method.exists():add_file(method,'development/host-'+(name or 'a')+'/method.py')
 base=pathlib.Path('/tmp/rustusb-gui-host-smoke-20261025'+name)
 if base.exists():
  for p in base.iterdir():
   # Host inventories/serial metadata/screenshots remain private, never in the public archive.
   if p.is_file()and p.name not in ['page.json','screen.png']:add_file(p,'development/host-'+(name or 'a')+'/'+p.name)
  private=base/'.private';private.mkdir(exist_ok=True)
  for n in ['page.json','screen.png']:
   if (base/n).exists():shutil.move(base/n,private/n)
for n in ['download.log','tauri-driver-src-index.json','tauri-driver-main.rs','tauri-driver-server.rs','licenses.json','cargo-metadata.json','root-normal-tree.txt']:
 add_file(pathlib.Path('/tmp/rustusb-gui-native-tools-20261025')/n,'inventory/'+n)
for p in pathlib.Path('/tmp').glob('run-rustusb-native-gui-*-20261025.py'):add_file(p,'methods/'+p.name)
for p in [pathlib.Path('/tmp/run-rustusb-native-gui-gates-20261025.py'),pathlib.Path(__file__)]:add_file(p,'methods/'+p.name)
add_dir('/tmp/rustusb-gui-fourth-parent-diagnostic-20261025','post-failure-diagnostic-only')
manifest=[{'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for n,(p,data)in sorted(selected.items())]
archive=out/'originals.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for n,(p,data)in sorted(selected.items()):
  info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as t:
 assert len(t.getmembers())==len(manifest)
 for row in manifest:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256']
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for n in ['glib-evidence.tar.gz','manifest.json','receipt.json']:
 name='glib-'+n if n!='glib-evidence.tar.gz'else n
 shutil.copyfile(pathlib.Path('/tmp/rustusb-gui-component-archive-20261025')/n,out/name)
receipt={'original_files':len(manifest),'original_bytes':sum(r['bytes']for r in manifest),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'scope':'Original source/commands/logs/results, including failures; no private keys, host device inventory, ELF or target trees. Same-author integrity review, not independent security audit.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt)

import pathlib,subprocess,json,hashlib,datetime,re,importlib.util
root=pathlib.Path('/home/ubuntu/github/usbip-client');out=pathlib.Path('/tmp/rustusb-native-gui-gates-b15dd113-20261025');out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('gui_inputs',root/'scripts/qemu_gui/run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
source=m.inputs();head=git('rev-parse','HEAD');status=git('status','--porcelain');assert not status
summary={'head':head,'status_before':status,'inputs':source,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'FAIL','commands':[]}
try:
 for name,cmd in [('core',['bash','scripts/check.sh']),('gui',['bash','scripts/check-gui.sh'])]:
  with (out/(name+'.log')).open('wb')as stream:r=subprocess.run(cmd,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
  log=(out/(name+'.log')).read_text();counts=[tuple(map(int,v))for v in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)]
  summary['commands'].append({'name':name,'argv':cmd,'exit':r.returncode,'passed':sum(v[0]for v in counts),'failed':sum(v[1]for v in counts),'ignored':sum(v[2]for v in counts)})
  assert r.returncode==0
 summary['binaries']={n:{'sha256':m.digest(p),'bytes':p.stat().st_size}for n,p in {'rustusb':root/'target/release/rustusb','rustusb-helper':root/'target/release/rustusb-helper','rustusb-gui':root/'apps/rustusb-gui/target/release/rustusb-gui'}.items()};summary['result']='PASS'
finally:
 summary['guards']={'inputs':m.inputs()==source,'head':git('rev-parse','HEAD')==head,'status':git('status','--porcelain')==status}
 if not all(summary['guards'].values()):summary['result']='FAIL'
 (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert summary['result']=='PASS'

import http.server,json,os,pathlib,urllib.parse
root=pathlib.Path('/home/ubuntu/github/usbip-client/website')
class Handler(http.server.SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(root),**kw)
 def do_GET(self):
  self.nojs=self.path.startswith('/nojs/')
  if self.nojs:self.path=self.path[len('/nojs'):]
  if not self.path.startswith('/usbip-client/'):
   self.send_error(404);return
  self.path=self.path[len('/usbip-client'):]
  super().do_GET()
 def end_headers(self):
  if getattr(self,'nojs',False):self.send_header('Content-Security-Policy',"script-src 'none'")
  super().end_headers()
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
pathlib.Path('/tmp/rustusb-arm64-virtual-preview-20261026.json').write_text(json.dumps({'pid':os.getpid(),'port':server.server_port})+'\n')
print(server.server_port,flush=True)
try:server.serve_forever()
except KeyboardInterrupt:pass
finally:server.server_close()

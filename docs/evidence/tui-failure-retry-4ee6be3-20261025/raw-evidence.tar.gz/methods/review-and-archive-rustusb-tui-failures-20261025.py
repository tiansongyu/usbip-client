import pathlib,json,hashlib,subprocess,re,base64,tarfile,io,shutil
repo=pathlib.Path('/home/ubuntu/github/usbip-client');target=repo/'docs/evidence/tui-failure-retry-4ee6be3-20261025'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=repo)
assert not git('status','--porcelain').strip();target.mkdir(exist_ok=False)
software=pathlib.Path('/tmp/rustusb-tui-failure-software-4ee6be3-20261025');s=read(software/'summary.json')
assert s['result']=='PASS' and s['inputs_unchanged'] and all(c['exit_code']==0 for c in s['commands'])
counts={name:sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',(software/(name+'.log')).read_text())))for name in ['test-default','test-all','vendor']}
assert counts=={'test-default':418,'test-all':514,'vendor':20},counts
for name in counts:
 results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (software/(name+'.log')).read_text())
 assert results and all(failed=='0' and ignored=='0' for _,failed,ignored in results)
for name,item in s['inputs_before'].items():
 data=(repo/name).read_bytes();assert sha(data)==item['sha256'] and git('show',s['head']+':'+name)==data
all_binary=next(c['binaries']for c in s['commands']if c['name']=='release-all')
old=read(repo/'docs/evidence/tui-settings-actions-5584c5b-20261024/software-summary.json')
old_binary=next(c['binaries']for c in old['commands']if c['name']=='release-all')
roots=[software];rows=[];passed_pty=0;red_pty=0
cases=[('red','ipv4','/tmp/rustusb-tui-failure-red-ipv4-20261025')]
cases +=[('new',f,'/tmp/rustusb-tui-failure-'+f+'-20261025')for f in ['ipv4','ipv6']]
cases +=[('regression',f,'/tmp/rustusb-tui-failure-actions-regression-'+f+'-20261025')for f in ['ipv4','ipv6']]
for kind,family,path in cases:
 root=pathlib.Path(path);q=read(root/'summary.json');roots.append(root)
 assert q['result']==('FAIL'if kind=='red'else'PASS')
 if kind=='red':
  assert q['error']=='RuntimeError: retained exact job did not visibly transition current/stale/current'
  assert read(root/'original-base-verifier-diagnostic.json')['facts']['assertion_count']==264
 else:
  assert q['facts']['assertion_count']==264 and q['facts']['io_rounds']==3
  if kind=='new':assert q['facts']['tui_failures']['unknown_start_ptys']==2
 assert q['guest_exit_codes']=={'server':0,'client':0} and all(q[k]for k in ['source_guard','binary_guard','head_guard','clean_guard'])
 binary=old_binary if kind=='red'else all_binary
 assert q['binary_sha256']=={n:i['sha256']for n,i in binary.items()}
 for name,item in q['source_inputs'].items():
  data=(root/'source'/name).read_bytes();assert sha(data)==item['sha256'] and len(data)==item['bytes'] and git('show',q['head']+':'+name)==data
  if kind!='red':assert (repo/name).read_bytes()==data
 children=0
 for role in ['server','client']:
  folder=root/(role+'-artifacts')
  for result in sorted(folder.glob('tui-*.result')):
   prefix=result.name.removesuffix('.result');fields=dict(line.split('=',1)for line in result.read_text().splitlines())
   assert fields['uid']=='1000' and fields['exit']=='0' and all(fields[k]=='1'for k in ['waited','raw_observed','resized','restored','entered','left'])
   status=(folder/(prefix+'.status')).read_text();assert re.search(r'^Uid:\s+1000\s+1000\s+1000\s+1000$',status,re.M)
   assert re.search(r'^Pid:\s+'+fields['pid']+r'$',status,re.M)
   assert all(re.search(r'^'+cap+r':\s+0000000000000000$',status,re.M)for cap in ['CapInh','CapPrm','CapEff','CapAmb'])
   assert(folder/(prefix+'.exe-sha256')).read_text().split()[0]==binary['rustusb']['sha256']
   tty=dict(line.split('=',1)for line in (folder/(prefix+'.termios')).read_text().splitlines());assert all(tty['before_'+k]==tty['after_'+k]for k in ['flags','speeds','cc']);children+=1
  final=read(folder/('agent-stopped-2.json'if role=='server'else'agent-final.json'));journal=read(folder/('root-stopped-2.json'if role=='server'else'root-final.json'))
  assert all(x['terminal']and x['cleanup']=='verified'for x in final['sessions']);assert journal['records']==[]and journal['exports']==[]
  for profile in (['server']if role=='server'else['hid','serial']):
   for epoch in [1,2]:
    receipt=read(folder/f'start-{profile}-{epoch}.json');assert receipt['response']['result']=='started'and receipt['response']['replayed']
    prefix=f'tui-start-{profile}-{epoch}'
    before=read(folder/(prefix+'-before.json'));after=read(folder/(prefix+'-after.json'));retry=read(folder/(prefix+'-after-retry.json'));prior={r['id']for r in before['requests']};new=[r for r in after['requests']if r['id']not in prior]
    assert len(new)==1 and new[0]['uid']==1000 and new[0]['profile']==profile and new[0]['job_id']==receipt['response']['job']['id']and after['requests']==retry['requests']
  if kind!='regression':
   profile='server'if role=='server'else'hid';prefix=f'tui-start-{profile}-1'
   before=read(folder/(prefix+'-before-issued.json'));timeout=read(folder/(prefix+'-after-timeout.json'));admit=read(folder/(prefix+'-after-admit.json'));retry=read(folder/(prefix+'-after-retry.json'))
   assert before==timeout and admit['requests']==retry['requests']and {j['id']for j in admit['jobs']}=={j['id']for j in retry['jobs']}
   assert read(folder/(prefix+'-before-read.json'))==read(folder/(prefix+'-after-read-timeout.json'))
   identities=[]
   for phase in ['before','paused','timeout','resumed','read-paused','read-timeout','read-resumed']:
    status=(folder/(prefix+'-agent-'+phase+'.status')).read_text();assert re.search(r'^Uid:\s+2000\s+2000\s+2000\s+2000$',status,re.M)
    if phase in ['paused','timeout','read-paused','read-timeout']:assert re.search(r'^State:\s+T',status,re.M)
    stat=(folder/(prefix+'-agent-'+phase+'.stat')).read_text();identities.append((stat.split(' ',1)[0],stat[stat.rfind(')')+2:].split()[19]))
   assert len(set(identities))==1
 assert children==19
 if kind=='red':red_pty+=children
 else:passed_pty+=children
 rows.append({'name':root.name,'head':q['head'],'result':q['result'],'inputs':len(q['source_inputs']),'pty':children,'guest_exit_codes':q['guest_exit_codes']})
 shutil.copyfile(root/'summary.json',target/(root.name+'-summary.json'))
assert passed_pty==76 and red_pty==19
shutil.copyfile(software/'summary.json',target/'software-summary.json')
entries=[];payloads={}
def add(p,name):
 data=p.read_bytes();assert not data.startswith(b'\x7fELF')and not re.search(rb'-----BEGIN (?:RSA |EC |ENCRYPTED )?PRIVATE KEY-----\r?\n',data)
 assert '.private'not in str(p)and 'target/'not in name and not p.name.endswith('-key.der')
 entries.append({'path':name,'original':str(p),'bytes':len(data),'sha256':sha(data)});payloads[name]=data
for root in roots:
 for p in sorted(root.rglob('*')):
  if p.is_file():add(p,root.name+'/'+str(p.relative_to(root)))
methods=[pathlib.Path(__file__),pathlib.Path('/tmp/run-rustusb-tui-failure-gate-20261025.py'),pathlib.Path('/tmp/rustusb-tui-failure-product-fix-20261025.py'),pathlib.Path('/tmp/rustusb-tui-failure-product-test-20261025.rs'),pathlib.Path('/tmp/rustusb-tui-failure-generated-init-preflight-20261025.sh')]
methods += sorted(p for p in pathlib.Path('/tmp').glob('rustusb-tui-failure-*-20261025*.log') if 'archive-review' not in p.name)
for p in methods:add(p,'methods/'+p.name)
blocks=0
for root in roots[1:]:
 for role in ['server','client']:
  for m in re.finditer(rb'SECURE_ARTIFACT_BEGIN ([^\n]+) (\d+)\n(.*?)SECURE_ARTIFACT_END \1\n',(root/(role+'-evidence.log')).read_bytes(),re.S):
   data=base64.b64decode(m[3]);assert len(data)==int(m[2])and data==(root/(role+'-artifacts')/m[1].decode()).read_bytes();blocks+=1
archive=target/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for name,data in sorted(payloads.items()):
  info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 assert len(tar.getmembers())==len(entries)
 for m in tar.getmembers():assert sha(tar.extractfile(m).read())==sha(payloads[m.name])
for e in entries:assert sha(pathlib.Path(e['original']).read_bytes())==e['sha256']
manifest={'result':'PASS','files':entries,'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'software_counts':counts,'software_inputs':len(s['inputs_before']),'qemu':rows,'passed_pty':passed_pty,'failed_run_pty':red_pty,'guest_base64_blocks_redecoded':blocks,'scope':'Same-author raw/source/identity review, no imported run verifier and no new USB execution/security audit. Original red remains FAIL. Four final paired runs and 76 actual PTYs at exact software source; SIGSTOP fault is not wire-loss or permanent kernel/FS blocking. No ELF, private keys, target or host-private discovery output.'}
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:manifest[k]for k in ['result','software_counts','software_inputs','qemu','passed_pty','failed_run_pty','guest_base64_blocks_redecoded','archive']}))

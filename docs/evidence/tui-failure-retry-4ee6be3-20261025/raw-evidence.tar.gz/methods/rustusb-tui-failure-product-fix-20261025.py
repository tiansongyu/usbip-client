from pathlib import Path
p=Path('crates/rustusb-tui/src/state.rs');s=p.read_text();anchor='    pub fn clear_profile(&mut self) {'
assert s.count(anchor)==1
s=s.replace(anchor,'''    pub fn agent_stale(&mut self) {
        // These pages are retained observations, never a current service receipt.
        self.jobs_status = "Stale: agent unavailable; retained page".into();
        self.sessions_status = "Stale: agent unavailable; retained page".into();
        self.audit_status = "Stale: agent unavailable; retained page".into();
        self.journal = None;
        self.health.clear();
    }
'''+anchor,1);p.write_text(s)
p=Path('crates/rustusb-tui/src/worker.rs');s=p.read_text();anchor='''                    self.reset().await;
                }
                return;
'''
assert s.count(anchor)==1
s=s.replace(anchor,'''                    self.reset().await;
                } else {
                    self.view.agent_stale();
                }
                return;
''',1);p.write_text(s)

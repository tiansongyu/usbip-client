import pathlib,urllib.request,json,hashlib,datetime,concurrent.futures
root=pathlib.Path('/tmp/rustusb-storage-usb-20261026'); manifest=json.loads((root/'sources.json').read_text())
paths=['drivers/usb/core/generic.c','drivers/usb/core/message.c','drivers/usb/usbip/usbip_common.h','drivers/usb/usbip/vhci_hcd.c','drivers/usb/storage/uas-detect.h','block/blk-core.c','block/bdev.c','fs/block_dev.c','drivers/scsi/scsi_ioctl.c']
jobs=[(f'linux-{v}/{p}',f'https://raw.githubusercontent.com/torvalds/linux/{v}/{p}') for v in ['v5.15','v6.8'] for p in paths]
def get(pair):
 name,url=pair
 try:
  data=urllib.request.urlopen(url,timeout=30).read(); dest=root/name; dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  return {'path':name,'url':url,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'fetched_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ok'}
 except Exception as e:return {'path':name,'url':url,'status':'error','error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: results=list(pool.map(get,jobs))
(root/'sources.json').write_text(json.dumps(manifest+results,indent=2)+'\n')
for x in results:
 if x['status']!='ok':print(x)
print('Downloaded',sum(x['status']=='ok' for x in results),'of',len(results))

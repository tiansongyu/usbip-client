import pathlib,urllib.request,json,hashlib,datetime,concurrent.futures
root=pathlib.Path('/tmp/rustusb-storage-usb-20261026'); manifest=json.loads((root/'sources.json').read_text())
jobs=[]
for v in ['v5.15','v6.8']:
 for p in ['block/fops.c','Documentation/usb/authorization.rst','drivers/usb/core/sysfs.c','drivers/usb/core/hub.c','drivers/usb/core/devio.c']:
  jobs.append((f'linux-{v}/{p}',f'https://raw.githubusercontent.com/torvalds/linux/{v}/{p}'))
for p in ['hw/usb/dev-storage-bot.c','hw/usb/dev-storage-classic.c','block/block-backend.c','include/hw/usb/msd.h']:
 jobs.append((f'qemu-v6.2.0/{p}',f'https://raw.githubusercontent.com/qemu/qemu/v6.2.0/{p}'))
def get(pair):
 name,url=pair
 try:
  data=urllib.request.urlopen(url,timeout=30).read();dest=root/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  return {'path':name,'url':url,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'fetched_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ok'}
 except Exception as e:return {'path':name,'url':url,'status':'error','error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:r=list(pool.map(get,jobs))
(root/'sources.json').write_text(json.dumps(manifest+r,indent=2)+'\n')
for x in r:
 if x['status']!='ok':print(x)
print('Downloaded',sum(x['status']=='ok' for x in r),'of',len(r))

import pathlib, urllib.request, concurrent.futures, hashlib, json, datetime
root=pathlib.Path('/tmp/rustusb-storage-usb-20261026')
linux=['COPYING','LICENSES/preferred/GPL-2.0','drivers/usb/storage/usb.c','drivers/usb/storage/uas.c','drivers/usb/storage/scsiglue.c','drivers/usb/storage/transport.c','drivers/usb/usbip/stub_dev.c','drivers/usb/usbip/stub_main.c','drivers/usb/usbip/stub_rx.c','drivers/usb/usbip/stub_tx.c','drivers/usb/core/driver.c','drivers/scsi/sd.c','drivers/scsi/scsi_sysfs.c','drivers/scsi/hosts.c','drivers/scsi/scsi_scan.c','drivers/scsi/scsi_lib.c','tools/usb/usbip/src/usbip_bind.c','tools/usb/usbip/src/usbip_unbind.c','block/ioctl.c','block/genhd.c']
qemu=['COPYING','LICENSE','hw/usb/dev-storage.c','hw/usb/dev-uas.c','hw/scsi/scsi-disk.c','hw/scsi/scsi-bus.c','docs/system/devices/usb.rst','qemu-options.hx','block/blkdebug.c','docs/devel/blkdebug.txt']
jobs=[]
for ver in ['v5.15','v6.8']:
 for path in linux: jobs.append((f'linux-{ver}/{path}',f'https://raw.githubusercontent.com/torvalds/linux/{ver}/{path}'))
for path in qemu: jobs.append((f'qemu-v6.2.0/{path}',f'https://raw.githubusercontent.com/qemu/qemu/v6.2.0/{path}'))
for repo,tag in [('torvalds/linux','v5.15'),('torvalds/linux','v6.8'),('qemu/qemu','v6.2.0')]:
 jobs.append((f'metadata/{repo.replace("/","-")}-{tag}.json',f'https://api.github.com/repos/{repo}/commits/{tag}'))
def fetch(pair):
 name,url=pair
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'RustUSB-source-research/1'})
  with urllib.request.urlopen(req,timeout=40) as resp: data=resp.read()
  path=root/name; path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(data)
  return {'path':name,'url':url,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'fetched_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ok'}
 except Exception as e: return {'path':name,'url':url,'status':'error','error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool: result=list(pool.map(fetch,jobs))
(root/'sources.json').write_text(json.dumps(result,indent=2)+'\n')
for item in result:
 if item['status']!='ok': print(item)
print('Downloaded',sum(i['status']=='ok' for i in result),'of',len(result))

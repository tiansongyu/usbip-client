# USB storage handoff research for RustUSB

Status: research / proposed design input, 2026-10-26. Repository inspected at clean `2eca4522104eef7ccbf23dffba2ef1120bf4349c`. No repository edits, builds, QEMU runs, device opens, module changes, service changes, or mounts were performed. Commands below are unexecuted test plans.

## Source identity and method

Fixed upstreams:

| Upstream | Tag | Commit | Commit timestamp |
| --- | --- | --- | --- |
| Linux | v5.15 | 8bb7eca972ad531c9b149c0a51ab43a417385813 | 2021-10-31T20:53:10Z |
| Linux | v6.8 | e8f897f4afef0031fe618a8e94127a0934896aba | 2024-03-10T20:38:09Z |
| QEMU | v6.2.0 | 44f28df24767cf9dca1ddc9b23157737c4cbb645 | 2021-12-14T20:35:01Z |

Fetched selected original source files directly from official GitHub mirrors using Python urllib. `fetch.py`, `fetch_extra.py`, and `fetch_last.py` retain the method. `sources.json` has URL, SHA-256, byte count, fetch time, and success/error for every request; `metadata/` retains official commit API responses. All original source is under `linux-v5.15/`, `linux-v6.8/`, and `qemu-v6.2.0/`. Two attempted historical `fs/block_dev.c` paths returned 404 and are preserved as failed requests; the actual relevant files are `block/bdev.c` and `block/fops.c`.

2026-qualified web searches located the current official QEMU USB page, but claims below use the fixed v6.2.0 source/documentation. Search queries were `2026 site:git.kernel.org linux usb-storage usb_stor_disconnect usbip stub_disconnect` and `2026 site:qemu.org docs usb-bot usb-uas scsi-hd readonly`. Current page: https://www.qemu.org/docs/master/system/devices/usb.html . It is only a locator, not evidence that v6.2 behavior changed or current stable support was audited.

Linux COPYING and LICENSES/preferred/GPL-2.0, and QEMU COPYING and LICENSE are retained. These are research copies, not code proposed for copying into the MIT Rust implementation; per-file SPDX/header terms remain authoritative. No benchmarking or hardware experiments occurred. Distribution Ubuntu kernels may carry patches; actual guest uname/package/source provenance remains an execution prerequisite.

## Main design consequences

1. A local block-device read-only flag is not USB-side write protection. It does not become a USB/IP policy and cannot protect data from a remote raw SCSI command.
2. Unbinding a storage/USB driver is not a checked cache-flush acknowledgement. BOT and UAS have materially different teardown behavior; both require a prior, explicit successful quiesce/flush step for a clean writable handoff.
3. A safe writable source handoff needs a fence that excludes **all** new/old local block, SCSI generic/bsg, USBFS, filesystem, and mapping users across audit, flush, driver removal, and transfer of USB ownership. A `/proc` scan plus userspace `O_EXCL` is not such a fence (see the separate ownership research).
4. Every LUN and partition, not only the first disk, belongs in the audit. A missing LUN/block node can be an incomplete scan, absent medium, unsupported peripheral, or failed discovery; absence is not positive safety proof.
5. Kernel transport cleanup, remote filesystem/cache state, device persistence, source re-enumeration, and permission to resume writing are separate facts. The existing exact owner/Root proof can prove resource release without proving a clean storage handoff.
6. Linux v5.15/v6.8 VHCI has no implemented USB streams. High-speed (USB2) UAS is a separate candidate from SuperSpeed UAS; do not claim USB3 UAS support from BOT or USB2 results.
7. First production increment can truthfully report bounded root-only observations and busy/unknown reasons while retaining the existing export denial. That is a useful prerequisite, not completed storage sharing. A full supported writable export path remains the eventual objective.

## Linux source findings

### A. What Native `usbip bind` actually changes

The user-space utility unbinds the **USB device driver**, then adds `match_busid`, then binds `usbip-host`; it does not perform a mount/open-handle/LUN check or explicit SCSI sync. See [v6.8 usbip_bind.c lines 59–177](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/tools/usb/usbip/src/usbip_bind.c#L59) and corresponding v5.15 file.

The generic USB disconnect unconfigures the whole device through `usb_set_configuration(udev, -1)` ([v6.8 generic.c 269–277](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/generic.c#L269)). `usb_disable_device` unregisters every active interface and thereby runs their disconnect callbacks, then disables endpoints ([message.c 1381–1439](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/message.c#L1381)). This is whole-device handoff, including composite siblings, not a selected-LUN export.

Stub probe checks `match_busid`, rejects hubs/VHCI loops, and claims the hub port ([stub_dev.c 310–394](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/usbip/stub_dev.c#L310)). Raw received URBs are submitted to the USB device ([stub_rx.c 455–605](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/usbip/stub_rx.c#L455)); this path does not consult an old source `/dev/sdX` RO flag. Remote SET_INTERFACE and SET_CONFIGURATION reach the actual device (same file 103–147, 170–188). Audit all configurations/alternates and keep identity/configuration constraints explicit.

On unexport, the stock tool writes usbip-host unbind, removes match, then writes `rebind` ([usbip_unbind.c 61–91](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/tools/usb/usbip/src/usbip_unbind.c#L61)); kernel rebind uses `device_attach` ([stub_main.c 199–211, 242–271](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/usbip/stub_main.c#L199)). That may re-publish block devices and trigger existing automounters. It is not a safe “keep quarantined” primitive after an uncertain write session. Storage-specific recovery must avoid automatic writable republication until policy and state are established; normal Native non-storage cleanup must remain intact.

Pre-populating `match_busid` alone is **not a proven pre-probe fence**: stub_driver has no `id_table` or `match` (stub_dev.c 527–537); the generic competitor check uses `usb_driver_applicable`, which returns false for such a driver (driver.c 842–855; generic.c 214–239), even though `usb_device_match` allows its probe to decide (driver.c 872–877). Do not infer it prevents the generic driver from configuring first. Dedicated controller `interface_authorized_default=0` before device arrival is a possible separate mechanism experiment, documented in [authorization.rst 95–129](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/Documentation/usb/authorization.rst#L95); it does not solve existing raw USBFS references or make descriptor identity authentic. No such policy was installed/tested here.

### B. BOT and UAS removal/cache behavior

| Path | v5.15 exact lines | v6.8 exact lines | Meaning |
| --- | --- | --- | --- |
| BOT `quiesce_and_remove_host` | usb/storage/usb.c 843–876 | usb/storage/usb.c 831–864 | Cancel scan; `scsi_remove_host` before DISCONNECTING except actual physical disappearance. |
| BOT `soft_unbind=1` | usb/storage/usb.c 1156 | usb/storage/usb.c 1144 | Present device teardown can still submit commands during disconnect. |
| USB generic interface removal | usb/core/driver.c function `usb_unbind_interface` | usb/core/driver.c 431–503 | Non-soft unbind disables interface URBs before callback; soft unbind exception applies only while present. |
| UAS disconnect | usb/storage/uas.c 1198–1223 | usb/storage/uas.c 1199–1224 | Mark resetting, cancel work, kill command/sense/data URBs, zap pending commands, cancel scan, then remove SCSI host. |
| UAS resetting queue branch | usb/storage/uas.c 662–666 | usb/storage/uas.c 657–661 | Commands complete with DID_ERROR while resetting. |
| sd removal | scsi/sd.c 3493–3512 | scsi/sd.c 3799–3811 | Delete gendisk then call shutdown (v6.8 if not already suspended). |
| sd shutdown | scsi/sd.c 3592–3610 | scsi/sd.c 3870–3891 | Only if not runtime suspended, WCE and medium present: issue sync; void caller ignores return. |
| sd sync | scsi/sd.c 1687 onward | scsi/sd.c 1646–1716 | Retry SCSI SYNCHRONIZE CACHE; selected unsupported/disconnected conditions treated as success by shutdown-oriented policy. |

Primary anchors: [BOT v5.15](https://github.com/torvalds/linux/blob/8bb7eca972ad531c9b149c0a51ab43a417385813/drivers/usb/storage/usb.c#L843), [BOT v6.8](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/storage/usb.c#L831), [UAS v5.15](https://github.com/torvalds/linux/blob/8bb7eca972ad531c9b149c0a51ab43a417385813/drivers/usb/storage/uas.c#L1198), [UAS v6.8](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/storage/uas.c#L1199), [sd shutdown v5.15](https://github.com/torvalds/linux/blob/8bb7eca972ad531c9b149c0a51ab43a417385813/drivers/scsi/sd.c#L3592), [sd shutdown v6.8](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/scsi/sd.c#L3870).

Therefore a return from `usbip bind`, a successful sysfs unbind write, or disappearance of `/dev/sdX` does not prove device cache persistence. UAS is especially unsuitable for treating disconnect as the preflush step.

`fsync` on an actual block FD waits file data and calls `blkdev_issue_flush`, but maps `-EOPNOTSUPP` to 0 ([v5.15 block/fops.c 405–425](https://github.com/torvalds/linux/blob/8bb7eca972ad531c9b149c0a51ab43a417385813/block/fops.c#L405), [v6.8 538–557](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/block/fops.c#L538)). `BLKFLSBUF` in v6.8 invokes sync/invalidation then returns 0 without returning sync error ([block/ioctl.c 365–380](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/block/ioctl.c#L365)). Do not use `blockdev --flushbufs` exit 0 as the sole device-cache evidence.

Proposed clean writable handoff requires: filesystem users already closed/unmounted voluntarily; exclusion fence retained; per-LUN checked writeback and checked SCSI sync result (full status, host/driver status, residual and sense, not syscall 0 alone); no new source writes after the flush; actual callback/worker completion before publishing the remote endpoint. Device firmware honesty and power-loss durability remain hardware evidence, not a guarantee from successful commands. Unsupported sync must be an explicit capability/result, not silently upgraded to media-persistence proof. Every blocking syscall retains its actual owner until completion; a timeout does not revoke it.

### C. Read-only has several meanings

`BLKROSET` sets `bdev->bd_read_only` after an optional driver hook ([v5.15 block/ioctl.c 343–359](https://github.com/torvalds/linux/blob/8bb7eca972ad531c9b149c0a51ab43a417385813/block/ioctl.c#L343), [v6.8 383–399](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/block/ioctl.c#L383)). The sd block ops have no set_read_only hook (v5.15 sd.c 1853 onward; v6.8 1978–1991). This is a Linux block-object policy, not a SCSI MODE SELECT command and not a device change.

The sd probe reads MODE SENSE WP, then maps that returned bit into disk RO; failed probes can assume write enabled ([v5.15 sd.c 2620–2673](https://github.com/torvalds/linux/blob/8bb7eca972ad531c9b149c0a51ab43a417385813/drivers/scsi/sd.c#L2620), [v6.8 2772–2823](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/scsi/sd.c#L2772)). Consequently `/sys/block/.../ro` alone cannot identify whether RO came from a local setting or a device report. A sysfs-only inspector should name it **kernel-reported block RO**, with **device-enforced protection unknown**.

Even a real MODE SENSE WP response is a report by firmware; it is not independent proof of immutable media. A physical write-protect switch/controller that rejects every media-mutating path is stronger, but requires a defined hardware trust model. Native USB/IP and transparent USBFS forwarding do not become command-filtering storage gateways. Blocking only WRITE(10) misses WRITE(6/12/16), WRITE SAME, UNMAP, FORMAT, MODE SELECT/vendor behavior and alternate protocols. A future enforcing storage proxy would need a separate audited protocol model and is not implied by this feature.

SCSI ioctl command permission has an explicit CAP_SYS_RAWIO bypass ([v6.8 scsi_ioctl.c 251–255](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/scsi/scsi_ioctl.c#L251)); elevated passthrough is another reason not to describe block RO as a universal write fence. `/dev/sg*`, bsg, USBFS and in-flight URBs belong in ownership research.

### D. Removal, open old objects, and re-enumeration

`scsi_remove_host` synchronizes scan/state, forgets devices and waits relevant references/tasks; `__scsi_remove_device` makes the device invisible, transitions to DEL, destroys the queue and waits queuecommand/scsi_run_queue completion (v6.8 hosts.c 165–203; scsi_sysfs.c 1450–1515; corresponding v5.15 164 and 1419). Device deletion does not certify that users voluntarily released filesystem references.

`del_gendisk` removes the disk from discovery, marks it dead and drains the queue; final gendisk memory removal is reference counted ([v5.15 block/genhd.c 542–614](https://github.com/torvalds/linux/blob/8bb7eca972ad531c9b149c0a51ab43a417385813/block/genhd.c#L542), [v6.8 608–690](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/block/genhd.c#L608)). An old open descriptor is not magically retargeted to the next disk that happens to reuse the name. sd_remove explicitly documents name reuse (v5.15 3488–3490; v6.8 3794–3796). This does not excuse unbinding active filesystems: cached users can still observe stale data and failed writeback. Pin USB generation, SCSI identity and block disk sequence where available; never infer recovery from a reused `/dev/sdX` path.

After a writable disconnect without checked client unmount/cache completion, default to explicit manual reconciliation. Keep last write/flush certainty, old session identity, exact USB owner release, and fresh enumeration separate. Do not automatically remount, reconnect, replay writes, fsck with modifications, or reauthorize by same busid alone. Physical removal/reset of the underlying device must be a new generation, not an implicit continuation.

### E. LUN discovery and UAS transport limits

BOT GET_MAX_LUN accepts values below 16 and falls back to 0 for stalls, short/failed requests or invalid values ([both versions transport.c 1075–1112](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/storage/transport.c#L1075)); scan is delayed work (usb.c v6.8 880–905). UAS advertises host max_lun=256 (v5.15 uas.c 1012; v6.8 1013); SCSI scanning can use REPORT LUNS and has fallback/quirk handling (v6.8 scsi_scan.c 1300–1525 and 1695). Thus a one-time sysfs walk is an observed set, not proof of all possible LUNs. Record incomplete scan/absent block/unrecognized peripheral as uncertainty; do not actively rescan from a read-only inspector.

[VHCI v5.15 1296–1311](https://github.com/torvalds/linux/blob/8bb7eca972ad531c9b149c0a51ab43a417385813/drivers/usb/usbip/vhci_hcd.c#L1296) and [v6.8 1297–1312](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/usbip/vhci_hcd.c#L1297) contain unimplemented stream alloc/free stubs. Both have scatter-gather table size 32 but do not set can_do_streams. `uas-detect.h` rejects SuperSpeed UAS without streams (v5.15 136–143; v6.8 149–155). A pure UAS-only SuperSpeed device can fail to bind; a dual BOT/UAS device may fall back to BOT. Actual driver, negotiated speed and active alternate setting must be evidence, not inferred from the model name.

## QEMU v6.2 fixture capabilities

[Fixed USB documentation](https://github.com/qemu/qemu/blob/44f28df24767cf9dca1ddc9b23157737c4cbb645/docs/system/devices/usb.rst#L115) describes:

- `usb-storage,drive=...`: creates one SCSI disk, max_lun=0 (hw/usb/dev-storage-classic.c 20–29, 31–80).
- `usb-bot,id=...` plus explicit `scsi-hd,bus=ID.0,scsi-id=0,lun=N,drive=...`: up to 16 contiguous LUNs, no gaps (dev-storage-bot.c 17–41; dev-storage.c 338–353). Useful to make the second or final LUN busy while the first is idle.
- `usb-uas` plus explicit SCSI disks: max_lun=255, can have sparse LUNs (dev-uas.c 622–625); both high-speed and SuperSpeed descriptors exist (181–332). For a USB2 UAS mechanism candidate use a dedicated EHCI bus; for SuperSpeed negative use xHCI. Do not force a fake negotiated speed in USB/IP metadata.
- Hotplug BOT/UAS starts unattached; add all SCSI LUNs before explicitly attaching (docs 235–247; dev-storage-bot.c 36–37; dev-uas.c 932–934).

QEMU readonly backend is an actual device-model test boundary: MODE SENSE reports WP when `!blk_is_writable` (scsi-disk.c 1258–1278), WRITE variants are rejected with WRITE_PROTECTED (2197–2206), as are UNMAP (1701–1704) and WRITE SAME (1792–1795). This supports a labelled **QEMU-enforced read-only fixture**, not a general hardware write-protection claim. [SCSI model source](https://github.com/qemu/qemu/blob/44f28df24767cf9dca1ddc9b23157737c4cbb645/hw/scsi/scsi-disk.c#L1258).

SYNCHRONIZE CACHE invokes `blk_aio_flush` (scsi-disk.c 2093–2099). `cache=writeback` keeps flush enabled; `cache=unsafe` disables it. QEMU v6.2 says `-snapshot` always uses unsafe caching ([qemu-options.hx 1335–1354, 1409–1422](https://github.com/qemu/qemu/blob/44f28df24767cf9dca1ddc9b23157737c4cbb645/qemu-options.hx#L1335)). Use independent expendable raw-image copies or explicit qcow2 overlays with flush-enabled cache for cache tests; do not use `-snapshot` for flush-durability evidence.

## Concrete minimal fixture plan (not run)

Every QEMU host-side backing argument is a newly created private **regular file**, never `/dev/*`, host_device, scsi-block, scsi-generic, usb-host, a mounted filesystem or a production image. Private images can be created by ordinary file I/O; no host loop device/mount/module is needed. Do not read the backing file while QEMU is writing it for an integrity verdict; wait for QEMU clean exit and record original/new hashes. Guest commands below run **only in the dedicated test guest**, after resolving the exact chosen QEMU USB ancestry and checking model, disk generation, capacity and expected fixture ID. They must not run on an arbitrary `/dev/sdX` found by enumeration order.

Host image setup example (regular files only, zero-filled sparse disks):

```sh
# E65_IMAGES is a newly created private evidence/run directory.
truncate -s 64M "$E65_IMAGES/lun0.raw"
truncate -s 64M "$E65_IMAGES/lun1.raw"
```

Single read-only enumeration/image-read fixture, add to the existing guest launch:

```sh
-device qemu-xhci,id=e65xhci \
-drive if=none,id=e65ro,file=PRIVATE/lun0.raw,format=raw,readonly=on,cache=writeback,rerror=report,werror=report \
-device usb-storage,bus=e65xhci.0,id=e65storage,drive=e65ro,serial=RUSTUSB-E65-RO
```

Multi-LUN BOT, first LUN RO and second writable disposable; this catches “first disk only” mistakes:

```sh
-device qemu-xhci,id=e65xhci \
-drive if=none,id=e65l0,file=PRIVATE/lun0.raw,format=raw,readonly=on,cache=writeback,rerror=report,werror=report \
-drive if=none,id=e65l1,file=PRIVATE/lun1.raw,format=raw,cache=writeback,rerror=report,werror=report \
-device usb-bot,bus=e65xhci.0,id=e65bot,serial=RUSTUSB-E65-BOT \
-device scsi-hd,bus=e65bot.0,scsi-id=0,lun=0,drive=e65l0,serial=RUSTUSB-E65-LUN0 \
-device scsi-hd,bus=e65bot.0,scsi-id=0,lun=1,drive=e65l1,serial=RUSTUSB-E65-LUN1
```

For an all-writable future forwarding positive, use separate copied raw images and omit readonly on LUN0. For all-RO negative mutating-command evidence use readonly on every LUN. Record per-LUN setting; never infer device-wide RO from the first LUN.

High-speed UAS candidate (must first prove guest local driver `uas` and speed 480):

```sh
-device usb-ehci,id=e65ehci \
-drive if=none,id=e65u0,file=PRIVATE/uas0.raw,format=raw,readonly=on,cache=writeback,rerror=report,werror=report \
-drive if=none,id=e65u5,file=PRIVATE/uas5.raw,format=raw,cache=writeback,rerror=report,werror=report \
-device usb-uas,bus=e65ehci.0,id=e65uas,serial=RUSTUSB-E65-UAS \
-device scsi-hd,bus=e65uas.0,scsi-id=0,lun=0,drive=e65u0 \
-device scsi-hd,bus=e65uas.0,scsi-id=0,lun=5,drive=e65u5
```

Model availability must be checked against the actual QEMU build's `-device help` before launch. UAS-over-VHCI is still a candidate mechanism experiment, not an established PASS. A separate xHCI/UAS trial can document the expected SuperSpeed limitation; don't turn failure into a fallback success without recording actual BOT capability/selection.

Guest busy fixtures for the inspection increment (one at a time; only previously pinned writable LUN1):

```sh
# E65_DISK is the verified disposable guest LUN1 path, E65_MNT a private guest directory.
# Whole-disk filesystem avoids host partition mapping entirely.
mkfs.ext4 -F "$E65_DISK"
mount "$E65_DISK" "$E65_MNT"
# Run read-only inspector: must report a mount, must not export/unbind/unmount.
umount "$E65_MNT"

# Hidden-from-parent mount namespace; child must hold a readiness barrier before inspection.
unshare --mount --fork sh -eu -c '
  mount --make-rprivate /
  mount -o ro "$1" "$2"
  printf ready > "$3"
  exec sleep 300
' sh "$E65_DISK" "$E65_MNT" "$E65_READY"
# Harness joins/kills only this known fixture child; no forced unmount in product.

# Raw FD with no mount. Requires readiness and actual child lifetime tracking.
python3 - "$E65_DISK" "$E65_READY" <<'PY'
import os, pathlib, sys, time
fd = os.open(sys.argv[1], os.O_RDONLY)
pathlib.Path(sys.argv[2]).write_text('ready\n')
try: time.sleep(300)
finally: os.close(fd)
PY
```

These are command sketches; the harness must retain child PID/process generation, wait for its readiness, inspect during the held condition, then join it and separately verify baseline. Inspection success must leave the mount/FD/driver and both LUNs unchanged. Concurrent change/no visibility becomes Unknown, not an empty audit. Read-only mounted filesystems are still active users and must block source USB handoff. The separate Linux ownership component supplies verified dm/LUKS/loop/swap and fd-table gaps; those are required additional cases, not covered by the sketches here.

## Evidence matrix and eventual positive storage acceptance

| Stage | Test | Required evidence | What it does not prove |
| --- | --- | --- | --- |
| Inspection | Single RO QEMU disk | exact USB→SCSI→LUN→disk ancestry, RO labelled local observation, bounded complete walk | hardware write protection / export safety |
| Inspection | LUN1 mounted while LUN0 idle | all LUNs found; busy reason targets correct derived disk | exhaustive latent LUN discovery |
| Inspection | RO mount in child namespace | actual distinct namespace held, mount recognized or scope explicitly Unknown | inaccessible/dead-namespace completeness |
| Inspection | raw fd / mapping / dm / LUKS / swap | matching real held reference or truthful Unknown | ability to fence/revoke it |
| Inspection | device remove/replace during scan | generation invalidates result; no stale permit | hotplug-free future |
| Future RO forwarding | QEMU backend readonly, Native and USBFS separately | client real enumeration, exact fixture hash, direct SCSI write/UNMAP/WRITE SAME rejection where supported, post-stop backing hash unchanged | physical firmware trust, generic filtering |
| Future writable forwarding | explicit private writable disk | source quiet/fence evidence, checked per-LUN flush, absence of local block consumers after handoff, client write+fsync/readback, voluntarily unmount+flush, original VHCI NULL/Gone + source cleanup, fresh source enumeration and checksum | power-loss durability or arbitrary filesystem integrity |
| Future cache failure | blkdebug flush_to_disk EIO | failure reaches exact sync result and blocks clean-handoff marker; original owner joined | arbitrary hardware failure response |
| Future fault | cable/network loss during write | old session ends uncertain; no automatic source writable rebind/remount/reconnect; explicit new recovery required | successful dirty-data recovery |
| Future crash | server/client/helper kill at each transition | durable original identity retained, no replacement owner's proof accepted for old session | FD revocation on process death |
| Transport | USB2 UAS vs USB3 UAS | actual speed/interface/driver, LUN set, independent results | interchangeable protocol support |

QEMU blkdebug supports `flush_to_disk` errors and state-conditioned rules; see [v6.2 docs/devel/blkdebug.txt](https://github.com/qemu/qemu/blob/44f28df24767cf9dca1ddc9b23157737c4cbb645/docs/devel/blkdebug.txt#L1). A future fixture can wrap only the private block backend with `[inject-error] event="flush_to_disk" errno="5"`; include WCE/flush trace and known trigger state so a boot-time unrelated flush does not masquerade as the product's flush. Avoid `werror=ignore`; record whether QEMU reports or stops on errors. Do not equate successful guest shutdown with explicit per-LUN data proof.

## Open decisions

- Atomic userspace-to-kernel exclusion for a live previously published writable disk is unresolved. Bounded inspection supplies evidence and refusal reasons; it cannot mint an export permit. The separate ownership research establishes O_EXCL/proc limitations.
- New read-only inspection should not send SCSI commands, probe media, mount, trigger scans, or change RO flags. It can report missing/ambiguous metadata; active command-based protection detection is a separately authorized future operation.
- Storage-specific quarantine on Native cleanup requires an API/receipt distinct from stock `usbip unbind`'s automatic driver rebind. USBFS's claim/release/restoration path needs its own equivalent contract. Existing non-storage behavior must retain its current proof semantics.
- Full client-side clean detach requires cooperation with client filesystems/holders and a checked flush before VHCI detach. Root release proof alone is insufficient.
- Firmware WP truth, multi-LUN quirks, physical resets/power failure, real storage hardware and performance remain untested. None of this research completes Phase 1, Phase 2, Phase 3 or the original full task.

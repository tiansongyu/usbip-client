# Linux storage ownership and inspection research

Date: 2026-10-26. Read-only research starting from RustUSB `2eca4522104eef7ccbf23dffba2ef1120bf4349c`. No repository files changed; no product tests/builds, host storage reads, USB/module/mount/account/service mutations, or host process inspection performed. All commands below are **planned, unexecuted guest-only fixtures** unless explicitly identified as source retrieval. This is a design contribution, not implemented storage sharing or completed requirement 4.6.

## Fixed sources and licensing

- Linux v5.15: `8bb7eca972ad531c9b149c0a51ab43a417385813`.
- Linux v6.8: `e8f897f4afef0031fe618a8e94127a0934896aba`.
- `revisions.json`, original GitHub ref/tag API responses, and `manifest.json` record source URLs, exact SHA-256, byte length, and license notices. Originals are in `sources/<tag>/...`. `COPYING`, GPL-2.0, Linux-syscall-note and license-rules originals are preserved. Kernel files retain their individual SPDX/copyright notices; do not copy implementation into MIT Rust source.
- References below are source-file line numbers from these exact commits, not distro-patched Ubuntu kernel assertions. The actual Ubuntu guest build/config/backports must be recorded separately when testing.
- Four failed exploratory path fetches are preserved in the manifest: `fs/mmap.c` at both tags (correct path `mm/mmap.c` subsequently fetched); `Documentation/ABI/testing/sysfs-block` at v6.8 (correct stable path fetched); `Documentation/ABI/stable/sysfs-block` at v5.15 (testing path was already fetched). These are source lookup errors, not product test failures.

## Main conclusion

A bounded root scan plus userspace `O_EXCL` has useful but limited guarantees. A whole-disk claim rejects cooperating holder conflicts across the whole disk and its partitions, including ordinary block filesystem mounts, block swap, device-mapper and MD. The claim checks are serialized in the kernel, so they improve on a scan alone.

It does **not** exclude existing or new ordinary raw block opens, revoke existing file descriptions or VMAs, cover SG/BSG/USBFS handles, prove the absence of kernel-held file references, or provide a transaction from filesystem quiescence through USB unbind/rebind. Therefore it cannot authorize general safe live USB-storage export under the present project contract.

The first production increment should be a bounded, read-only **inspection report**. It can accurately identify many blockers and uncertainty reasons. It must have no conversion into an export permit. Storage refusal remains in place while an actual source admission fence, checked per-LUN flushing, two-sided release and crash behavior are designed and validated. Refusal/inspection alone must not be presented as U-disk sharing.

## What O_EXCL really provides

| Topic | v5.15 | v6.8 | Meaning |
|---|---|---|---|
| Userspace O_EXCL translation | `block/fops.c:428-453` | `block/fops.c:569-619` | Sets `FMODE_EXCL` / `BLK_OPEN_EXCL`, using the file as holder. |
| Holder conflict test | `block/bdev.c:539-554` | `block/bdev.c:466-493` | Examines holders of target and whole disk; does not reject all existing ordinary openers. |
| Atomic claim preparation | `block/bdev.c:569-600` | `block/bdev.c:508-540` | Serialized claiming; competing in-progress claim can sleep uninterruptibly. This is not a bounded-time userspace operation. |
| Ordinary open bypass | `block/bdev.c:789-845` | `block/bdev.c:812-898` | No claim preparation for a non-exclusive open / null holder. |
| Mounted filesystem | `fs/super.c:1230-1246`, `1320-1327` | `fs/super.c:1526-1537` | Mount obtains exclusive block holder; even read-only mount remains an owner. |
| Block swap | `mm/swapfile.c:2896-2906` | `mm/swapfile.c:2763-2775` | Uses exclusive holder. Swap files instead reference their underlying filesystem (`v6.8:2788-2789`). |
| DM lower-device claim | `drivers/md/dm.c:636-655` | `drivers/md/dm.c:725-756` | Uses a common DM holder and registers graph links; claim and sysfs publication are distinct steps. |
| MD member claim | `drivers/md/md.c:2518-2530` | `drivers/md/md.c:3780-3789` | Claims each component block device. |

In v6.8, `BLK_OPEN_RESTRICT_WRITES` is a separate **kernel** open flag (`include/linux/blkdev.h:128`, `1473-1475`). `bdev_may_open()` and write-owner accounting consult it (`block/bdev.c:740-788`), subject to `CONFIG_BLK_DEV_WRITE_MOUNTED` / `bdev_allow_write_mounted`. Userspace `file_to_blk_mode()` does not set it from `O_EXCL`. It is not an available userspace all-access fence, and it does not solve SG/USBFS or readers.

A whole-device O_EXCL claim is sufficient to conflict with claimed partitions; separately opening every partition with distinct file holders conflicts with one's own whole claim. Conversely, multiple LUNs require separate whole-disk claims and there is no atomic multi-LUN userspace claim transaction. Partial claims would require actual owner cleanup and generation revalidation. None of these claims belong in the first **read-only inspection** endpoint: opening a real block device can invoke driver open paths and changes ownership.

Primary links: [5.15 block ownership](https://github.com/torvalds/linux/blob/8bb7eca972ad531c9b149c0a51ab43a417385813/block/bdev.c#L539), [6.8 block ownership](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/block/bdev.c#L812), [6.8 userspace flag mapping](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/block/fops.c#L569).

## Mount namespaces, threads and references outside FD tables

1. Enumerating only `/proc/<tgid>/fd` is insufficient. Threads can unshare their `files_struct`; `kernel/fork.c` v5.15 `3003+`, v6.8 `3354-3365` duplicates the caller's table for `CLONE_FILES`. Enumerate `/proc/<tgid>/task/<tid>/fd` and related per-TID metadata. Do not assume a process-wide FD table or count the process leader as complete coverage. FD info takes a reference under that task's file lock, but this protects one entry, not a global snapshot (`fs/proc/fd.c` v6.8 `23-54`).
2. `mountinfo` is a task's mount namespace **and root view**. `fs/proc_namespace.c` v6.8 `240-280` obtains both, and `150-151` skips mounts outside a chroot. v5.15 has the same explicit skip at `154`. Deduplicating only by mount namespace inode can hide mounts. At most deduplicate by namespace identity **plus process root identity**, preserving coverage uncertainty.
3. A namespace can outlive every task in it. Namespace inode eviction releases the namespace reference (`fs/nsfs.c` v6.8 `52-56`), and the namespace's mounts are dropped only on final namespace reference (`fs/namespace.c` v6.8 `5197-5202`; v5.15 `4340+`). Open namespace FDs and bind mounts of nsfs can pin dormant namespaces. Inspecting every visible task's `ns/mnt` cannot enumerate all such namespaces. Detect visible nsfs references as uncertainty; do not follow arbitrary filesystem trees looking for all pins. A later dedicated child entering a namespace would require a separately designed root-view and lifecycle contract; it still would not enumerate undiscoverable references.
4. Lazy unmount differs from successful busy-checked unmount: v6.8 `fs/namespace.c:1784-1796` detaches without the regular `propagate_mount_busy()` gate. A detached but live mount can still own its superblock/device. A successful exclusive block claim may catch that holder; a mountinfo scan alone need not. The inspection endpoint must not execute lazy or forced unmount.
5. `/proc/<tid>/maps` contains filesystem `st_dev`, not a block-special file's `st_rdev`: v6.8 `fs/proc/task_mmu.c:263-280` takes `file_user_inode()->i_sb->s_dev`. A raw `/dev/sdX` mapping can therefore appear with devtmpfs's device number. Parse maps for ranges/flags, then inspect `/proc/<tid>/map_files/<start>-<end>` object metadata to recognize block special files. Do not identify raw maps from pathname strings. `map_files` gets the actual VMA file path (`fs/proc/base.c:2187-2218`) but following links requires init-user-namespace CAP_SYS_ADMIN/CAP_CHECKPOINT_RESTORE (`2234-2247`; v5.15 `2213-2218`). Missing privileges or VMA changes become Unknown, not absent.
6. VMAs keep file references after FD closure (`mm/mmap.c` v6.8 `2828`). Other references can be held outside both FD lists and VMAs: io_uring registered files use `fget` and store a fixed reference (`io_uring/rsrc.c:700-755`; v5.15 `fs/io_uring.c:8212+`), and SCM_RIGHTS queues acquire `fget_raw` references (`net/core/scm.c` v6.8 `91-112`, v5.15 `104`). A raw block FD can thus disappear from the original table without the open file being released. An ordinary `/proc` traversal does not enumerate all kernel file references.
7. `hidepid`, ptrace checks, PID namespace visibility, process churn, symlink targets disappearing, and partial file reads all constrain coverage. `/proc/PID/maps` is explicitly documented as racy (`Documentation/filesystems/proc.rst` v6.8 `585-595`). Root inside a container is not proof of initial host namespace coverage. Equality with `/proc/1/ns/pid` only proves equality with the visible PID 1; it does not prove the initial namespace.

Primary links: [mountinfo root filtering](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/fs/proc_namespace.c#L150), [namespace lifetime](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/fs/namespace.c#L5197), [map_files access](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/fs/proc/base.c#L2187), [registered files](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/io_uring/rsrc.c#L700), [SCM references](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/net/core/scm.c#L91).

## Other command paths and host read-only flags

- SG and BSG opens are distinct from the block holder. SG has its own `sdp->exclude`/`open_cnt` and O_EXCL logic (`drivers/scsi/sg.c` v6.8 `245-355`), which is stronger within that SG node but does not share block ownership. BSG open merely retains its request queue (`block/bsg.c:74-84`). Claiming a block node does not claim these character nodes.
- USBFS retains separate device file state (`drivers/usb/core/devio.c` v6.8 `1032-1076`). `USBDEVFS_DISCONNECT_CLAIM` can release an existing interface driver and then claim the interface (`2460-2492`). Block claims do not authorize or prevent it.
- `BLKROSET` requires CAP_SYS_ADMIN but ordinarily sets `bdev->bd_read_only`; it does not revoke FDs or VMAs (`block/ioctl.c` v6.8 `383-399`). Ordinary block writes check current read-only state, including writes through an already open FD (`block/fops.c:671-681`; v5.15 `497+`). v6.8 newly created mappings use a read-only mapping helper when flagged (`843-850`). This is useful behavior, but not comprehensive access fencing.
- Both fixed kernels' lower-level `bio_check_ro()` warns and continues for writes to read-only lower devices (v5.15 `block/blk-core.c:698-713`; v6.8 `500-517`). The comment explicitly cites LVM / dm / RAID paths. Hence setting a lower USB disk read-only is not a universal barrier against writes from existing stacked devices.
- SG_IO authorization uses the file's original open-for-write mode and CAP_SYS_RAWIO, not the bdev read-only bit: v6.8 `drivers/scsi/sd.c:1508-1536`, `drivers/scsi/scsi_ioctl.c:251-255,898+`. Existing writable raw FD pass-through and separate SG/BSG paths remain concerns. A host flag also does not make the remotely re-enumerated device physically write-protected.
- `BLKFLSBUF` v6.8 `block/ioctl.c:365-380` invokes sync then invalidation and returns zero without propagating sync failure. It is not a checked durable-media flush receipt.
- Node chmod/udev policy or device cgroup changes can restrict future access in their covered domain; they do not revoke already held open file descriptions. They cannot be advertised as an atomic all-host fence without a defined pre-enrollment trust boundary and tests.

Primary links: [RO write check](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/block/fops.c#L671), [RO is not lower-layer denial](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/block/blk-core.c#L500), [SCSI command authorization](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/scsi/sd.c#L1508).

## Bounded read-only production inspection proposal

### Result and authority

The selected first increment is root-only local inspection, with no application-service/remote metadata exposure and no permit. Use a type such as `StorageInspection`, separate from all helper grants, leases and release proofs. Return:

- Target pinned USB generation and observed start/end identity; source version and monotonic inspection interval.
- Observed LUN/block/partition graph and bounded ownership observations.
- Findings: `UseObserved`, `NoUseObserved`, or `Indeterminate`; independent coverage/uncertainty list. `UseObserved` may coexist with incomplete coverage.
- Explicit flags `non_atomic_observation=true` and `export_authorized=false`. No `Safe`, `Eligible`, `Exclusive`, `UnmountedEverywhere` or implicit conversion to an export policy object.
- Counts and reason codes, with bounded optional diagnostics. Do not publish raw process command lines, usernames, FD target paths, mount source paths, volume labels, serials, DM table parameters/keys or storage bytes. Access to process metadata must be authorized; ordinary general device discovery must not become a host process disclosure endpoint.

### Acquisition steps

1. Pin current USB sysfs directory/identity using existing project rules; classify every configuration/interface/alternate setting. Enumerate actual descendant SCSI hosts/targets/LUNs and associated block devices, not just `/dev/sd*` names. Treat initial scanning, unsupported transport, missing LUN mapping and hotplug as Indeterminate. Do not issue SCSI discovery commands or read media for this first endpoint.
2. Enumerate whole disks and partitions, using sysfs `dev` major/minor, partition membership and canonical kernel path. Walk holders/slaves **as an explicitly controlled graph**, bounded by visited device identities, depth, nodes and edges. The existing descendant scanner deliberately avoids arbitrary sysfs symlink traversal; do not weaken it globally to add graph support. Links leaving the expected graph/sysfs root, dangling links, cycles, renumbering or overflow produce uncertainty. Multi-LUN is a list of independent backing disks; class information alone is insufficient.
3. Any active upper holder is a blocker, whether DM, MD, crypt, thin, snapshot, multipath, cache or unknown. `holders/` is not a complete list of all uses: mounts and swap claim blocks without being upper block disks, and even DM claims can precede holder-link publication (`drivers/md/dm.c` v6.8 `738-750`). Preserve graph uncertainty.
4. For DM, sysfs `dm/name`/`uuid` are administrator-controlled identifiers, not proof of target type or absence of encryption. A first increment can report `MappedDeviceObserved` with encryption classification Unknown. If exact active target type is needed, add separately reviewed bounded `DM_TABLE_STATUS` **INFO** ioctl, with neither `DM_STATUS_TABLE_FLAG` nor IMA/table/key retrieval, `DM_NOFLUSH_FLAG` where appropriate, strict output bounds/offsets and no persistence of target status strings. `drivers/md/dm-ioctl.c:1274-1307` selects status type and emits authoritative `target_type`; `include/uapi/linux/dm-ioctl.h:150-170` documents output `next` offsets. Unknown targets/status effects must be reviewed before calling them. Active `crypt` is distinguishable; a closed LUKS container has no active mapper, and metadata-only inspection cannot claim the media is unencrypted. Do not run `dmsetup table --showkeys`, invoke cryptsetup on real disks, or scan LUKS headers in this endpoint.
5. Snapshot visible TGIDs and each task's TIDs under trusted procfs. Keep directory references and task start identities; read before/after identities. Traverse every distinct thread table; skip/deduplicate only where identity is proven, not merely equal TGID. A vanished task/table, replaced FD or new task between bounded passes makes coverage partial. Two equal passes do not prove no activity in between.
6. Read each distinct `(mount namespace, process-root)` mountinfo view. Match device numbers against the entire lower/upper/partition graph. Retain mount flags as observations; read-only mounts remain use. Visible nsfs mount or FD references with no represented task view are explicit `UninspectedNamespace` reasons. Do not claim full namespace enumeration even if none is observed.
7. Inspect FD metadata, not target file content. Identify block/char raw device references by file type and `st_rdev`; identify files/directories/cwd/root on implicated filesystems by `st_dev` and mount evidence. FD flags can come from `fdinfo`, but fdinfo and object metadata are separate observations; revalidate identity and mark races. Kernel references outside FD tables remain a documented coverage gap.
8. Parse maps and resolve only corresponding map_files object metadata. Map permissions are useful; retain read-only mappings as use because changing/removing the backing USB device still affects them. Missing map_files authority or unmatched mappings produce Unknown. No reading mapped pages, file content or process memory.
9. Read bounded `/proc/swaps`. Match block entries by metadata, not path spelling; for swap files resolve filesystem ownership via metadata/graph. Missing/deleted/malformed entries remain Unknown. Do not execute swapoff or change hibernation/resume state.
10. Re-read USB/block topology and target identities. Return observations only when original generation remains identifiable; otherwise `GenerationChanged`/partial report. No automatic retry producing a new authorization identity.

### Parsing and resource limits

Choose explicit initial limits in the design (for example 4,096 visible tasks, 256 block graph nodes/1,024 edges/32 depth, 65,536 FD and VMA observations total, 1 MiB per proc text file, 8 MiB aggregate input, bounded output). These numbers are proposals, not upstream limits or measured optimum. Exceeding any limit must set a reason and stop admission-free inspection; never silently truncate to a clean result.

- `mountinfo`: byte-bounded line parser, decimal IDs and major:minor checked for overflow; locate the ` - ` separator; require mandatory fields, preserve unknown optional tags, decode only defined octal escapes for paths when necessary, and never execute or reopen arbitrary source strings. Kernel ABI fields are documented at `Documentation/filesystems/proc.rst` v6.8 `1857-1885`.
- `maps`: bounded hexadecimal address range, permissions, offset, hex major/minor and decimal inode; optional pathname is opaque untrusted bytes and may contain `(deleted)`. Do not split it into authority or require UTF-8. Validate map_files names from parsed ranges; only follow that specific procfs magic-link operation to obtain metadata. `O_NOFOLLOW`/`RESOLVE_NO_MAGICLINKS` cannot be blindly applied to an operation whose purpose is following a proc magic link; use a dedicated reviewed path, not arbitrary links.
- `fdinfo`: bounded key/value parser, octal flags and checked decimal fields, forward-compatible unknown fields. Treat flags as observations, not write exclusion.
- `stat`: process comm can contain spaces/parentheses; don't split entire line on spaces. Verify numeric PID, final comm delimiter and known field positions; preserve PID reuse/start-time mismatches as uncertainty.
- `sysfs dev`, partition numbers and graph links: strict nonempty numerics, overflow rejection, bounded bytes, explicit directory/type checks and generation rechecks. Detect errors rather than interpreting unreadable as absent.
- Use existing safe Rust/nix wrappers if possible; do not introduce core unsafe or shell calls. Root path access requires narrowly scoped fixed requests, not user-supplied filesystem roots. A synthetic injected filesystem reader for parser/unit tests must never become an externally controllable root path.
- Wall-clock budget limits starting more work, not actual cancellation of a filesystem/kernel syscall. Keep actual worker ownership, bounded concurrency, and join semantics. Do not claim a Rust timeout stopped a blocked stat/open/read operation.

## Planned QEMU inspection cases

All use disposable **guest-only** storage images/devices with a verified QMP identity and no connection to host disks. Assert each `$CASE_DEV` is a whole synthetic USB LUN belonging to the chosen test USB generation, is not the guest root/backing drive, and has no unexpected mounts/holders before setup. Record guest kernel/package/config, image origin, test setup actions, actual process PIDs/waits, inspection JSON, cleanup and guest exits. Do not archive data or encryption keys. Package/tool availability must be verified in the guest before a case begins.

| Case | Construction | Required observation |
|---|---|---|
| Idle BOT one-LUN | New synthetic U-disk, no local use | LUN/disk/partitions present; `NoUseObserved` with non-atomic/global-reference coverage caveat; export still denied. |
| Mount RW and RO | Fresh guest test filesystem mounted normally, then separate RO case | Both report mount use; no forced/lazy unmount by product. |
| Other namespace/chroot | Child `unshare -m`, private propagation, mount only there; separate child with same ns but chroot excluding mount | Both views handled; namespace-only dedup must not lose mount. |
| Dormant namespace pin | Child opens `/proc/self/ns/mnt`, passes FD to parent, exits after mounting inside it | No member task remains; parent-held nsfs reference reported as uninspected/Unknown. Namespace FD in SCM_RIGHTS queue is a further incomplete-coverage case. |
| Lazy detached mount | Fixture holds file/cwd, then guest fixture uses `umount -l` | Missing mountinfo entry must not yield safe/complete; open file or retained namespace/coverage reasons remain. |
| Thread-local table | Test process worker calls `unshare(CLONE_FILES)`, opens test raw device, main thread does not | TID scan finds raw block reference. Leader-only scan negative control must miss it. |
| Raw FD/alias | Open ordinary O_RDONLY and O_RDWR without O_EXCL; optional alias node in private guest tmpfs | Match `st_rdev` independent of path; report both as use. |
| VMA after close | Map raw block file, close FD, keep mapping | Find through map_files; maps dev field alone negative control is insufficient. |
| io_uring / SCM_RIGHTS | Register a raw FD then close original; separately queue raw FD then close sender without receiving | Fixed-kernel metadata scan must not certify no references; report coverage Unknown even if no direct raw FD is visible. |
| Swap block/file | Guest-only `mkswap`/`swapon` on synthetic LUN, and swap file on its mounted filesystem | Swap and filesystem ownership reported. Product does not swapoff. |
| DM linear | Commands below on one disposable LUN | Holder/slave edge and mapped-device blocker; mount upper layer in another variant. |
| dm-crypt/LUKS | Commands below; mapper open but unmounted, then mounted variant; separate closed LUKS case | Active mapper is blocked; closed mapper is not called unencrypted and no media probing occurs. |
| LVM/MD | Dedicated disposable LUN(s) assembled in guest; active unmounted logical/MD devices | Recursive upper graph ownership; no inference from absence of a mount. |
| Multiple LUNs | Two or more LUNs under one selected USB generation; only nonfirst LUN in use | All LUNs considered, whole USB object not eligible. |
| SG/BSG/USBFS | Guest probe holds corresponding character FD without writes | Distinct raw access evidence; block-holder availability is not global exclusion. |
| Churn/permissions/limits | Controlled TID/FD/VMA/namespace changes, restricted inspection child, oversize synthetic parser inputs | Stable reason codes, bounded memory/output; no false clean result. |
| Hotplug/reuse | QMP removes/readds another test generation at same port | Original target changed; report never relabels new generation as original. |

Concrete guest-only setup sketches, not executed by this research:

```sh
# $CASE_DEV is the separately validated disposable guest USB LUN.
# Fixture owns these names, directories and processes; no host or production use.
sectors=$(blockdev --getsz "$CASE_DEV")
dmsetup create rustusb-test-linear --table "0 $sectors linear $CASE_DEV 0"
# Invoke read-only inspection while mapper remains active; then cleanup:
dmsetup remove rustusb-test-linear
```

```sh
# Separate fresh disposable USB image for the destructive LUKS fixture.
install -d -m 0700 /run/rustusb-storage-test
head -c 32 /dev/urandom > /run/rustusb-storage-test/key
chmod 0600 /run/rustusb-storage-test/key
cryptsetup luksFormat --batch-mode --type luks2 --pbkdf pbkdf2 \
  --key-file /run/rustusb-storage-test/key "$CASE_DEV"
cryptsetup open --key-file /run/rustusb-storage-test/key \
  "$CASE_DEV" rustusb-test-crypt
# Inspect active mapper without mounting; a separate test formats/mounts it.
cryptsetup close rustusb-test-crypt
rm /run/rustusb-storage-test/key
# Inspect closed LUKS case: no active crypt mapper, encryption status unknown.
```

The upstream fixed dm-crypt documentation describes its lower-device mapping and LUKS/cryptsetup setup; its command parameter discussion includes keys, which is why the inspection protocol must avoid copying table payloads. Guest recipes still require execution/verification before becoming reported test evidence.

## Path from inspection to actual safe sharing

1. Deliver truthful bounded inspection and fixture coverage as a **partial requirement 4.6 increment**; keep all storage exports blocked. UI should expose blockers and unknown scope without a misleading export-ready state.
2. Define a supported source lifecycle and a real admission fence. General live device handoff on an arbitrary host is not solved by current userspace scanning. Options to research are a reviewed kernel mechanism covering all access paths and outstanding operations, or a narrow export-only pre-enrollment/quarantine lifecycle that prevents local storage and raw access from initial device arrival. The sibling USB audit found prepopulating usbip `match_busid` alone does not reliably prevent generic USB probing in these versions; do not propose it as an existing fence. A trusted administrator policy is a stated assumption, not a kernel proof.
3. Under that validated fence, require administrator-requested cooperative cessation of consumers, release of files/mappings/swap/DM/MD as appropriate, then checked per-LUN host/page-cache and device-cache flush. No force/lazy unmount, blind lower-layer RO, automated filesystem repair or root-wide kill. Retain original generation and every actual owner through transfer. Flush API success and supported media cache semantics need separate review.
4. Commit durable storage-specific intent/baseline before USB mutation, then transfer the entire USB device only after all LUNs qualify. Old bdev FDs refer to the removed old generation; they are not a transferable lock on remote/newly probed block devices. `del_gendisk()` removes inode lookup/partitions and marks I/O dead (`block/genhd.c` v5.15 `561-590`, v6.8 `641-675`), rather than refusing removal because a holder exists.
5. Receiver must enforce its own namespace/consumer policy and explicit user mount flow. Before normal release, require cooperative remote unmount/all-consumer retirement and checked flush with a receipt bound to original USB/session/LUN identities. A generic transport disconnect/FIN cannot prove filesystem or media consistency.
6. On cable/network/power/process failure, retain a storage-needs-attention state. Do not automatically remount locally or claim filesystem consistency from driver restoration, helper resource zero or process death. Recovery policy and crash/replug identities need specific design and destructive tests using disposable media.
7. Only after normal source→receiver writes/readback→safe release→source reread, multi-LUN/DM/namespace/raw access negatives, source/receiver crash and failure tests pass should a narrow storage class be enabled. QEMU verifies defined mechanisms; physical BOT/UAS/media-cache behavior and actual USB fault gates remain separate.

## Questions to resolve before implementation/admission

- First increment is explicitly root-only local inspection. Any later ordinary-user/application RPC projection needs a separate authorization and redaction design; existing Read authorization is not assumed to allow cross-user process metadata.
- Does the first implementation classify DM only as active mapped storage (sufficient blocker), or add a reviewed INFO-only target ioctl? Sysfs identifiers must never stand in for target truth.
- Which initial limits suit supported hosts? Measure completeness/resource use on synthetic guest workloads before freezing the public schema.
- What exact restricted source lifecycle or kernel fence will eventually permit real U-disk sharing? Current fixed-kernel userspace APIs do not establish a general live handoff guarantee.
- How will peer media flush and safe detach be represented without conflating USB cleanup with data durability? Read-only inspection cannot answer this.
- Ubuntu GA/HWE/backport behavior, block write-mounted config, UAS/BOT differences, and real-media cache guarantees remain execution/compatibility work, not established by upstream source review.

## Parser source addendum

- Sysfs device `dev` publication: v6.8 `drivers/base/core.c:2932-2937` calls `print_dev_t`; `include/linux/kdev_t.h` defines the decimal major:minor plus newline format. Partition identity: `block/partitions/core.c:173-176` emits decimal `bd_partno`, and `203-204` defines the read-only partition/start attributes. Both fixed versions' originals are archived. The relevant block ABI docs live in `Documentation/ABI/testing/sysfs-block` at v5.15 and `Documentation/ABI/stable/sysfs-block` at v6.8.
- FD reference lookup: v6.8 `fs/proc/fd.c:171+` resolves a task FD's actual file path; `245+` iterates that task table. `23-59` shows separately locked fdinfo fields. This is per-entry observation, not a combined atomic metadata/flags snapshot.
- `/proc/TID/stat`: v6.8 `fs/proc/array.c:585-612` prints start time in clock ticks after time-namespace adjustment and emits unescaped comm inside parentheses. Parse a bounded complete byte buffer, not a single newline-delimited fragment (comm can contain newline), use the final comm delimiter before numeric fields, and read field 22 for starttime. Keep inspector time namespace stable. PID+starttime is a useful change detector, not an absolute cryptographic/generation identity; retain pinned proc directory/task references where possible and never elevate a stable pair to exclusion proof.
- `/proc/TID/map_files` access and VMA identity are explicitly sourced in the namespace/FD section above. File type plus `st_rdev` is needed for raw block/char mappings; `maps` major:minor alone is insufficient.

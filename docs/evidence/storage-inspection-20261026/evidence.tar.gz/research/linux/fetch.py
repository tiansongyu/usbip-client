import urllib.request,json,pathlib,hashlib,concurrent.futures,datetime
root=pathlib.Path('/tmp/rustusb-storage-linux-20261026')
paths=['COPYING','LICENSES/preferred/GPL-2.0','block/bdev.c','block/fops.c','block/genhd.c','block/ioctl.c','include/linux/blkdev.h','include/linux/blk_types.h','fs/super.c','fs/namespace.c','fs/proc/task_mmu.c','fs/proc/fd.c','mm/swapfile.c','drivers/md/dm.c','drivers/md/md.c','drivers/md/dm-table.c','drivers/scsi/sg.c','drivers/scsi/scsi_sysfs.c','drivers/scsi/sd.c','drivers/usb/storage/usb.c','drivers/usb/storage/scsiglue.c','drivers/usb/storage/uas.c','drivers/usb/core/devio.c','drivers/usb/usbip/stub_main.c','drivers/usb/usbip/stub_dev.c','Documentation/filesystems/proc.rst','Documentation/admin-guide/device-mapper/dm-crypt.rst','Documentation/admin-guide/devices.txt']
def get(url):
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'RustUSB read-only source research'}),timeout=40) as r:return r.read()
revs={}
for tag in ['v5.15','v6.8']:
 url=f'https://api.github.com/repos/torvalds/linux/git/ref/tags/{tag}'
 raw=get(url); (root/f'{tag}-ref.json').write_bytes(raw); obj=json.loads(raw)['object']
 if obj['type']=='tag':
  raw=get(obj['url']);(root/f'{tag}-tag.json').write_bytes(raw);obj=json.loads(raw)['object']
 revs[tag]=obj['sha']
(root/'revisions.json').write_text(json.dumps(revs,indent=2)+'\n')
def fetch(task):
 tag,path=task; url=f'https://raw.githubusercontent.com/torvalds/linux/{revs[tag]}/{path}'
 target=root/'sources'/tag/path
 try:
  raw=get(url);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
  spdx=next((l.strip() for l in raw.decode(errors='replace').splitlines()[:30] if 'SPDX-License-Identifier:' in l),'See file notices and repository COPYING; not inferred from absence of SPDX')
  return dict(tag=tag,commit=revs[tag],path=path,url=url,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),license_notice=spdx)
 except Exception as e:return dict(tag=tag,path=path,url=url,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:records=list(pool.map(fetch,[(tag,path) for tag in revs for path in paths]))
(root/'manifest.json').write_text(json.dumps({'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'read_only_research':True,'sources':records},indent=2)+'\n')
print(json.dumps({'revisions':revs,'downloaded':sum('sha256' in r for r in records),'errors':[r for r in records if 'error' in r]},indent=2))

import urllib.request,json,pathlib,hashlib,concurrent.futures
root=pathlib.Path('/tmp/rustusb-storage-linux-20261026');revs=json.loads((root/'revisions.json').read_text());m=json.loads((root/'manifest.json').read_text())
tasks=[(v,p) for v in revs for p in ['fs/proc_namespace.c','fs/proc/base.c','fs/mmap.c','drivers/md/dm-crypt.c','block/bsg.c','include/linux/fs.h','net/core/scm.c']]+[('v5.15','fs/io_uring.c'),('v6.8','io_uring/rsrc.c'),('v6.8','block/Kconfig')]
def fetch(task):
 v,p=task;u=f'https://raw.githubusercontent.com/torvalds/linux/{revs[v]}/{p}'
 try:
  with urllib.request.urlopen(u,timeout=40) as r:raw=r.read()
  t=root/'sources'/v/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(raw)
  return dict(tag=v,commit=revs[v],path=p,url=u,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),license_notice=next((l.strip() for l in raw.decode(errors='replace').splitlines()[:30] if 'SPDX-License-Identifier:' in l),'See file notices and repository COPYING'))
 except Exception as e:return dict(tag=v,path=p,url=u,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:res=list(pool.map(fetch,tasks))
m['sources']+=res;(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print({'downloaded':sum('sha256' in r for r in res),'errors':[r for r in res if 'error' in r]})

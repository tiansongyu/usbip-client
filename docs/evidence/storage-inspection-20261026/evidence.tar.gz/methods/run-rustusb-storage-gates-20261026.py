import concurrent.futures,datetime,hashlib,json,pathlib,re,subprocess
root=pathlib.Path('/home/ubuntu/github/usbip-client');out=pathlib.Path('/tmp/rustusb-storage-software-20261026');out.mkdir(mode=0o700)
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inventory():
 paths=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
 return {n:{'bytes':(root/n).stat().st_size,'sha256':digest(root/n)} for n in paths if n and not n.startswith('docs/evidence/')}
head=git('rev-parse','HEAD');assert not git('status','--porcelain');inputs=inventory()
summary={'head':head,'inputs':inputs,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'FAIL'}
def gate(item):
 name,argv=item
 with (out/(name+'.log')).open('wb') as f:p=subprocess.run(argv,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 values=[tuple(map(int,x)) for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',(out/(name+'.log')).read_text())]
 return {'name':name,'argv':argv,'exit':p.returncode,'passed':sum(v[0] for v in values),'failed':sum(v[1] for v in values),'ignored':sum(v[2] for v in values)}
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:summary['commands']=list(pool.map(gate,[('core',['bash','scripts/check.sh']),('gui',['bash','scripts/check-gui.sh'])]))
 summary['binaries']={str(p.relative_to(root)):{'sha256':digest(p),'bytes':p.stat().st_size} for p in [root/'target/release/rustusb',root/'target/release/rustusb-helper',root/'apps/rustusb-gui/target/release/rustusb-gui']}
 summary['guards']={'head':git('rev-parse','HEAD')==head,'clean':not git('status','--porcelain'),'inputs':inventory()==inputs}
 summary['result']='PASS' if all(c['exit']==0 and c['failed']==c['ignored']==0 for c in summary['commands']) and all(summary['guards'].values()) else 'FAIL'
finally:(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='inputs'}),flush=True)
assert summary['result']=='PASS'


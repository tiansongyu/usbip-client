import gzip,hashlib,io,json,pathlib,re,subprocess,tarfile
repo=pathlib.Path('/home/ubuntu/github/usbip-client');dest=repo/'docs/evidence/storage-inspection-20261026';
if dest.exists():
 old=json.loads((dest/'manifest.json').read_text())
 assert hashlib.sha256((dest/'evidence.tar.gz').read_bytes()).hexdigest()==old['archive']['sha256']
else:dest.mkdir(parents=True)

items={}
def add(name,data):
 assert name not in items and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
 items[name]=data
roots={
 'research/linux':pathlib.Path('/tmp/rustusb-storage-linux-20261026'),
 'research/usb':pathlib.Path('/tmp/rustusb-storage-usb-20261026'),
 'development':pathlib.Path('/tmp/rustusb-storage-development-20261026'),
 'software/initial':pathlib.Path('/tmp/rustusb-storage-software-20261026'),
 'software/fixed':pathlib.Path('/tmp/rustusb-storage-fixed-software-20261026'),
 'qemu/jammy-failed':pathlib.Path('/tmp/rustusb-storage-jammy-20261026'),
 'qemu/jammy-fixed':pathlib.Path('/tmp/rustusb-storage-jammy-fixed-20261026'),
 'qemu/noble-fixed':pathlib.Path('/tmp/rustusb-storage-noble-fixed-20261026'),
 'qemu/native-regression':pathlib.Path('/tmp/rustusb-storage-native-regression-20261026'),
 'audit':pathlib.Path('/tmp/rustusb-storage-audit-20261026'),
}
for prefix,root in roots.items():
 for p in sorted(root.rglob('*')):
  relative=p.relative_to(root)
  if '.private' in relative.parts or '__pycache__' in relative.parts:continue
  if p.is_file():
   assert not p.is_symlink(),str(p)
   add(prefix+'/'+str(relative),p.read_bytes())
methods=['run-rustusb-storage-gates-20261026.py','run-rustusb-storage-fixed-gates-20261026.py','run-rustusb-storage-native-regression-20261026.py','audit-rustusb-storage-20261026.py','collect-rustusb-storage-20261026.py']
for name in methods:add('methods/'+name,(pathlib.Path('/tmp')/name).read_bytes())
for name in ['rustusb-storage-software-20261026.log','rustusb-storage-fixed-software-20261026.log','rustusb-storage-jammy-20261026.log','rustusb-storage-jammy-fixed-20261026.log','rustusb-storage-noble-fixed-20261026.log','rustusb-storage-native-regression-20261026.log','rustusb-storage-audit-20261026.log']:
 add('host-logs/'+name,(pathlib.Path('/tmp')/name).read_bytes())
observations={'source':'assistant-observed exec terminal results, transcribed separately from subprocess logs','sessions':[{'id':85374,'exit':0,'kind':'initial full software'},{'id':82863,'exit':1,'kind':'initial Jammy FAIL'},{'id':74920,'exit':0,'kind':'fixed full software'},{'id':44529,'exit':0,'kind':'fixed Jammy'},{'id':55378,'exit':0,'kind':'fixed Noble'},{'id':8711,'exit':0,'kind':'Native regression'},{'id':64623,'exit':0,'kind':'read-only audit'}]}
add('host-terminal-observations.json',(json.dumps(observations,indent=2)+'\n').encode())
for head in ['ce840a81cf2bd9405b072afd707b75118a44018c','c55a6c577d2479b77a27b3edf796d803c8b689f7']:
 for name in ['scripts/qemu_storage/run.py','scripts/qemu_storage/guest.py','scripts/qemu_storage/hold.c']:
  add('executed-source/'+head+'/'+name,subprocess.check_output(['git','show',head+':'+name],cwd=repo))
private_keys=[p.read_bytes() for r in ['jammy','jammy-fixed','noble-fixed'] for p in [pathlib.Path('/tmp/rustusb-storage-'+r+'-20261026/guest/.private/ssh-key')]]
secret=re.compile(rb'-----BEGIN (?:OPENSSH |RSA |EC |ENCRYPTED )?PRIVATE KEY-----\s+[A-Za-z0-9+/]{40,}')
def check(name,data):
 assert not data.startswith(b'\x7fELF') and not data.startswith(b'QFI\xfb'),name
 assert not secret.search(data),name
 assert not any(key in data for key in private_keys),name
 assert not re.search(rb'https?://[^\s"<>]+[?&](?:sig|X-Amz-Signature|X-Goog-Signature)=[A-Za-z0-9%+/]{24,}',data),name
 assert not name.endswith(('.deb','.qcow2','.img','.iso','.pem','.key')),name
 if name.endswith('.tar'):
  with tarfile.open(fileobj=io.BytesIO(data)) as t:
   for m in t.getmembers():
    assert m.isfile() or m.isdir(),(name,m.name)
    if m.isfile():check(name+'/'+m.name,t.extractfile(m).read())
for n,b in items.items():check(n,b)
manifest={'schema_version':1,'scope':'Fixed-source research, both software runs, retained first QEMU failure, two fixed storage guests, original Native regression, same-author read-only audit','exclusions':['all .private trees, SSH private keys, guest disks/backing images, packages, executable payloads, native harness temporary credentials/initramfs'],'ssh_private_keys_checked':len(private_keys),'files':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(items.items())}}
archive=dest/'evidence.tar.gz'
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as t:
   for n,b in sorted(items.items()):
    info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;t.addfile(info,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(items)
 for m in t.getmembers():assert t.extractfile(m).read()==items[m.name]
manifest['archive']={'path':'evidence.tar.gz','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(items),'uncompressed_file_bytes':sum(len(b) for b in items.values())}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(dest/'README.md').write_text('# Storage inspection evidence\n\nSee [validation](../../research/storage-inspection-validation.md). The archive preserves the first failed Jammy mmap trial and the later successful fixed trials separately. Every member is hashed in `manifest.json`; private disks, keys and executable payloads are excluded. GPL upstream research originals retain their license files and notices; they are not product implementation.\n')
print(json.dumps(manifest['archive']),flush=True)

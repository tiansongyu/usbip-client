import hashlib,json,pathlib,subprocess
root=pathlib.Path('/home/ubuntu/github/usbip-client');out=pathlib.Path('/tmp/rustusb-storage-native-regression-20261026');out.mkdir(mode=0o700)
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():
 names=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
 return {n:sha(root/n) for n in names if n and not n.startswith('docs/evidence/')}
head=git('rev-parse','HEAD');assert not git('status','--porcelain');source=inputs()
elfs={str(p.relative_to(root)):sha(p) for p in [root/'target/release/rustusb',root/'target/release/rustusb-helper',root/'apps/rustusb-gui/target/release/rustusb-gui']}
args=['python3','scripts/qemu/run-secure-qemu.py','--backend','native','--family','ipv4','--skip-build','--evidence',str(out/'qemu')]
receipt={'head':head,'inputs':source,'binaries':elfs,'argv':args,'build':'same clean-head full check.sh/check-gui.sh release outputs; no rebuild during actual owner'}
(out/'before.json').write_text(json.dumps(receipt,indent=2)+'\n')
with (out/'run.log').open('wb') as f:p=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
receipt['exit']=p.returncode
receipt['guards']={'head':git('rev-parse','HEAD')==head,'clean':not git('status','--porcelain'),'inputs':inputs()==source,'binaries':all(sha(root/n)==h for n,h in elfs.items())}
receipt['passed']=p.returncode==0 and all(receipt['guards'].values())
(out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ['inputs']}),flush=True)
if not receipt['passed']:raise SystemExit(1)

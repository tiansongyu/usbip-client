import hashlib,json,pathlib,subprocess,tarfile
root=pathlib.Path('/home/ubuntu/github/usbip-client');out=pathlib.Path('/tmp/rustusb-storage-audit-20261026');out.mkdir(mode=0o700,exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text())
def check_sources(head,inputs):
 for n,row in inputs.items():
  expected=row['sha256'] if isinstance(row,dict) else row
  data=subprocess.check_output(['git','show',head+':'+n],cwd=root)
  assert sha(data)==expected,(head,n)
 return len(inputs)
checks=[]
for phase in ['software','fixed-software']:
 d=load('/tmp/rustusb-storage-'+phase+'-20261026/summary.json')
 assert d['result']=='PASS' and all(d['guards'].values())
 assert [(c['exit'],c['passed'],c['failed'],c['ignored']) for c in d['commands']]==[(0,1148,0,0),(0,18,0,0)]
 checks.append({'kind':phase,'source_inputs':check_sources(d['head'],d['inputs'])})
gate=load('/tmp/rustusb-storage-fixed-software-20261026/summary.json')
for trial,expected in [('jammy',False),('jammy-fixed',True),('noble-fixed',True)]:
 folder=pathlib.Path('/tmp/rustusb-storage-'+trial+'-20261026');d=load(folder/'result.json');p=load(folder/'provenance.json')
 assert d['passed']==expected and d['qemu_exit']==0 and d['collection_exit']==0 and d['kernel_integrity'] and all(d['guards'].values())
 count=check_sources(p['head'],p['inputs'])
 with tarfile.open(folder/'guest-evidence.tar') as t:
  def get(n):return json.load(t.extractfile('./'+n))
  assert all(m.isfile() or m.isdir() for m in t.getmembers())
  reports={}
  for m in t.getmembers():
   if not m.isfile() or not m.name.endswith('.json'):continue
   v=get(m.name[2:])
   if isinstance(v,dict) and 'limitations' in v:
    assert 'not_an_export_permission' in v['limitations'] and 'RUSTUSB_PRIVATE' not in json.dumps(v)
    assert len(v['luns'])==2
    reports[m.name[2:-5]]=v
  result=get('result.json');assert result['helper_exit']==0 and result['passed']==expected
  commands=get('commands.json')
  if expected:
   assert len(reports)==10 and len(result['cases'])==12
   assert reports['idle']['uses']==reports['released']['uses']==[]
   assert reports['idle']['issues'] and reports['released']['issues']
   assert len(reports['idle']['blocks'])==4 and len(reports['crypt-holder']['blocks'])==5
   for name,kind in [('fd','block_fd'),('mapping','mapping'),('thread-fd','block_fd'),('mounted-file-fd','filesystem_fd'),('mounted-file-mapping','mapping'),('separate-mount-namespace','mount'),('swap','swap'),('crypt-holder','holder')]:
    assert any(u['kind']==kind for u in reports[name]['uses']),(trial,name)
   thread=[u for u in reports['thread-fd']['uses'] if u['kind']=='block_fd'];assert all(u['pid']!=u['tid'] for u in thread)
   assert any(b['dm_hint']=='crypt' and b['slaves'] for b in reports['crypt-holder']['blocks'])
   assert any(c['exit']==1 and 'requires root' in c['stdout'] and 'setpriv' in c['argv'] for c in commands)
   assert any(c['exit']==1 and 'unsafe device' in c['stdout'] and 'export' in c['argv'] for c in commands)
   identity=get('helper-identity.json')
   assert identity['exe_sha256']==gate['binaries']['target/release/rustusb-helper']['sha256']
   assert identity['cli_sha256']==gate['binaries']['target/release/rustusb']['sha256']
   children=[get(m.name[2:]) for m in t.getmembers() if m.isfile() and m.name.startswith('./child-exit-')]
   assert len(children)==6 and all(c['exit']==0 for c in children)
   for m in t.getmembers():
    if m.isfile() and m.name.startswith('./holder-proc-'):
     v=get(m.name[2:]);assert v['direct_map_files'] and not v['nested_map_files']
  else:
   assert reports['mapping']['uses']==[] and not reports['mapping']['busy_observed']
 checks.append({'kind':trial,'source_inputs':count,'expected_verdict':'PASS' if expected else 'FAIL','reports':len(reports)})
folder=pathlib.Path('/tmp/rustusb-storage-native-regression-20261026');d=load(folder/'result.json');q=load(folder/'qemu/summary.json')
assert d['passed'] and d['exit']==0 and all(d['guards'].values()) and q['result']=='PASS' and q['guest_exit_codes']=={'server':0,'client':0}
assert q['binary_sha256']['rustusb']==gate['binaries']['target/release/rustusb']['sha256'] and q['binary_sha256']['rustusb-helper']==gate['binaries']['target/release/rustusb-helper']['sha256']
for name,row in q['artifact_manifest'].items():
 b=(folder/'qemu'/name).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],name
checks.append({'kind':'native-regression','source_inputs':check_sources(d['head'],d['inputs']),'inner_source_inputs':check_sources(q['head'],q['source_inputs']),'original_artifacts':len(q['artifact_manifest']),'cycles':len(q['facts']['cycles'])})
(out/'result.json').write_text(json.dumps({'passed':True,'scope':'same-author read-only source/artifact/report verification; not another USB run or independent security audit','checks':checks},indent=2)+'\n')
print(json.dumps(checks),flush=True)

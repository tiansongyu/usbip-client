import datetime, hashlib, json, pathlib, subprocess, urllib.request

root = pathlib.Path('/home/ubuntu/github/usbip-client')
out = pathlib.Path('/tmp/rustusb-storage-publication-20261026')
head = '34b7cc62eb0670c7cfdbff3c34c02af366f7181d'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)
def sha(data):
    return hashlib.sha256(data).hexdigest()
assert git('rev-parse', 'HEAD').decode().strip() == head
assert not git('status', '--porcelain')
remote = git('ls-remote', 'origin', 'refs/heads/main')
(out / 'remote-content-head.txt').write_bytes(remote)
assert remote.decode().split()[0] == head
rows = []
for name in git('ls-files', 'website').decode().splitlines():
    relative = name.removeprefix('website/')
    url = 'https://tiansongyu.github.io/usbip-client/' + ('' if relative == 'index.html' else relative)
    with urllib.request.urlopen(url, timeout=30) as response:
        data = response.read()
        headers = list(response.headers.items())
        status = response.status
        final_url = response.url
    target = out / 'live' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    expected = git('show', head + ':' + name)
    row = {'source':name, 'url':url, 'final_url':final_url, 'status':status, 'headers':headers,
           'bytes':len(data), 'sha256':sha(data), 'git_sha256':sha(expected), 'equal':data==expected}
    rows.append(row)
    (out / 'live-http.json').write_text(json.dumps(rows, indent=2)+'\n')
    assert status == 200 and data == expected, name
gate = json.loads(pathlib.Path('/tmp/rustusb-storage-fixed-software-20261026/summary.json').read_text())
product = {n:v for n,v in gate['inputs'].items() if n.startswith(('crates/','apps/','vendor/')) or n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']}
for name,row in product.items():
    assert sha((root/name).read_bytes()) == row['sha256'], name
    assert sha(git('show', head+':'+name)) == row['sha256'], name
for name,row in gate['binaries'].items():
    assert sha((root/name).read_bytes()) == row['sha256'], name
qa = json.loads(pathlib.Path('/tmp/rustusb-storage-docs-20261026/result.json').read_text())
global_root = pathlib.Path('/home/ubuntu/.agents/skills/readme-site')
for name,expected in qa['global_readme_site'].items():
    assert sha((global_root/name).read_bytes()) == expected, name
assert pathlib.Path('/home/ubuntu/.codex/skills/readme-site').resolve() == global_root
result = {'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head':head,
          'remote_equal':True, 'clean':True, 'site_files':len(rows), 'all_http_200_and_git_bytes_equal':True,
          'product_inputs_unchanged':len(product), 'binaries':gate['binaries'],
          'global_readme_site':qa['global_readme_site'], 'discovery_symlink':True}
(out / 'content-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result), flush=True)

import hashlib, io, json, pathlib, re, subprocess, tarfile

root = pathlib.Path('/home/ubuntu/github/usbip-client')
src = pathlib.Path('/tmp/rustusb-storage-publication-20261026')
dst = root / 'docs/evidence/storage-inspection-publication-34b7cc62-20261026'
head = '34b7cc62eb0670c7cfdbff3c34c02af366f7181d'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip() == head
def sha(data):
    return hashlib.sha256(data).hexdigest()
def read(name):
    return json.loads((src/name).read_text())
runs = json.loads(read('runs-final.connector.json')['structuredContent']['content'])['workflow_runs']
assert len(runs) == 3
jobs = {}
for run in runs:
    assert run['head_sha'] == head and run['status'] == 'completed' and run['conclusion'] == 'success'
    current = read('jobs-final-'+str(run['id'])+'.connector.json')['structuredContent']['jobs']
    assert len(current) == (2 if run['name']=='Project website' else 4)
    for job in current:
        assert job['run_id'] == run['id'] and job['status'] == 'completed' and job['conclusion'] == 'success'
        assert job['steps'] and all(s['status']=='completed' and s['conclusion']=='success' for s in job['steps'])
    jobs[str(run['id'])] = current
summary = {'content_head':head,'primary_runs':[{k:r[k] for k in ['id','name','html_url','status','conclusion','head_sha']} for r in runs],
           'jobs':jobs,'http':read('live-http.json'),'content_verification':read('content-verification.json'),
           'browser':read('browser-observations.json'),
           'scope':'Primary run/job/step metadata and live site bytes only; no full CI log/ELF download or per-platform test-count recount. Initial .nojekyll HTTP 404 remains a separate failed request. No new USB execution. Full project goal and writable-storage acceptance remain incomplete.'}
(src/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
methods = {
    'methods/http-final-method.py':pathlib.Path('/tmp/check-rustusb-storage-publication-20261026.py').read_bytes(),
    'methods/collect.py':pathlib.Path(__file__).read_bytes(),
}
files = {}
for p in sorted(src.rglob('*')):
    if not p.is_file(): continue
    rel = p.relative_to(src).as_posix()
    assert p.is_symlink() is False and '.private' not in p.parts
    assert rel.startswith('live/') or p.suffix in ['.json','.txt','.log','.py'], rel
    files[rel] = p.read_bytes()
files.update(methods)
for name,data in files.items():
    assert not data.startswith((b'\x7fELF',b'QFI\xfb')) and b'-----BEGIN OPENSSH PRIVATE KEY-----' not in data, name
    assert not re.search(rb'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----',data), name
    assert not re.search(rb'(?i)(?:X-Amz-Signature|X-Goog-Signature|[?&]sig=)',data), name
assert not dst.exists()
dst.mkdir()
archive = dst/'originals.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644
        tar.addfile(info,io.BytesIO(data))
manifest={'scope':summary['scope'],'content_head':head,
          'archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},
          'files':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())}}
(dst/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(dst/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(files)
    for member in tar.getmembers():
        assert tar.extractfile(member).read() == files[member.name], member.name
print(json.dumps({'members':len(files),'raw_bytes':sum(map(len,files.values())),**manifest['archive']}),flush=True)

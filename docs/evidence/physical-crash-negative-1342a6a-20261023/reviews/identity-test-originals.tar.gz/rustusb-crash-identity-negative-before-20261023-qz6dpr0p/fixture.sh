#!/bin/sh
set -eu
ordinary_identity() { printf 'ordinary-rejected\n' >> "$TRACE"; return 1; }
readlink() { printf 'readlink-reached\n' >> "$TRACE"; printf '/not-authorized\n'; }
stat() { printf 'stat-reached\n' >> "$TRACE"; printf 'not-real\n'; }
jq() { printf 'jq-reached\n' >> "$TRACE"; printf '[]\n'; }
SERVER_PID=RUSTUSB_TEST_NONEXISTENT
SERVER_START=1
HID_NODE=/RUSTUSB_TEST/hid
FTDI_NODE=/RUSTUSB_TEST/ftdi
    server_identity() {
        ordinary_identity "$SERVER_PID" "$SERVER_START" || return 1
        : > /tmp/rustusb-crash-identity-negative-before-20261023-qz6dpr0p/fds.jsonl || return 1
        for node in "$HID_NODE" "$FTDI_NODE"; do
            found=false
            for fd in /proc/"$SERVER_PID"/fd/*; do
                if [ "$(readlink "$fd")" = "$node" ]; then
                    found=true
                    identity=$(stat -L -c '%d:%i:%t:%T' "$fd") || return 1
                    node_identity=$(stat -L -c '%d:%i:%t:%T' "$node") || return 1
                    [ "$identity" = "$node_identity" ] || return 1
                    jq -Mcn --arg node "$node" --arg fd "${fd##*/}" --arg identity "$identity" '{node:$node,fd:($fd|tonumber),identity:$identity}' >> /tmp/rustusb-crash-identity-negative-before-20261023-qz6dpr0p/fds.jsonl || return 1
                fi
            done
            [ "$found" = true ] || return 1
        done
        jq -s '.' /tmp/rustusb-crash-identity-negative-before-20261023-qz6dpr0p/fds.jsonl > /tmp/rustusb-crash-identity-negative-before-20261023-qz6dpr0p/fds.json || return 1
        jq -Mcn --argjson pid "$SERVER_PID" --argjson start "$SERVER_START" --slurpfile fds /tmp/rustusb-crash-identity-negative-before-20261023-qz6dpr0p/fds.json \
            '{pid:$pid,starttime:$start,exe:"/usr/bin/rustusb",uids:[1000,1000,1000,1000],cap_effective:0,cap_permitted:0,cap_ambient:0,fds:$fds[0]}' > /tmp/rustusb-crash-identity-negative-before-20261023-qz6dpr0p/identity.json || return 1
    }
if server_identity; then result=0; else result=$?; fi
printf 'conditional_function_status=%s\n' "$result"

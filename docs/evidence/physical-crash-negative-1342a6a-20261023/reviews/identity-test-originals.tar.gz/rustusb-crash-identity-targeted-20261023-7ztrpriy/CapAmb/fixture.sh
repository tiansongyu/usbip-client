#!/bin/sh
set -eu
kill() { printf 'kill\n' >> "$TRACE"; [ "$CASE" != kill ]; }
readlink() { printf 'exe\n' >> "$TRACE"; if [ "$CASE" = exe ]; then printf '/incorrect/executable\n'; else printf '/usr/bin/rustusb\n'; fi; }
awk() {
 case "$*" in
 *'print $22'*) tag=start; value=123; [ "$CASE" != start ] || value=999 ;;
 *'^Uid:'*) tag=uid; value=1000:1000:1000:1000; [ "$CASE" != uid ] || value=1001:1001:1001:1001 ;;
 *'cap=CapEff:'*) tag=CapEff; value=0000000000000000; [ "$CASE" != CapEff ] || value=0000000000000001 ;;
 *'cap=CapPrm:'*) tag=CapPrm; value=0000000000000000; [ "$CASE" != CapPrm ] || value=0000000000000001 ;;
 *'cap=CapAmb:'*) tag=CapAmb; value=0000000000000000; [ "$CASE" != CapAmb ] || value=0000000000000001 ;;
 *) return 22 ;;
 esac
 printf '%s\n' "$tag" >> "$TRACE"; printf '%s\n' "$value"
}
ordinary_identity() {
    kill -0 "$1" || return 1
    [ "$(readlink "/proc/$1/exe")" = /usr/bin/rustusb ] || return 1
    [ "$(awk '{print $22}' "/proc/$1/stat")" = "$2" ] || return 1
    [ "$(awk '/^Uid:/ {print $2 ":" $3 ":" $4 ":" $5}' "/proc/$1/status")" = 1000:1000:1000:1000 ] || return 1
    for cap in CapEff CapPrm CapAmb; do
        [ "$(awk -v cap="$cap:" '$1 == cap {print $2}' "/proc/$1/status")" = 0000000000000000 ] || return 1
    done
}
if ordinary_identity RUSTUSB_TEST_NO_HOST_PID 123; then status=0; else status=$?; fi
printf "status=%s\n" "$status"

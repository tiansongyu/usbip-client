ordinary_identity() {
    kill -0 "$1" || return 1
    [ "$(readlink "/proc/$1/exe")" = /usr/bin/rustusb ] || return 1
    [ "$(awk '{print $22}' "/proc/$1/stat")" = "$2" ] || return 1
    [ "$(awk '/^Uid:/ {print $2 ":" $3 ":" $4 ":" $5}' "/proc/$1/status")" = 1000:1000:1000:1000 ] || return 1
    for cap in CapEff CapPrm CapAmb; do
        [ "$(awk -v cap="$cap:" '$1 == cap {print $2}' "/proc/$1/status")" = 0000000000000000 ] || return 1
    done
}

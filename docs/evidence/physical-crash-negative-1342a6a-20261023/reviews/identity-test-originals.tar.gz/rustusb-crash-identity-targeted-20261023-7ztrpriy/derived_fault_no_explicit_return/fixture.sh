#!/bin/sh
set -eu
ordinary_identity() { printf 'ordinary\n' >> "$TRACE"; [ "$CASE" != ordinary ]; }
readlink() { printf 'readlink\n' >> "$TRACE"; if [ "$CASE" = missing_fd ]; then printf '/non-authorized\n'; else printf '%s\n' "$node"; fi; }
stat() {
 printf 'stat:%s\n' "$*" >> "$TRACE"
 case "$*" in
 *'/fd/'*) [ "$CASE" != fd_stat_error ] || return 17; if [ "$CASE" = mismatch ]; then printf 'wrong\n'; else printf 'same\n'; fi ;;
 *) [ "$CASE" != node_stat_error ] || return 18; printf 'same\n' ;;
 esac
}
jq() { printf 'jq\n' >> "$TRACE"; [ "$CASE" != jq_error ] || return 19; printf '[]\n'; }
SERVER_PID=RUSTUSB_TEST_NO_HOST_PID
SERVER_START=123
HID_NODE=/RUSTUSB_TEST/hid
FTDI_NODE=/RUSTUSB_TEST/ftdi
    server_identity() {
        ordinary_identity "$SERVER_PID" "$SERVER_START"
        : > /tmp/rustusb-crash-identity-targeted-20261023-7ztrpriy/derived_fault_no_explicit_return/fds.jsonl
        for node in "$HID_NODE" "$FTDI_NODE"; do
            found=false
            for fd in /proc/"$SERVER_PID"/fd/*; do
                if [ "$(readlink "$fd")" = "$node" ]; then
                    found=true
                    identity=$(stat -L -c '%d:%i:%t:%T' "$fd")
                    node_identity=$(stat -L -c '%d:%i:%t:%T' "$node")
                    [ "$identity" = "$node_identity" ]
                    jq -Mcn --arg node "$node" --arg fd "${fd##*/}" --arg identity "$identity" '{node:$node,fd:($fd|tonumber),identity:$identity}' >> /tmp/rustusb-crash-identity-targeted-20261023-7ztrpriy/derived_fault_no_explicit_return/fds.jsonl
                fi
            done
            [ "$found" = true ]
        done
        jq -s '.' /tmp/rustusb-crash-identity-targeted-20261023-7ztrpriy/derived_fault_no_explicit_return/fds.jsonl > /tmp/rustusb-crash-identity-targeted-20261023-7ztrpriy/derived_fault_no_explicit_return/fds.json
        jq -Mcn --argjson pid "$SERVER_PID" --argjson start "$SERVER_START" --slurpfile fds /tmp/rustusb-crash-identity-targeted-20261023-7ztrpriy/derived_fault_no_explicit_return/fds.json \
            '{pid:$pid,starttime:$start,exe:"/usr/bin/rustusb",uids:[1000,1000,1000,1000],cap_effective:0,cap_permitted:0,cap_ambient:0,fds:$fds[0]}' > /tmp/rustusb-crash-identity-targeted-20261023-7ztrpriy/derived_fault_no_explicit_return/identity.json
    }
if server_identity; then status=0; else status=$?; fi
printf "status=%s\n" "$status"

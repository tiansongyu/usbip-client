import pathlib,json,hashlib,tarfile,io,shutil
root=pathlib.Path('/home/ubuntu/github/usbip-client');out=root/'docs/evidence/native-gui-filter-03621a06-20261025';out.mkdir(parents=True,exist_ok=False)
files={}
for label,base in [('software',pathlib.Path('/tmp/rustusb-native-gui-gates-filter-20261025')),('qemu',pathlib.Path('/tmp/rustusb-native-gui-qemu-filter-20261025'))]:
 for p in base.rglob('*'):
  if p.is_file():files[label+'/'+str(p.relative_to(base))]=p.read_bytes()
files['qemu/original-runner.log']=pathlib.Path('/tmp/rustusb-native-gui-qemu-filter-20261025-runner.log').read_bytes()
for name in ['archive-rustusb-native-gui-filter-20261025.py','run-rustusb-native-gui-filter-gates-20261025.py']:files['methods/'+name]=(pathlib.Path('/tmp')/name).read_bytes()
manifest=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in sorted(files.items())]
archive=out/'originals.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for n,b in sorted(files.items()):
  assert not b.startswith(b'\x7fELF')and '.private'not in pathlib.Path(n).parts
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;t.addfile(info,io.BytesIO(b))
with tarfile.open(archive)as t:
 assert len(t.getmembers())==len(manifest)
 for x in manifest:assert hashlib.sha256(t.extractfile(x['path']).read()).hexdigest()==x['sha256']
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for label,base in [('software','/tmp/rustusb-native-gui-gates-filter-20261025'),('qemu','/tmp/rustusb-native-gui-qemu-filter-20261025')]:shutil.copyfile(pathlib.Path(base)/'summary.json',out/(label+'-summary.json'))
receipt={'files':len(manifest),'bytes':sum(x['bytes']for x in manifest),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'scope':'Final GUI local-filter correction/software/native QEMU originals. Prior 08/b15/72 and all failures stay in the original independent archive; no private key/ELF/rootfs/host USB inventory.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt)

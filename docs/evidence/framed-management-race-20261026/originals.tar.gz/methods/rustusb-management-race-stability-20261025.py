from pathlib import Path
import hashlib,json,re,subprocess,time
root=Path('/home/ubuntu/github/usbip-client');out=Path('/tmp/rustusb-management-race-20261025/stability');out.mkdir()
log=(out.parent/'owned-close-transport-suite.log').read_text()
binary=root/re.search(r'Running unittests .*\((target/[^)]+)\)',log).group(1)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip()
names=['link::tests::half_close_keeps_cached_bytes_and_reverse_direction_until_actual_consumption','tls::tests::link::completed_framed_peer_close_survives_delayed_final_tls_read']
rows=[]
for round_id in range(32):
 for name in names:
  file=out/(str(round_id).zfill(2)+'-'+name.rsplit('::',1)[1]+'.log')
  with file.open('wb') as stream:p=subprocess.run([str(binary),'--exact',name,'--nocapture'],cwd=root,stdout=stream,stderr=subprocess.STDOUT)
  rows.append({'round':round_id,'test':name,'exit':p.returncode,'log':file.name})
summary={'head':head,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'commands':rows,'passed':sum(r['exit']==0 for r in rows),'failed':sum(r['exit']!=0 for r in rows),'head_guard':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head,'clean_guard':not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip()}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='commands'}),flush=True)
assert summary['passed']==64 and summary['failed']==0 and summary['head_guard'] and summary['clean_guard']

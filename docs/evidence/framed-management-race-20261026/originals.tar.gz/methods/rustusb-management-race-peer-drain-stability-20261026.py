from pathlib import Path
import hashlib,json,re,subprocess
root=Path('/home/ubuntu/github/usbip-client');base=Path('/tmp/rustusb-management-race-20261025');out=base/'peer-drain-stability';out.mkdir()
def binary(log):return root/re.search(r'Running unittests .*\((target/[^)]+)\)',(base/log).read_text()).group(1)
transport=binary('final-peer-drain-transport-suite.log');service=binary('final-peer-drain-concurrent.log')
cases=[(transport,'link::tests::half_close_keeps_cached_bytes_and_reverse_direction_until_actual_consumption'),(transport,'tls::tests::link::completed_framed_peer_write_close_retains_owner_until_final_tls_read'),(service,'jobs::management_tests::concurrent_catalogs_keep_complete_replies_and_join_every_actual_owner')]
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
head=git('rev-parse','HEAD');assert not git('status','--porcelain');hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [transport,service]};rows=[]
for iteration in range(32):
 for exe,name in cases:
  file=out/(str(iteration).zfill(2)+'-'+name.rsplit('::',1)[1]+'.log')
  with file.open('wb') as f:p=subprocess.run([str(exe),'--exact',name,'--nocapture'],cwd=root,stdout=f,stderr=subprocess.STDOUT)
  rows.append({'round':iteration,'test':name,'exit':p.returncode,'log':file.name,'exactly_one_test':bool(re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored;',file.read_text()))})
summary={'head':head,'binary_sha256':hashes,'commands':rows,'passed':sum(r['exit']==0 and r['exactly_one_test'] for r in rows),'failed':sum(r['exit']!=0 or not r['exactly_one_test'] for r in rows),'head_guard':git('rev-parse','HEAD')==head,'clean_guard':not git('status','--porcelain'),'binary_guard':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in hashes.items())}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='commands'}),flush=True)
assert summary['passed']==96 and not summary['failed'] and all(summary[k] for k in ['head_guard','clean_guard','binary_guard'])

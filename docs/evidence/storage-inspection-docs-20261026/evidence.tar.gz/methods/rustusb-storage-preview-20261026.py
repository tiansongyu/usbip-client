import functools,http.server,json,os,pathlib
root=pathlib.Path('/tmp/rustusb-storage-preview-20261026');root.mkdir(exist_ok=False)
(root/'usbip-client').symlink_to('/home/ubuntu/github/usbip-client/website',target_is_directory=True)
class Handler(http.server.SimpleHTTPRequestHandler):
 def end_headers(self):
  if self.path.startswith('/nojs/'):
   self.send_header('Content-Security-Policy',"script-src 'none'")
  super().end_headers()
(root/'nojs').symlink_to('/home/ubuntu/github/usbip-client/website',target_is_directory=True)
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(root)))
receipt={'pid':os.getpid(),'port':server.server_port};(root/'receipt.json').write_text(json.dumps(receipt)+'\n');print(json.dumps(receipt),flush=True)
try:server.serve_forever()
except KeyboardInterrupt:pass
finally:server.server_close()

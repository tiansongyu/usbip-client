import hashlib,importlib.util,json,pathlib,re,subprocess,urllib.parse,tarfile
root=pathlib.Path('/home/ubuntu/github/usbip-client');out=pathlib.Path('/tmp/rustusb-storage-docs-20261026')
spec=importlib.util.spec_from_file_location('site',root/'scripts/check-site.py');site=importlib.util.module_from_spec(spec);spec.loader.exec_module(site)
files=['README.md','README.zh-CN.md','AGENTS.md','.agents/skills/rustusb-development/SKILL.md','docs/storage-inspection.md','docs/research/storage-inspection-design.md','docs/research/storage-inspection-validation.md','docs/acceptance.md','docs/compatibility.md','docs/roadmap.md','docs/testing.md','docs/security.md','docs/architecture.md','docs/third-party.md','docs/work-log.md','scripts/qemu_storage/README.md','docs/evidence/storage-inspection-20261026/README.md']
checks=[]
for name in files:
 p=root/name
 for link in re.findall(r'\[[^\]\n]*\]\(([^\s)]+)\)',p.read_text()):
  parsed=urllib.parse.urlsplit(link)
  if parsed.scheme or parsed.netloc:continue
  target=(p.parent/urllib.parse.unquote(parsed.path)).resolve() if parsed.path else p
  assert target.exists(),(name,link)
  if parsed.fragment and target.suffix=='.md':assert urllib.parse.unquote(parsed.fragment) in site.markdown_ids(target),(name,link)
  checks.append({'file':name,'target':link})
# Only product/build inputs must stay equal after documentation updates.
gate=json.loads(pathlib.Path('/tmp/rustusb-storage-fixed-software-20261026/summary.json').read_text())
product={n:v for n,v in gate['inputs'].items() if n.startswith(('crates/','apps/','vendor/')) or n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']}
for n,v in product.items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==v['sha256'],n
for n,v in gate['binaries'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==v['sha256'],n
manifest=json.loads((root/'docs/evidence/storage-inspection-20261026/manifest.json').read_text());archive=root/'docs/evidence/storage-inspection-20261026/evidence.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archive']['sha256']
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(manifest['files'])
 for m in t.getmembers():
  b=t.extractfile(m).read();row=manifest['files'][m.name];assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
global_root=pathlib.Path('/home/ubuntu/.agents/skills/readme-site')
expected={'SKILL.md':'83514d886ff1f1ff17585805a89508f35f60bb326a3dd9592f42fa52198a26f3','agents/openai.yaml':'61c795ad1d34ded25f1e2b8a799c45fea9b66abd32717c505ffe5b474c35e5cb','references/readme.md':'995cb45f62c0ae8bcec45092267f67eec73633474bf59d0a8047c8a48b4b713b','references/site.md':'82624a1db23c94ed3767ea47996311cd065f8510d6649eec20a11875cca1a24b'}
for n,h in expected.items():assert hashlib.sha256((global_root/n).read_bytes()).hexdigest()==h,n
assert pathlib.Path('/home/ubuntu/.codex/skills/readme-site').resolve()==global_root
snap=out/'snapshots';snap.mkdir()
for n in [*files,'website/index.html']:
 p=snap/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/n).read_bytes())
result={'passed':True,'document_files':len(files),'local_link_checks':len(checks),'product_input_guard':len(product),'binary_guard':list(gate['binaries']),'evidence_members':len(manifest['files']),'global_readme_site':expected,'codex_discovery_symlink':True}
(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

from pathlib import Path
import json,hashlib,tarfile,gzip,io,shutil,re
root=Path('/home/ubuntu/github/usbip-client');src=Path('/tmp/rustusb-storage-policy-publication-20261026');head='32f345c6d09c0df724ab3bcdcaba9c8303dc7ae9'
rows=json.loads((src/'runs-final.json').read_text())['workflow_runs'];expected={40339684834:4,40339685702:4,40339684705:2}
assert {r['id']for r in rows}==set(expected)
for r in rows:assert r['head_sha']==head and r['event']=='push' and r['status']=='completed' and r['conclusion']=='success'
for run_id,count in expected.items():
 o=json.loads((src/f'jobs-final-{run_id}.json').read_text());assert not o.get('isError');sc=o['structuredContent'];groups=sc if isinstance(sc,list) else [sc];jobs=[j for group in groups for j in group.get('jobs',[])];assert len(jobs)==count
 assert all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
 if count==4:assert {j['name']for j in jobs}=={'check (ubuntu-22.04, x86_64)','check (ubuntu-24.04, x86_64)','check (ubuntu-22.04-arm, aarch64)','check (ubuntu-24.04-arm, aarch64)'}
http=json.loads((src/'live/http.json').read_text());assert len(http)==8 and all(r['status']==200 and r['matches_content_32f345c6'] for r in http)
shutil.copy(__file__,src/Path(__file__).name)
dest=root/'docs/evidence/storage-policy-publication-32f345c6-20261026';assert not dest.exists();dest.mkdir()
files={p.relative_to(src).as_posix():p.read_bytes() for p in src.rglob('*') if p.is_file()}
for n,b in files.items():
 assert '.private' not in Path(n).parts and not b.startswith(b'\x7fELF')
 assert not re.search(rb'-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----\s*\n',b)
 assert not re.search(rb'(?i)(?:[?&]X-Amz-Signature=|[?&]sig=[A-Za-z0-9%]{24})',b)
archive=dest/'evidence.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as t:
 for n,b in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for m in t.getmembers():assert t.extractfile(m).read()==files[m.name]
manifest={'content_head':head,'scope':'push/primary workflow API metadata/connector job status and eight canonical live HTTP byte checks; no downloaded CI logs or executable artifacts','archive':'evidence.tar.gz','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in sorted(files.items())}}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'members':len(files),'raw_bytes':sum(map(len,files.values())),'gzip_bytes':manifest['bytes'],'sha256':manifest['sha256']}))

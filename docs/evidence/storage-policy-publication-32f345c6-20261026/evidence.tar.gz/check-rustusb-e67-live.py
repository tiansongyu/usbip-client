from pathlib import Path
import urllib.request,json,hashlib
root=Path('/home/ubuntu/github/usbip-client/website');out=Path('/tmp/rustusb-storage-policy-publication-20261026/live');out.mkdir(exist_ok=True)
paths=['','index.html','styles.css','app.js',*[str(p.relative_to(root))for p in sorted((root/'assets').iterdir()) if p.is_file()]]
rows=[]
for path in paths:
 url='https://tiansongyu.github.io/usbip-client/'+path
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'RustUSB-publication-check'}),timeout=30) as r:
  data=r.read();headers=dict(r.headers);status=r.status
 dest=out/('root.html' if not path else path);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 expected=(root/(path or 'index.html')).read_bytes();row={'url':url,'status':status,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'matches_content_32f345c6':data==expected,'headers':headers};rows.append(row)
 (out/'http.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert status==200 and data==expected,row
print(json.dumps({'requests':len(rows),'all_200':True,'all_content_bytes_match':True}))

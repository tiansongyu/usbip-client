import gzip,hashlib,io,json,pathlib,tarfile

source=pathlib.Path('/tmp/rustusb-arm64-virtual-publication-20261026')
target=pathlib.Path('/home/ubuntu/github/usbip-client/docs/evidence/arm64-virtual-publication-dd880309-20261026')
target.mkdir(parents=True,exist_ok=False)
head='dd88030956ab0a8a5177abec08dff04d5b088385'
read=lambda n:json.loads((source/n).read_text())
runs=json.loads(read('e64runs4.json')['content'])['workflow_runs']
assert len(runs)==3 and all(r['head_sha']==head and r['status']=='completed' and r['conclusion']=='success' for r in runs)
jobs={}
for name in ['e64jobs3_40304757716.json','e64jobsFinalGui.json','e64jobs1_40304757421.json']:
    rows=read(name)['jobs']
    assert all(j['status']=='completed' and j['conclusion']=='success' for j in rows)
    jobs[str(rows[0]['run_id'])]=rows
http=read('http-summary.json');assert len(http)==8 and all(r['status']==200 and r['exact_source_bytes'] for r in http)
summary={'content_head':head,'primary_runs':[{'id':r['id'],'name':r['name'],'url':r['html_url'],'status':r['status'],'conclusion':r['conclusion']} for r in runs],
         'jobs':jobs,'http_responses':8,'exact_http_source':True,'live_browser':read('live-browser.json'),
         'scope':'Primary API run/job/step status, canonical HTTP bodies and actual browser DOM. No complete CI logs, new binary execution or per-platform Cargo count reconstruction.'}
(source/'publication-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
members={p.name:p.read_bytes() for p in source.iterdir() if p.is_file()}
members['collector.py']=pathlib.Path(__file__).read_bytes()
archive=target/'originals.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(filename='',fileobj=output,mode='wb',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for name,data in sorted(members.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    assert tar.getnames()==sorted(members)
    assert all(tar.extractfile(n).read()==b for n,b in members.items())
manifest={'content_head':head,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
          'archive_bytes':archive.stat().st_size,'members':[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(members.items())]}
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'members':len(members),'raw_bytes':sum(map(len,members.values())),
                  'archive_bytes':manifest['archive_bytes'],'archive_sha256':manifest['archive_sha256']}))

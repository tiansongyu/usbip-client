//! Bounded local transport authenticated with kernel Unix peer credentials.

use crate::{
    config::{Action, LoadedConfig, Manifest},
    fs::Directory,
    rpc::*,
    runtime::{Command, Controls, Runtime},
};
use rustix::fs::{AtFlags, FileType, Mode, OFlags};
use rustusb_core::{Error, Result};
use std::{
    fs::File,
    os::unix::fs::{MetadataExt, PermissionsExt},
    path::{Component, Path},
    sync::{Arc, Mutex},
    time::Duration,
};
use tokio::{
    io::{AsyncReadExt, AsyncWriteExt},
    net::{UnixListener, UnixStream},
    sync::{Semaphore, mpsc, oneshot, watch},
    task::JoinSet,
};

const MAX_FRAME: usize = 65536;
const DEADLINE: Duration = Duration::from_secs(5);

struct Endpoint {
    directory: Directory,
    _lock: File,
    listener: UnixListener,
    identity: (u64, u64),
    uid: u32,
}
impl Endpoint {
    async fn bind(manifest: &Manifest) -> Result<Self> {
        let directory = Directory::open(&manifest.control_directory, manifest.broker_uid, 0o711)?;
        let lock = directory.lock()?;
        let path = manifest.socket_path();
        if let Some(identity) = socket_identity(&directory.file, manifest.broker_uid)? {
            let connected =
                tokio::time::timeout(Duration::from_secs(1), UnixStream::connect(&path)).await;
            match connected {
                Ok(Err(error)) if error.kind() == std::io::ErrorKind::ConnectionRefused => {}
                _ => {
                    return Err(Error::State(
                        "existing agent socket is active or cannot safely be classified".into(),
                    ));
                }
            }
            directory.verify()?;
            if socket_identity(&directory.file, manifest.broker_uid)? != Some(identity) {
                return Err(Error::State("stale agent socket changed".into()));
            }
            rustix::fs::unlinkat(&directory.file, "control.sock", AtFlags::empty())
                .map_err(std::io::Error::from)?;
        }
        directory.verify()?;
        let listener = UnixListener::bind(&path)?;
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o666))?;
        directory.verify()?;
        let identity = socket_identity(&directory.file, manifest.broker_uid)?
            .ok_or_else(|| Error::State("new agent socket disappeared".into()))?;
        directory.file.sync_all()?;
        Ok(Self {
            directory,
            _lock: lock,
            listener,
            identity,
            uid: manifest.broker_uid,
        })
    }
    fn unlink(&self) -> Result<()> {
        self.directory.verify()?;
        if socket_identity(&self.directory.file, self.uid)? != Some(self.identity) {
            return Err(Error::State(
                "agent socket identity changed before close".into(),
            ));
        }
        rustix::fs::unlinkat(&self.directory.file, "control.sock", AtFlags::empty())
            .map_err(std::io::Error::from)?;
        self.directory.file.sync_all()?;
        Ok(())
    }
}

fn socket_identity(directory: &File, uid: u32) -> Result<Option<(u64, u64)>> {
    let stat = match rustix::fs::statat(directory, "control.sock", AtFlags::SYMLINK_NOFOLLOW) {
        Ok(s) => s,
        Err(rustix::io::Errno::NOENT) => return Ok(None),
        Err(e) => return Err(std::io::Error::from(e).into()),
    };
    if FileType::from_raw_mode(stat.st_mode) != FileType::Socket
        || stat.st_uid != uid
        || stat.st_mode & 0o7777 != 0o666
    {
        return Err(Error::Permission("agent socket owner/type/mode".into()));
    }
    Ok(Some((stat.st_dev, stat.st_ino)))
}

/// Run the nonroot application service until cooperative stop and actual job cleanup.
/// The caller must await this future; cancelling its owning task is not cleanup.
pub async fn serve(config: LoadedConfig, stop: watch::Receiver<bool>) -> Result<()> {
    serve_with_logging(config, stop, None).await
}

/// Run with a nonowning logger monitor for authorized reads and committed audit mirrors.
/// The caller retains the actual log owner and joins it after this service's USB
/// owners and durable records finish. Log health never substitutes for WAL health.
pub async fn serve_with_logging(
    config: LoadedConfig,
    stop: watch::Receiver<bool>,
    logging: Option<rustusb_logging::LogMonitor>,
) -> Result<()> {
    serve_with_automation(config, stop, logging, None).await
}

/// Run with explicit root-managed automation delegation in addition to existing
/// OS/profile ACLs. The policy must be loaded in the caller's retained startup
/// task. Absence disables automation; service shutdown still joins every owner.
pub async fn serve_with_automation(
    config: LoadedConfig,
    mut stop: watch::Receiver<bool>,
    logging: Option<rustusb_logging::LogMonitor>,
    policy: Option<crate::automation::AutomationPolicy>,
) -> Result<()> {
    if rustix::process::geteuid().as_raw() != config.manifest.broker_uid
        || config.manifest.broker_uid == 0
    {
        return Err(Error::Permission(
            "agent must run as configured nonroot broker".into(),
        ));
    }
    let config = Arc::new(config);
    let controls = Arc::new(Mutex::new(Controls::default()));
    let mut runtime = match logging.clone() {
        Some(monitor) => {
            Runtime::open_with_logging(config.clone(), controls.clone(), Some(monitor)).await?
        }
        None => Runtime::open(config.clone(), controls.clone()).await?,
    };
    runtime.configure_automation(policy).await?;
    let endpoint = Endpoint::bind(&config.manifest).await?;
    let diagnostics = runtime.diagnostics();
    let (sender, receiver) = mpsc::channel(16);
    let (shutdown, shutdown_receiver) = watch::channel(*stop.borrow());
    let mut owner = tokio::spawn(runtime.run(receiver, shutdown_receiver));
    let permits = Arc::new(Semaphore::new(16));
    let mut requests = JoinSet::new();
    let mut accept_error = None;
    if !*stop.borrow() {
        loop {
            tokio::select! {
                changed=stop.changed()=>{let _=changed;break;},
                result=&mut owner=>{
                    // No job can remain when the supervisor returns normally.
                    while let Some(result)=requests.join_next().await{let _=result;}
                    endpoint.unlink()?;
                    return result.map_err(|_|Error::State("agent supervisor task ended abnormally".into()))?;
                },
                result=requests.join_next(),if !requests.is_empty()=>{let _=result;},
                accepted=endpoint.listener.accept()=>{
                    let (stream,_)=match accepted{Ok(pair)=>pair,Err(error)=>{accept_error=Some(error);break;}};
                    let Ok(permit)=permits.clone().try_acquire_owned()else{drop(stream);continue;};
                    let sender=sender.clone();let config=config.clone();let controls=controls.clone();let logging=logging.clone();let diagnostics=diagnostics.clone();
                    requests.spawn(async move{let _permit=permit;let _=tokio::time::timeout(DEADLINE,request(stream,sender,config,controls,logging,Some(diagnostics))).await;});
                },
            }
        }
    }
    let shutdown_result = request_shutdown(&controls, &shutdown);
    // Request tasks own no device capability. Their individual bounded deadline
    // completes while the real supervisor continues handling cleanup facts.
    while let Some(result) = requests.join_next().await {
        let _ = result;
    }
    drop(sender);
    let result = owner
        .await
        .map_err(|_| Error::State("agent supervisor task ended abnormally".into()))
        .and_then(|result| result);
    let endpoint_result = endpoint.unlink();
    let result = match (result, shutdown_result) {
        (Err(owner), Err(stop)) => Err(Error::State(format!(
            "agent stop delivery: {stop}; supervisor: {owner}"
        ))),
        (Err(error), _) | (_, Err(error)) => Err(error),
        (Ok(()), Ok(())) => Ok(()),
    };
    result?;
    endpoint_result?;
    if let Some(error) = accept_error {
        return Err(error.into());
    }
    Ok(())
}

// Stop delivery cannot depend on a store transaction finishing. This is only
// cooperative control, never a durable response or terminal/cleanup receipt.
pub(crate) fn request_shutdown(
    controls: &Mutex<Controls>,
    shutdown: &watch::Sender<bool>,
) -> Result<()> {
    let result = match controls.lock() {
        Ok(mut controls) => {
            controls.begin_shutdown();
            Ok(())
        }
        Err(poisoned) => {
            // Send stop to every still-represented owner even after poison.
            // Report the failure after the caller has joined the supervisor.
            poisoned.into_inner().begin_shutdown();
            Err(Error::State(
                "agent controls lock poisoned during stop".into(),
            ))
        }
    };
    shutdown.send_replace(true);
    result
}

pub(crate) async fn request(
    mut stream: UnixStream,
    sender: mpsc::Sender<Command>,
    config: Arc<LoadedConfig>,
    controls: Arc<Mutex<Controls>>,
    logging: Option<rustusb_logging::LogMonitor>,
    diagnostics: Option<Arc<crate::diagnostics::Registry>>,
) -> Result<()> {
    let uid = stream.peer_cred()?.uid();
    let envelope: RequestEnvelope = serde_json::from_slice(&read_frame(&mut stream).await?)
        .map_err(|_| Error::InvalidInput("agent request schema".into()))?;
    if envelope.schema_version != 1 {
        return Err(Error::InvalidInput("agent protocol version".into()));
    }
    if let Some(Ok(response)) = crate::diagnostics::respond(
        diagnostics.as_deref(),
        &config.manifest,
        uid,
        &envelope.request,
    ) {
        // Every authorized outcome, including invalid/expired/Busy, stays out
        // of the WAL actor. Denials continue below through its audited path.
        let journal_healthy = controls
            .lock()
            .map_err(|_| Error::State("agent controls lock poisoned".into()))?
            .journal_healthy();
        let response = ResponseEnvelope {
            schema_version: 1,
            journal_healthy,
            response,
        };
        let encoded = serde_json::to_vec(&response);
        let bytes = match encoded {
            Ok(bytes) if bytes.len() <= MAX_FRAME => bytes,
            _ => serde_json::to_vec(&ResponseEnvelope {
                schema_version: 1,
                journal_healthy,
                response: Response::DiagnosticError {
                    code: crate::diagnostics::DiagnosticFailure::EncodingLimit,
                },
            })
            .map_err(|_| Error::State("agent diagnostic encoding".into()))?,
        };
        return write_frame(&mut stream, &bytes).await;
    }
    if let Request::ReadLogs {
        profile,
        after,
        limit,
    } = &envelope.request
        && config
            .manifest
            .authorize(uid, profile, Action::Audit)
            .is_ok()
    {
        // Authorization precedes cursor/history evaluation and reader admission.
        // Every authorized result bypasses WAL, including Busy/disabled/errors.
        // The logging owner retains real readers after this RPC is cancelled.
        let result = if !(1..=rustusb_logging::MAX_PAGE_RECORDS).contains(limit) {
            Err(rustusb_logging::Error::InvalidInput("log page limit"))
        } else if let Some(monitor) = logging.as_ref() {
            monitor
                .read(
                    rustusb_logging::ReadFilter::Audit {
                        profile: profile.clone(),
                        actor_uid: uid,
                        root_admin: uid == 0,
                    },
                    after.clone(),
                    *limit,
                )
                .await
        } else {
            Err(rustusb_logging::Error::Disabled)
        };
        let response = match result {
            Ok(page) => Response::Logs { page },
            Err(error) => Response::LogError {
                code: LogReadFailure::from(&error),
            },
        };
        // No Controls/Store guard is held during filesystem I/O. The envelope
        // reports current business health, independently of the logger result.
        let journal_healthy = controls
            .lock()
            .map_err(|_| Error::State("agent controls lock poisoned".into()))?
            .journal_healthy();
        let bytes = serde_json::to_vec(&ResponseEnvelope {
            schema_version: 1,
            journal_healthy,
            response,
        })
        .map_err(|_| Error::State("agent log response encoding".into()))?;
        return write_frame(&mut stream, &bytes).await;
    }
    if let Request::ServerSecurity { profile } | Request::ServerAdmission { profile } =
        &envelope.request
        && config
            .manifest
            .authorize(uid, profile, Action::Read)
            .is_ok()
    {
        // All authorized results, including client-profile Unsupported, bypass
        // WAL. No credentials, stream or device owner enter this response.
        let response = {
            let controls = controls
                .lock()
                .map_err(|_| Error::State("agent controls lock poisoned".into()))?;
            let result = if matches!(&envelope.request, Request::ServerAdmission { .. }) {
                controls.admission(&config, uid, profile)
            } else {
                controls.security(&config, uid, profile)
            };
            match result {
                Ok(response) => response,
                Err(error) => ResponseEnvelope {
                    schema_version: 1,
                    journal_healthy: controls.journal_healthy(),
                    response: Response::Error {
                        code: crate::model::Failure::from_error(&error),
                    },
                },
            }
        };
        let bytes = serde_json::to_vec(&response)
            .map_err(|_| Error::State("agent security response encoding".into()))?;
        return write_frame(&mut stream, &bytes).await;
    }
    // Health reads are independent of a stalled WAL actor. Authorization and
    // the finite registry are still the same fixed-profile OS-UID boundary.
    if let Request::SessionHealth { profile, after } = &envelope.request {
        let response = controls
            .lock()
            .map_err(|_| Error::State("agent controls lock poisoned".into()))?
            .health(&config, uid, profile, after.as_ref());
        if let Ok(response) = response {
            let bytes = serde_json::to_vec(&response)
                .map_err(|_| Error::State("agent health encoding".into()))?;
            return write_frame(&mut stream, &bytes).await;
        }
        // Denied/invalid reads use the existing actor error and audit path.
        // Only authorized successful observations bypass a stalled journal.
    }
    // Every authorized rule observation stays independent of WAL, including an
    // unavailable/empty policy. Mutations/retries retain original actor ordering.
    let read_rule = match &envelope.request {
        Request::Rules { profile, .. } => Some((profile, Action::Read)),
        Request::RuleDecisionSupport { profile } => Some((profile, Action::Read)),
        Request::RuleEvents { profile, .. } => Some((profile, Action::Audit)),
        _ => None,
    };
    if let Some((profile, action)) = read_rule
        && config.manifest.authorize(uid, profile, action).is_ok()
    {
        let response = {
            let controls = controls
                .lock()
                .map_err(|_| Error::State("agent controls lock poisoned".into()))?;
            let result = match &envelope.request {
                Request::Rules { after, .. } => {
                    controls.rules(&config, uid, profile, after.as_ref())
                }
                Request::RuleEvents { after, .. } => {
                    controls.rule_events(&config, uid, profile, *after)
                }
                Request::RuleDecisionSupport { .. } => {
                    controls.rule_decision_support(&config, uid, profile)
                }
                _ => return Err(Error::State("rule read dispatch".into())),
            };
            result.unwrap_or_else(|error| ResponseEnvelope {
                schema_version: 1,
                journal_healthy: controls.journal_healthy(),
                response: Response::Error {
                    code: crate::model::Failure::from_error(&error),
                },
            })
        };
        let bytes = serde_json::to_vec(&response)
            .map_err(|_| Error::State("agent rule response encoding".into()))?;
        return write_frame(&mut stream, &bytes).await;
    }
    // A valid stop reaches its independent watch even if a durable transaction
    // is slow. The response still waits for persistence; it never reports release.
    if matches!(
        envelope.request,
        Request::StopJob { .. } | Request::StopSession { .. }
    ) {
        let _ = controls
            .lock()
            .map_err(|_| Error::State("agent controls lock poisoned".into()))?
            .request(&config, uid, &envelope.request);
    }
    let (reply, receive) = oneshot::channel();
    sender
        .send(Command {
            uid,
            request: envelope.request,
            reply,
        })
        .await
        .map_err(|_| Error::State("agent supervisor unavailable".into()))?;
    let response = receive
        .await
        .map_err(|_| Error::State("agent supervisor unavailable".into()))?;
    let bytes = serde_json::to_vec(&response)
        .map_err(|_| Error::State("agent response encoding".into()))?;
    write_frame(&mut stream, &bytes).await
}

async fn read_frame(stream: &mut UnixStream) -> Result<Vec<u8>> {
    let length = stream.read_u32().await? as usize;
    if length == 0 || length > MAX_FRAME {
        return Err(Error::InvalidInput("agent frame length".into()));
    }
    let mut bytes = vec![0; length];
    stream.read_exact(&mut bytes).await?;
    Ok(bytes)
}
async fn write_frame(stream: &mut UnixStream, bytes: &[u8]) -> Result<()> {
    if bytes.is_empty() || bytes.len() > MAX_FRAME {
        return Err(Error::State("agent response exceeds frame budget".into()));
    }
    stream.write_u32(bytes.len() as u32).await?;
    stream.write_all(bytes).await?;
    stream.flush().await?;
    Ok(())
}

fn control_directory(manifest: &Manifest) -> Result<File> {
    // O_PATH permits traversal by an operator with execute-only access to the
    // broker's 0711 leaf. Each component is anchored to its checked parent FD.
    let flags = OFlags::PATH | OFlags::DIRECTORY | OFlags::NOFOLLOW | OFlags::CLOEXEC;
    let mut directory =
        File::from(rustix::fs::open("/", flags, Mode::empty()).map_err(std::io::Error::from)?);
    let components: Vec<_> = manifest
        .control_directory
        .components()
        .filter(|c| !matches!(c, Component::RootDir))
        .collect();
    for (index, component) in components.iter().enumerate() {
        let metadata = directory.metadata()?;
        if metadata.uid() != 0 || metadata.mode() & 0o022 != 0 {
            return Err(Error::Permission("agent client ancestor trust".into()));
        }
        let Component::Normal(name) = component else {
            return Err(Error::InvalidInput("agent client directory".into()));
        };
        directory = File::from(
            rustix::fs::openat(&directory, *name, flags, Mode::empty())
                .map_err(std::io::Error::from)?,
        );
        if index + 1 == components.len() {
            let metadata = directory.metadata()?;
            if metadata.uid() != manifest.broker_uid || metadata.mode() & 0o7777 != 0o711 {
                return Err(Error::Permission("agent client leaf owner/mode".into()));
            }
        }
    }
    Ok(directory)
}

/// Send one typed operation to the fixed trusted endpoint and verify its OS UID.
/// This reads public manifest metadata only; it never loads a TLS private key.
pub async fn call(manifest: &Manifest, request: Request) -> Result<ResponseEnvelope> {
    manifest.validate()?;
    tokio::time::timeout(DEADLINE, async {
        let directory = control_directory(manifest)?;
        let identity = socket_identity(&directory, manifest.broker_uid)?
            .ok_or_else(|| Error::State("agent is not listening".into()))?;
        let mut stream = UnixStream::connect(manifest.socket_path()).await?;
        if stream.peer_cred()?.uid() != manifest.broker_uid
            || socket_identity(&directory, manifest.broker_uid)? != Some(identity)
        {
            return Err(Error::Permission("agent server identity changed".into()));
        }
        let current = control_directory(manifest)?;
        let before = directory.metadata()?;
        let after = current.metadata()?;
        if (before.dev(), before.ino()) != (after.dev(), after.ino()) {
            return Err(Error::Permission("agent directory identity changed".into()));
        }
        let bytes = serde_json::to_vec(&RequestEnvelope {
            schema_version: 1,
            request,
        })
        .map_err(|_| Error::InvalidInput("agent request encoding".into()))?;
        write_frame(&mut stream, &bytes).await?;
        let response: ResponseEnvelope = serde_json::from_slice(&read_frame(&mut stream).await?)
            .map_err(|_| Error::Protocol("agent response schema".into()))?;
        if response.schema_version != 1 {
            return Err(Error::Protocol("agent response version".into()));
        }
        Ok(response)
    })
    .await
    .map_err(|_| Error::Timeout("agent local request".into()))?
}

/// Load a public trusted manifest in an owned blocking task and make one call.
pub async fn call_path(path: &Path, request: Request) -> Result<ResponseEnvelope> {
    let path = path.to_owned();
    let manifest = tokio::task::spawn_blocking(move || Manifest::read(&path))
        .await
        .map_err(|_| Error::State("agent manifest task failed".into()))??;
    call(&manifest, request).await
}

#[cfg(test)]
mod tests {
    use super::*;
    #[tokio::test]
    async fn oversized_empty_and_unknown_requests_fail_without_allocating_unboundedly() -> Result<()>
    {
        for length in [0, 65537, u32::MAX] {
            let (mut left, mut right) = UnixStream::pair()?;
            left.write_u32(length).await?;
            assert!(read_frame(&mut right).await.is_err());
        }
        assert!(serde_json::from_str::<RequestEnvelope>(r#"{"schema_version":1,"request":{"op":"start","profile":"x","request_id":"00000000-0000-0000-0000-000000000001","endpoint":"attacker"}}"#).is_err());
        Ok(())
    }
    #[tokio::test]
    async fn unix_credentials_and_framing_come_from_the_actual_connection() -> Result<()> {
        let (mut left, mut right) = UnixStream::pair()?;
        assert_eq!(
            right.peer_cred()?.uid(),
            rustix::process::geteuid().as_raw()
        );
        write_frame(&mut left, b"bounded").await?;
        assert_eq!(read_frame(&mut right).await?, b"bounded");
        Ok(())
    }
}

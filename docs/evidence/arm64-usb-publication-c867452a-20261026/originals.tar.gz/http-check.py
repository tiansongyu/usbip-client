"""One actual fetch per canonical runtime/pinned documentation URL, exact source bytes."""
from pathlib import Path
import concurrent.futures,datetime,hashlib,json,subprocess,urllib.request
OUT=Path(__file__).parent;ROOT=Path('/home/ubuntu/github/usbip-client');HEAD='c867452ae63de3e0dab8de430c3b98f1436b5f80'
paths=['website/index.html','website/styles.css','website/app.js','website/assets/favicon.svg','website/assets/usbip-flow.svg','website/assets/usbip-flow-mobile.svg','website/assets/gui-qemu.png','README.md','docs/research/arm64-usb-data-validation.md','docs/research/arm64-usb-data-design.md']
(OUT/'http').mkdir(exist_ok=True)
def one(path):
 expected=subprocess.check_output(['git','show',HEAD+':'+path],cwd=ROOT)
 url=('https://tiansongyu.github.io/usbip-client/'+path.removeprefix('website/')) if path.startswith('website/') else 'https://raw.githubusercontent.com/tiansongyu/usbip-client/'+HEAD+'/'+path
 if path=='website/index.html':url='https://tiansongyu.github.io/usbip-client/'
 row={'path':path,'url':url,'head':HEAD,'expected_sha256':hashlib.sha256(expected).hexdigest()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'RustUSB-publication-verification'}),timeout=60) as response:body=response.read();row['http_status']=response.status
  destination=OUT/'http'/path;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(body)
  row.update(bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),source_equal=body==expected,passed=row['http_status']==200 and body==expected)
 except Exception as error:row.update(passed=False,error=str(error))
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(one,paths))
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':HEAD,'passed':all(r['passed'] for r in rows),'requests':rows};(OUT/'http-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(0 if result['passed'] else 1)

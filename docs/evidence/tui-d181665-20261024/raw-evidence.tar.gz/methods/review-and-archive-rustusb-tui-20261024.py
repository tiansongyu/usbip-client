import pathlib,json,hashlib,subprocess,tarfile,io,base64,re,shutil
repo=pathlib.Path('/home/ubuntu/github/usbip-client')
target=repo/'docs/evidence/tui-d181665-20261024'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def git(*a):return subprocess.check_output(['git',*a],cwd=repo)
assert not git('status','--porcelain').strip()
target.mkdir(exist_ok=False)
software=pathlib.Path('/tmp/rustusb-tui-software-ba0cedc-20261024');sw=load(software/'summary.json')
assert sw['result']=='PASS' and sw['inputs_unchanged'] and all(c['exit_code']==0 for c in sw['commands'])
for name,fact in sw['inputs_before'].items():
 data=(repo/name).read_bytes();assert sha(data)==fact['sha256'] and len(data)==fact['bytes'];assert git('show',sw['head']+':'+name)==data
qemus=[pathlib.Path('/tmp/rustusb-tui-native-'+family+'-second-20261024')for family in ['ipv4','ipv6']]
for q in qemus:
 s=load(q/'summary.json');assert s['result']=='PASS' and all(s[k]for k in ['source_guard','binary_guard','head_guard','clean_guard']);assert s['guest_exit_codes']=={'server':0,'client':0};assert s['facts']['tui']['pty_children']==10
 assert s['binary_sha256']=={name:fact['sha256']for name,fact in next(c for c in sw['commands']if c['name']=='release-all')['binaries'].items()}
 for name,fact in s['source_inputs'].items():
  data=(repo/name).read_bytes();assert sha(data)==fact['sha256'] and len(data)==fact['bytes'];assert git('show',s['head']+':'+name)==data
 shutil.copyfile(q/'summary.json',target/(q.name+'-summary.json'))
first=pathlib.Path('/tmp/rustusb-tui-native-ipv4-first-20261024');assert load(first/'summary.json')['result']=='FAIL';shutil.copyfile(first/'summary.json',target/'first-ipv4-FAIL-summary.json')
shutil.copyfile(software/'summary.json',target/'software-summary.json')
research=pathlib.Path('/tmp/rustusb-tui-terminal-research-20261024')
index=load(research/'public-files.json')
print('research_index_type',type(index).__name__,flush=True)
# Close only explicitly selected public files; never research target/ or .private.
if isinstance(index,dict):
 rows=index.get('files',index.get('entries'))
else:rows=index
entries=[];filebytes={}
def add(path,archive):
 data=path.read_bytes();assert not data.startswith(b'\x7fELF');assert not re.search(rb'-----BEGIN (?:RSA |EC |ENCRYPTED )?PRIVATE KEY-----\r?\n',data);assert '.private'not in str(path);assert 'target/'not in archive
 entries.append({'path':archive,'original':str(path),'bytes':len(data),'sha256':sha(data)});filebytes[archive]=data
roots=[software,first,*qemus,pathlib.Path('/tmp/rustusb-tui-first-capture-review-20261024'),pathlib.Path('/tmp/rustusb-tui-capture-20261024')]
for root in roots:
 for p in sorted(root.rglob('*')):
  if p.is_file():add(p,root.name+'/'+str(p.relative_to(root)))
for row in rows:
 name=row.get('path',row.get('relative_path'));p=research/name
 data=p.read_bytes();assert sha(data)==row['sha256'];add(p,research.name+'/'+name)
add(research/'public-files.json',research.name+'/public-files.json')
methods=[pathlib.Path('/tmp/run-rustusb-tui-gate-20261024.py'),pathlib.Path(__file__),pathlib.Path('/tmp/parse-rustusb-tui-captures-20261024.py'),pathlib.Path('/tmp/render-rustusb-tui-capture-20261024.py')]
methods+=sorted(pathlib.Path('/tmp').glob('rustusb-tui-development-*.log'))
methods += [pathlib.Path('/tmp/rustusb-tui-archive-first-method-20261024.py'), pathlib.Path('/tmp/rustusb-tui-archive-first-failure-20261024.log')]
methods +=[pathlib.Path('/tmp/rustusb-tui-default-cli-tree.txt'),pathlib.Path('/tmp/rustusb-tui-added-dependencies.json'),pathlib.Path('/tmp/rustusb-tui-first-readonly-recheck-20261024.json'),pathlib.Path('/tmp/rustusb-tui-first-capture-review.log'),pathlib.Path('/tmp/rustusb-tui-pyte-install.log'),pathlib.Path('/tmp/rustusb-tui-wcwidth-install.log')]
methods +=sorted(pathlib.Path('/tmp').glob('rustusb-tui-native-*-20261024-driver.log'))
for p in methods:add(p,'methods/'+p.name)
# Independently decode original guest blocks, without importing runner/verifier.
blocks=0
for root in [first,*qemus]:
 for role in ['server','client']:
  raw=(root/(role+'-evidence.log')).read_bytes()
  for m in re.finditer(rb'SECURE_ARTIFACT_BEGIN ([^\n]+) (\d+)\n(.*?)SECURE_ARTIFACT_END \1\n',raw,re.S):
   name=m[1].decode();data=base64.b64decode(m[3],validate=False);assert len(data)==int(m[2]);assert(root/(role+'-artifacts')/name).read_bytes()==data;blocks+=1
archive=target/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for name,data in sorted(filebytes.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(entries)
 for m in members:assert sha(tar.extractfile(m).read())==sha(filebytes[m.name])
for e in entries:assert sha(pathlib.Path(e['original']).read_bytes())==e['sha256']
manifest={'result':'PASS','files':entries,'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'guest_base64_blocks_redecoded':blocks,'scope':'Same-author independent raw/hash/input review; no new USB run or security audit. Original first IPv4 FAIL retained; external Python decoder not bundled.'}
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'result':'PASS','files':len(entries),'blocks':blocks,'archive_bytes':archive.stat().st_size}),flush=True)

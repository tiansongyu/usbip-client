import sys,pathlib,json,re
sys.path.insert(0,'/tmp/rustusb-tui-qa-pyte')
import pyte
out=pathlib.Path('/tmp/rustusb-tui-first-capture-review-20261024');out.mkdir(exist_ok=True)
summary=[]
for role in ['server','client']:
 raw=(pathlib.Path('/tmp/rustusb-tui-native-ipv4-first-20261024')/(role+'-artifacts')/'tui-held.raw').read_bytes()
 screen=pyte.Screen(120,30);stream=pyte.Stream(screen);frames=[];clears=0
 # Ratatui emits Hide after a rendered frame. Keep cursor controls and full diff.
 for chunk in raw.decode('utf-8').split('\x1b[?25l'):
  if '\x1b[2J' in chunk:
   clears+=chunk.count('\x1b[2J')
   if clears>=2:screen.resize(lines=18,columns=60)
  stream.feed(chunk+'\x1b[?25l')
  frames.append('\n'.join(screen.display))
 (out/(role+'-frames.txt')).write_text('\n\n--- FRAME ---\n\n'.join(frames))
 matches=[i for i,f in enumerate(frames) if 'Connected' in f]
 summary.append(dict(role=role,clears=clears,frames=len(frames),connected=matches))
 print(role,summary[-1]);print(frames[matches[0]] if matches else frames[-1])
(out/'summary.json').write_text(json.dumps(summary,indent=2))

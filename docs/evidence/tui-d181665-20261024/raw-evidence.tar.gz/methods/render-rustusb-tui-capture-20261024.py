from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import hashlib,json
root=Path('/tmp/rustusb-tui-native-ipv4-second-20261024');out=Path('/tmp/rustusb-tui-capture-20261024');out.mkdir(exist_ok=True)
s=(root/'tui-server-held-frames.txt').read_text().split('\n\n--- FRAME ---\n\n')
index=next(i for i,f in enumerate(s)if 'Incoming Connected native:' in f and 'Current page (up to 16)'in f)
frame=s[index];lines=frame.splitlines();assert len(lines)==18 and all(len(line)==60 for line in lines)
fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
font=ImageFont.truetype(fontpath,16);small=ImageFont.truetype(fontpath,12)
cell=10;row=23;pad=24;top=64;w=60*cell+pad*2;h=18*row+top+pad
image=Image.new('RGB',(w,h),'#0f172a');draw=ImageDraw.Draw(image)
draw.text((pad,16),'RustUSB terminal preview',font=font,fill='#f8fafc')
draw.text((pad,39),'Recorded QEMU output reconstruction | UID 1000 | 60x18',font=small,fill='#94a3b8')
for y,line in enumerate(lines):
 color='#67e8f9'if y in [0,17]or line.startswith('│>')else'#f8fafc'
 for x,char in enumerate(line):draw.text((pad+x*cell,top+y*row),char,font=font,fill=color)
image.save(out/'tui-qemu.png')
(out/'frame.txt').write_text(frame+'\n')
(out/'provenance.json').write_text(json.dumps({'source':str(root/'server-artifacts/tui-held.raw'),'raw_sha256':hashlib.sha256((root/'server-artifacts/tui-held.raw').read_bytes()).hexdigest(),'frames_file':str(root/'tui-server-held-frames.txt'),'frames_sha256':hashlib.sha256((root/'tui-server-held-frames.txt').read_bytes()).hexdigest(),'frame_index':index,'head':json.loads((root/'summary.json').read_text())['head'],'actual_overall_result':json.loads((root/'summary.json').read_text())['result'],'meaning':'Output reconstructed from actual product PTY, same characters/positions; explicit monospace font and presentation colors, not native terminal pixels. Original real USB I/O/cleanup evidence is separate.','font':fontpath,'font_sha256':hashlib.sha256(Path(fontpath).read_bytes()).hexdigest(),'image_sha256':hashlib.sha256((out/'tui-qemu.png').read_bytes()).hexdigest()},indent=2)+'\n')
print(out/'tui-qemu.png')

import hashlib,importlib.util,json,re,subprocess
from pathlib import Path
from urllib.parse import urlsplit,unquote
ROOT=Path('/home/ubuntu/github/usbip-client');OUT=Path('/tmp/rustusb-storage-arrival-docs-20261026');OUT.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('sitecheck',ROOT/'scripts/check-site.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
names=subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines()+['docs/research/storage-arrival-quarantine-validation.md','docs/evidence/storage-arrival-20261026/README.md']
checks=0
for name in names:
 p=ROOT/name
 if p.suffix!='.md':continue
 for target in re.findall(r'\]\(([^)\s]+)\)',p.read_text()):
  u=urlsplit(unquote(target))
  if u.scheme or u.netloc:continue
  dest=(p.parent/u.path).resolve() if u.path else p
  assert dest.is_relative_to(ROOT) and dest.exists(),(name,target)
  if u.fragment and dest.suffix=='.md':assert u.fragment in mod.markdown_ids(dest),(name,target)
  checks+=1
expected={'SKILL.md':'83514d886ff1f1ff17585805a89508f35f60bb326a3dd9592f42fa52198a26f3','agents/openai.yaml':'61c795ad1d34ded25f1e2b8a799c45fea9b66abd32717c505ffe5b474c35e5cb','references/readme.md':'995cb45f62c0ae8bcec45092267f67eec73633474bf59d0a8047c8a48b4b713b','references/site.md':'82624a1db23c94ed3767ea47996311cd065f8510d6649eec20a11875cca1a24b'}
for n,h in expected.items():assert hashlib.sha256((Path('/home/ubuntu/.agents/skills/readme-site')/n).read_bytes()).hexdigest()==h
assert Path('/home/ubuntu/.codex/skills/readme-site').resolve()==Path('/home/ubuntu/.agents/skills/readme-site')
software=json.loads(Path('/tmp/rustusb-storage-arrival-software-20261026/summary.json').read_text())
for n,v in software['binaries'].items():
 p=Path(n);p=p if p.is_absolute() else ROOT/p
 assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256']
changed=subprocess.check_output(['git','diff','--name-only','c55a6c57','--','crates','apps','Cargo.toml','Cargo.lock','rust-toolchain.toml','packaging'],cwd=ROOT,text=True);assert not changed,changed
commands={}
for name,args in [('site',['python3','scripts/check-site.py']),('javascript',['node','--check','website/app.js']),('diff',['git','diff','--check'])]:
 r=subprocess.run(args,cwd=ROOT,capture_output=True,text=True);commands[name]={'argv':args,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr};assert r.returncode==0
receipt={'passed':True,'markdown_files':sum((ROOT/n).suffix=='.md' for n in names),'local_links_and_anchors':checks,'commands':commands,'global_readme_skill_unchanged':expected,'product_paths_unchanged_since':'c55a6c57','release_hashes_unchanged':software['binaries'],'browser':{'scope':'actual CUA DOM observations on local project-subpath preview; screenshot unavailable previously, no new pixel claim','desktop':{'viewport':1280,'document':1265,'new_link_keyboard_focus':True,'outline':'2px','loaded_images':3},'mobile':{'viewport':390,'document':375,'new_link_and_boundary_visible':True},'warn_error_sample':[],'viewport_reset_requested':True,'temporary_tab_63_closed':True,'not_retested':['clipboard','reduced-motion','JavaScript-disabled']} }
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
for name in names:
 p=ROOT/name
 if p.is_file():dest=OUT/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
print(json.dumps({'passed':True,'markdown_files':receipt['markdown_files'],'links':checks,'product_unchanged':True,'global_skill_unchanged':True}))

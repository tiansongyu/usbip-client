"""Read-only fixed upstream source research; no host USB or product code."""
from pathlib import Path
import concurrent.futures,datetime,hashlib,json,urllib.request
ROOT=Path(__file__).parent
FILES=['Documentation/driver-api/usb/power-management.rst','Documentation/usb/usbip_protocol.rst','drivers/base/power/sysfs.c','drivers/base/power/runtime.c','drivers/usb/core/sysfs.c','drivers/usb/core/driver.c','drivers/usb/core/devio.c','drivers/hid/usbhid/hid-core.c','drivers/usb/usbip/vhci_hcd.c','drivers/usb/usbip/vhci_rx.c','drivers/usb/usbip/vhci_tx.c','drivers/usb/usbip/usbip_common.h','drivers/usb/usbip/stub_dev.c','COPYING','LICENSES/preferred/GPL-2.0']
def one(pair):
 version,name=pair;url='https://raw.githubusercontent.com/torvalds/linux/'+version+'/'+name;p=ROOT/version/name;p.parent.mkdir(parents=True,exist_ok=True)
 row={'version':version,'path':name,'url':url,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(url,timeout=45) as response:body=response.read();row['http_status']=response.status
  p.write_bytes(body);row.update(bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),fetched=True)
 except Exception as error:row.update(fetched=False,error=type(error).__name__+': '+str(error))
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(one,[(v,n) for v in ['v5.15','v6.8'] for n in FILES]))
(ROOT/'download-receipts.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'files':len(rows),'fetched':sum(r['fetched'] for r in rows),'failures':[r for r in rows if not r['fetched']]}))

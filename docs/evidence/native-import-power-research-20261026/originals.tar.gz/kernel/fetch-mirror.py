"""Fixed-tag primary Linux mirror, only missing load-bearing PM/USBIP files."""
from pathlib import Path
import concurrent.futures,datetime,hashlib,json,urllib.request,base64
ROOT=Path(__file__).parent
files=[('v5.15',n) for n in ['drivers/base/power/sysfs.c','drivers/usb/core/devio.c','drivers/usb/usbip/vhci_hcd.c','drivers/usb/usbip/vhci_rx.c']]+[('v6.8',n) for n in ['drivers/base/power/sysfs.c','drivers/hid/usbhid/hid-core.c','drivers/usb/core/driver.c','drivers/usb/core/devio.c','drivers/usb/usbip/vhci_hcd.c','drivers/usb/usbip/vhci_rx.c']]
def one(pair):
 version,name=pair;url='https://kernel.googlesource.com/pub/scm/linux/kernel/git/torvalds/linux/+/refs/tags/'+version+'/'+name+'?format=TEXT';p=ROOT/'mirror'/version/name;p.parent.mkdir(parents=True,exist_ok=True)
 row={'version':version,'path':name,'url':url,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(url,timeout=40) as response:body=base64.b64decode(response.read(),validate=True);row['http_status']=response.status
  assert b'SPDX-License-Identifier' in body[:2000] or b'Copyright' in body[:2000]
  p.write_bytes(body);row.update(bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),fetched=True)
 except Exception as error:row.update(fetched=False,error=type(error).__name__+': '+str(error))
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(one,files))
(ROOT/'mirror-receipts.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'files':len(rows),'fetched':sum(r['fetched'] for r in rows),'failures':[r for r in rows if not r['fetched']]}))

# Imported USB runtime PM — fixed Linux source audit

2026-10-26, read-only component research for E63. No repository/product edit,
commit, build, QEMU or host USB/service mutation. This does not reclassify any
E62 failure, prove every failed matrix client's PM state, or accept a product fix.
Fixed upstream v5.15/v6.8 contracts are not exact Ubuntu5.15.0-198/6.8.0-147
vendor source snapshots; the parent's actual target-kernel controls remain needed.

## Recommendation and alternative boundary

For the already authorized, pinned imported VHCI USB generation, a single
`power/autosuspend_delay_ms=-1` write is a source-supported choice if the normal
USB PM attribute is available and actual readback plus `runtime_status=active`
succeed. It establishes an independent PM usage-count hold and survives a later
`power/control=auto`/`pm_runtime_allow()`; the root's new actual control is testing
that claim. Opening and writing must stay anchored to the same generation, and
partial effects remain owned through original cleanup. Missing attributes, EIO,
`error` or `unsupported` are not successful active-state evidence. This research
does not authorize a silent missing-file fallback or global PM configuration.

`power/control=on` is already supported by the E62 diagnostic and is narrower in
attributes, but sets the mutable `runtime_auto` policy flag: a later allow/auto
can undo that hold. The audited usbhid source does not itself call
usb_enable_autosuspend/pm_runtime_allow; this is not a guarantee about other
class drivers or administrator/udev policy. A negative-delay hold is preferable
when Ready can precede later driver/policy activity that merely enables auto.
Neither setting is immutable against a later privileged writer changing that
same setting. No arbitrary administrator override resistance is claimed.

A retained USBFS file is a real PM hold with an open-time resume result, but it
adds an opened device capability, ownership/lifetime and cleanup accounting.
Legacy one-shot attach has no existing persistent session FD owner. Duplicating
an existing USBFS OFD does not create an independent fresh PM usage reference.
It should not be substituted casually for the existing Native receipt model.

## Versioned findings

The two official [v5.15](https://www.kernel.org/doc/html/v5.15/driver-api/usb/power-management.html)
and [v6.8](https://www.kernel.org/doc/html/v6.8/driver-api/usb/power-management.html)
USB PM references distinguish runtime suspend from whole-system sleep. They
present per-device control on and negative autosuspend delay as runtime-suspend
prevention. The documented usual delay is2000ms; actual initialization derives
from CONFIG_USB_AUTOSUSPEND_DELAY/module parameter, so an observed device's
value, rather than documentation alone, determines its delay. E62 observed2000ms.

The following functions/semantics were read in both fixed tags:

| Source | Load-bearing fact |
| --- | --- |
| `drivers/usb/core/hub.c`, usb_new_device | Sets active, increments initialization usage, calls pm_runtime_use_autosuspend and pm_runtime_enable, then forbids autosuspend before device_add. Normal CONFIG_PM USB enumeration therefore establishes use_autosuspend before sysfs publication |
| `drivers/usb/core/usb.c`, usb_alloc_dev | Initial autosuspend delay comes from the USB module parameter/configured default |
| `drivers/base/power/runtime.c`, pm_runtime_forbid | Idempotently clears runtime_auto, adds its own usage reference and calls rpm_resume. Returns void and discards resume result |
| same, pm_runtime_allow | Sets runtime_auto and releases only the reference associated with that policy transition |
| same, update_autosuspend / pm_runtime_set_autosuspend_delay | With use_autosuspend enabled, transition to negative delay adds another usage reference and resumes; keeping delay negative does not add repeated refs. Nonnegative transition removes it. Resume result is again not returned to userspace |
| `drivers/base/power/sysfs.c`, control_store | Valid on/auto calls void PM core API under device lock and reports the supplied count. Successful write/on readback alone does not establish a successful resume |
| same, autosuspend_delay_ms_store | Returns EIO if use_autosuspend is false, validates representable int, updates under device lock, reports count. Successful -1 write/readback still does not prove active state |
| same, runtime_status_show | May report active, suspended, suspending, resuming, error (runtime_error set), or unsupported (disable_depth nonzero). Unsupported does not imply active: disabling runtime PM may leave a device active or suspended |
| same, dpm_sysfs_add | May omit PM attributes when device_pm_not_required; runtime group is omitted for no_callbacks. Thus even CONFIG_PM=y does not make missing power/control a reliable PM-disabled signal |
| `drivers/base/power/Makefile` | sysfs.o and runtime.o compile under CONFIG_PM. Missing files can also mean teardown, mount/access or observation error; do not infer safe operation from ENOENT |
| `drivers/hid/usbhid/hid-core.c`, usbhid_open | Sets HID_OPENED, temporarily gets interface PM, asks for remote wakeup and starts IN polling, then puts PM immediately. Evdev open is not a lifetime hold. supports_autosuspend is set |
| `drivers/usb/core/devio.c`, usbdev_open/release | Fresh USBFS open calls usb_autoresume_device and fails on its returned error; successful open retains the PM reference until release unless USBDEVFS_ALLOW_SUSPEND explicitly releases it. FORBID_SUSPEND reacquires it |

The PM setters invoke a synchronous runtime resume path under device serialization.
A driver/kernel wait can block the actual syscall. A timeout or dropped Rust
future does not cancel that actual write/resume; existing blocking-worker and
cleanup joins must remain real.

## USB/IP/VHCI wakeup limit

In both fixed `drivers/usb/usbip/vhci_hcd.c`, SetPortFeature SUSPEND changes local
virtual port state; ClearPortFeature SUSPEND schedules local resume signaling.
These root-hub operations do not send a dedicated server PM request. The fixed
`vhci_rx.c` dispatch handles only RET_SUBMIT/RET_UNLINK and rejects unknown PDUs.
No separate remote-wakeup notification exists in that audited receive path.
Therefore supporting a local suspended keyboard's physical wakeup does not prove
an imported keyboard can wake its client through USB/IP after all IN URBs are
cancelled. This source reading is consistent with the E62 original-Linux
reproduction; it is not an additional execution or a universal wakeup proof.

VHCI also has platform suspend logic that refuses active connections in these
tags. That is separate from the imported child runtime-PM issue. Neither the
per-device control nor this source audit establishes safe system suspend,
hibernation, power loss or physical device PM for the product.

## Primary source links and local custody

Function-level files are fixed under:

- [Linux v5.15 source tree](https://github.com/torvalds/linux/tree/v5.15)
- [Linux v6.8 source tree](https://github.com/torvalds/linux/tree/v6.8)
- [v5.15 PM core](https://github.com/torvalds/linux/blob/v5.15/drivers/base/power/runtime.c)
- [v6.8 PM core](https://github.com/torvalds/linux/blob/v6.8/drivers/base/power/runtime.c)
- [v5.15 runtime sysfs](https://github.com/torvalds/linux/blob/v5.15/drivers/base/power/sysfs.c)
- [v6.8 runtime sysfs](https://github.com/torvalds/linux/blob/v6.8/drivers/base/power/sysfs.c)
- [v5.15 USB enumeration](https://github.com/torvalds/linux/blob/v5.15/drivers/usb/core/hub.c)
- [v6.8 USB enumeration](https://github.com/torvalds/linux/blob/v6.8/drivers/usb/core/hub.c)
- [v5.15 USBFS ownership](https://github.com/torvalds/linux/blob/v5.15/drivers/usb/core/devio.c)
- [v6.8 USBFS ownership](https://github.com/torvalds/linux/blob/v6.8/drivers/usb/core/devio.c)
- [v5.15 VHCI](https://github.com/torvalds/linux/blob/v5.15/drivers/usb/usbip/vhci_hcd.c)
- [v6.8 VHCI](https://github.com/torvalds/linux/blob/v6.8/drivers/usb/usbip/vhci_hcd.c)

Initial GitHub raw download attempted30 files; six succeeded and24 HTTP429
failures remain in the original receipt/log. After that failure, only missing
load-bearing files were requested from the fixed-tag kernel.googlesource primary
mirror, with no repeated raw retries. Exact source bytes/SHA and URLs are in
manifest/download receipts. Sources retain SPDX/license headers; they are
research originals, not copied implementation for the MIT project. The initial
single mirror runtime.c fetch is separately transcribed; no HTTP status was saved
for that one call, so none is invented. This directory contains no private USB,
credential, disk or product payload.

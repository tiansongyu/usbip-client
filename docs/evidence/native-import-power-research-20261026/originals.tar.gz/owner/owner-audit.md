# E63 Native imported-device PM ownership audit

Status: read-only recommendation, not implementation or accepted architecture. Source observed at clean `84045dfb1a3997f7c6dcb7ca8630a01ed4431363`. Exact input hashes are in `inputs.json`. No repo modification, cargo, QEMU, host USB/sysfs change or agent delegation was performed by this audit. The E62 eight failed acceptance pairs, one traced failure and partial/local diagnostic verdicts remain unchanged.

## Existing authorization and ownership

- `crates/rustusb-native/src/lib.rs:1-6`: low-level adapter does not authorize; caller must authorize mutations. Dropping an operation cannot undo kernel writes and requires reconciliation. Do not silently strengthen that public cancellation promise without owning the full transaction.
- `crates/rustusb-daemon/src/linux.rs:301-306,338-342,445-470`: Legacy helper checks caller UID, takes helper state mutex, checks approved/trusted peer, reconciles old managed ports before `NativeBackend::attach_session`. Only a successful returned receipt is inserted into `state.ports` at469.
- `crates/rustusb-daemon/src/lib.rs:597-619,656-663,695-703`: secure import requires exact nonzero broker UID plus logical server/device-key policy; legacy requires allowed UID plus trusted-network/approved peer. PM is a derived consequence of the existing authorized new import; no new RPC accepting a sysfs path or arbitrary value is justified.
- `crates/rustusb-native/src/lib.rs:239-312`: Legacy holds `self.mutation` from before DEVLIST through native tool execution, before/after port matching, local generation observation, endpoint-record check and return. `matched_new_sessions` only claims an initially free matching session. A new PM stage belongs after exact record match298, before successful return304.
- `lib.rs:342-429`: `detach_checked` reacquires the same backend mutex, checks complete generation and exact session identity, performs one detach, then requires NULL and old generation disappearance. Calling it while attach retains that mutex deadlocks. If compensation is integrated, split an internal locked body from its locking public wrapper, retaining existing destructive-operation checks.
- `lib.rs:1089-1100`: identity includes port/local bus, remote devid, VID/PID, local address and filesystem-device/inode receipt; bus ID alone is insufficient.

## Secure anonymous Import

- `channel.rs:675-751`: one retained K endpoint; durable Intent precedes actual attach write, and `write_started` precedes even a possible short write.
- `channel.rs:231-394`: `InitialObserver` pins the first USED row and first local directory generation; never-seen missing initialization nodes may be pending, but observed identity is never reset. Directory is a root-owned descendant of the selected VHCI controller.
- `channel.rs:764-811`: exact local VID/PID, first local receipt779, full profile, matching row/local generation and controller are checked before return. PM can be applied after `self.local` is set and profile completes, and before final successful receipt, followed by another same-row/local verification. A PM error then still has `observed_receipt` metadata for cleanup.
- Important boundary: `InitialObserver::profile_inner` (`channel.rs:420-514`) checks configuration and interface number/alt/class/subclass/protocol, never a `driver` link or driver-probe completion. Do not claim this hook necessarily follows usbhid probe. The kernel audit/actual delayed-policy diagnostic must determine whether later driver or udev policy can override control=on; that is not proved by this owner audit.
- `native_channel.rs:369-399`: authorization precedes reserving Prepared state/creating channel. No new PM work before that authorization or kernel adoption.
- `native_channel.rs:439-458`: owned `spawn_blocking` captures helper mutation guard and channel; stop/EOF sets cancel and still awaits the same actual worker. `observed_receipt` is persisted even after an unsuccessful commit (when available).
- `native_channel.rs:465-488`, `channel.rs:835-884`: every operation outcome goes through actual K shutdown and independent cleanup; PM error cannot bypass this. NativeImportReleased remains NULL plus disappearance of the old pinned generation, not power state. Unknown/failed observations remain unresolved.
- `native_channel.rs:232-290`: client actor owns full commit exchange even if caller abandons its oneshot, then closes UDS on failure so helper supervisor runs. `jobs/client.rs:188-214,242-267` retains accepted prepare/commit, joins network owners and awaits actual handle close. No PM work should move into a metadata, monitoring or application-state actor.

## Legacy partial-error and cancellation trap

A bare `ensure_pm(...)?` before attach returns would create a NEW common failure after a known valid kernel session exists, but the daemon's `?` at linux.rs455 prevents registration. Do not introduce that without explicit compensation.

Recommended small pattern, retaining existing generic cancellation contract:

1. Acquire the backend mutex using `self.mutation.clone().lock_owned().await`.
2. Once native attach is fully identified, move that owned guard and immutable pinned session/roots into one actual PM blocking worker; return `(guard, pm_result)` from it. Do not put an unowned synchronous sysfs write on a Tokio worker and do not release the mutex when an async waiter is dropped while the blocking operation remains live.
3. On normal PM failure, keep the returned same guard, invoke the internal locked detach body against only the exact freshly verified receipt, and return an operation error whether cleanup succeeds or fails. Keep PM and cleanup error contexts distinct; cleanup failure must explicitly remain uncertain/reconciliation-required. Never compensate an ambiguous pre-receipt native-tool failure.
4. The existing public async attach can still be dropped at OTHER await boundaries after a kernel side effect; this approach does not invent whole-operation cancellation rollback. Retain the documented caller-reconciliation limitation. If its waiter is dropped DURING the new PM worker, that worker still owns its mutex until true completion; its result/guard are dropped only then. No successful cleanup is inferred.

Normal product helper is stronger than a freely cancellable public-library waiter: `linux.rs:1387-1392` JoinSet owns each `serve_connection`; App::handle at1122/1130 is directly awaited, without an EOF-select/request-wide timeout. Shutdown at1416-1425 stops acceptance, sends native_stop and joins all request jobs; it does not abort legacy mutation. Thus new PM+compensation can be directly awaited in the production helper while preserving public API limitations. It is unnecessary to introduce a large new actor for this change.

Daemon-only PM after `state.ports` insertion can preserve legacy ownership on PM failure, but misses direct public `NativeBackend::attach_session` callers. A common backend hook plus narrow same-lock compensation is preferable if the requested policy covers all import entry points.

## Directory-FD anchored PM operation

Use a private Linux-only common helper, accepting trusted roots/controller and a complete pinned NativeSession (no new externally supplied paths). Production expected UID is root; a UID parameter, if useful for unprivileged fixtures, must remain private/test-only. Candidate interface shape:

`pub(crate) fn ensure_import_active(devices: &Path, controller: &Path, session: &NativeSession, expected_uid: u32) -> Result<()>`

Required properties:

1. Require USED, present local bus/address/devid/VID/PID and LocalDeviceGeneration. Resolve the fixed sysfs alias, require it belongs below the selected trusted VHCI controller, open the final directory and check fstat device/inode equals the receipt, root-owned directory and no group/other write. Validate local address and VID/PID through that same opened directory (or existing immediately rechecked pinned observation).
2. Open `power` as exactly one relative component with `openat(dirfd, "power", RDONLY|DIRECTORY|NOFOLLOW|CLOEXEC, Mode::empty())`. Validate its directory metadata before opening the attribute.
3. Open only fixed `control` (or the specific kernel-audited chosen attribute) with `openat(powerfd, "control", RDWR|NOFOLLOW|CLOEXEC|NONBLOCK, Mode::empty())`. No CREAT, TRUNC, APPEND, following symlink or fallback path write. Validate regular file/root ownership/no group-other write; fstat filesystem device should match the pinned sysfs filesystem. NONBLOCK helps reject special nodes but does not make a sysfs driver callback bounded/cancellable.
4. Read a tiny bounded value with a closed enum; reject empty/oversized/unknown/invalid encoding. If already desired, avoid unnecessary writes while still validating identity. Recheck current alias/row identity immediately before mutation.
5. Seek the opened attribute to offset0; issue ONE `write` of the fixed value/newline and require the exact length. Do not use retrying `write_all` for a sysfs side effect when a short write may already have changed state. EINTR/short/error remains an operation failure with potential effect and actual cleanup. No fsync promise on kernfs.
6. Read back via the same opened attribute, and re-observe same current alias/controller/row/local generation before claiming successful import. Do not adopt a replacement.

Opening the attribute under pinned directory FDs guarantees a last-moment alias swap cannot redirect the write into a replacement node. It does not provide a globally atomic row+directory+attribute transaction against an external privileged actor. If a disappearance/replacement is seen, fail; retain the exact original ownership and cleanup rules. No destructive action against a replacement is authorized.

No PM baseline/storage/schema/FD capability addition is necessary for a fixed per-device policy on a newly imported ephemeral VHCI node: successful existing detach removes it. Do not restore `auto` by reopening its old pathname after detach (that can hit replacement), change physical source power policy, or apply writes from restart/read-only reconciliation. Inherited journal observations do not authorize powering/resuming unknown surviving devices.

## Pinned safe APIs

Workspace already depends on rustix fs; Cargo.lock rustix1.1.5 checksum `891efababe418670775f199f0d233d84843c227a0949a883ce15b37c78d6629d`. Public safe `rustix::fs::openat<P: path::Arg,Fd: AsFd>(dirfd,path,OFlags,Mode) -> io::Result<OwnedFd>` is implemented in local src/fs/at.rs84. `fstat` is src/fs/fd.rs156. Its fd types re-export std::os::fd (src/lib.rs198-212). Existing daemon linux.rs842-851 demonstrates safe `rustix::fs::open` -> `File::from(OwnedFd)`; no unsafe raw-fd conversion or new dependency is needed. Docs checked:

- https://docs.rs/rustix/1.1.5/rustix/fs/fn.openat.html
- https://docs.rs/rustix/1.1.5/rustix/fs/fn.openat2.html

`openat2` is available but unnecessary for a small sequence of fixed single-component children from already pinned descriptors; ordinary `NOFOLLOW` must not be misrepresented as protecting arbitrary multi-component ancestry. No silent weaker openat2 fallback is justified.

## Meaningful verification recommendations (not executed)

- No PM mutation from read-only `sessions`/`port_states`/doctor/old journal coordination; approved new import only. Unauthorized helper request must not reach the PM stage.
- Exact receipt works on only its imported node; same bus/address/VIDPID but replaced inode fails before write, and another node's sentinel stays unchanged.
- Gated alias replacement after directory open: opened FD never redirects to replacement; before-write observed replacement rejects, post-write replacement prevents success; original owner/cleanup identity retained.
- Symlink `power` or attribute, FIFO, directory attribute, wrong owner, writable group/other, missing attribute, oversized/unknown contents all reject without creating/truncating another file.
- Verify one-operation short-write/error semantics through a narrow injectable writer test; no retry/false success. Keep this internal rather than building a generic I/O framework.
- Real blocking gate after PM worker starts: drop/cancel async waiter and prove next backend mutation still cannot acquire until actual worker exits. This is an ownership test, not an arbitrary permanent-kernel-block cancellation claim.
- Legacy PM failure after valid attachment: exact-session compensation succeeds only with original NULL+gone proof; compensation failure preserves original PM error plus cleanup uncertainty; replacement is not detached. Original ambiguous attach/tool-failure tests keep their outcomes.
- Secure PM failure after self.local pin persists Observed and uses the actual existing K shutdown cleanup path; no successful Connected/receipt or terminal proof solely from PM state.
- Original full software gates, exact new native ARM package receipts/ELFs, all four original installed ARM data cases without weakened I/O/Root/driver/PCAP/upgrade predicates. Preserve E62 failures; no hardware support or all-architecture guarantee from one fixture.

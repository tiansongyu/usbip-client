import hashlib, io, json, pathlib, subprocess, tarfile
ROOT=pathlib.Path('/home/ubuntu/github/usbip-client')
OUT=pathlib.Path('/tmp/rustusb-debian-package-audit-20261025');OUT.mkdir(exist_ok=False)
results=[]
for group in ['v1','v2']:
 folder=pathlib.Path('/tmp/rustusb-debs-'+group+'-20261025')
 for deb in sorted(folder.glob('*.deb')):
  name=subprocess.check_output(['dpkg-deb','-f',str(deb),'Package'],text=True).strip()
  control=subprocess.check_output(['dpkg-deb','-I',str(deb)])
  (OUT/(deb.name+'.control.txt')).write_bytes(control)
  raw=subprocess.check_output(['dpkg-deb','--fsys-tarfile',str(deb)])
  with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
   files={m.name.removeprefix('./'):tar.extractfile(m).read() for m in tar if m.isfile()}
   members=tar.getmembers()
  assert all(m.uid==0 and m.gid==0 and not m.mode&0o7000 for m in members)
  assert not any(n.startswith(('etc/','var/','home/','usr/local/')) for n in files)
  expected={'usr/bin/rustusb-gui':'apps/rustusb-gui/target/release/rustusb-gui'} if name=='rustusb-gui' else {'usr/bin/rustusb':'target/release/rustusb','usr/libexec/rustusb/rustusb-helper':'target/release/rustusb-helper'}
  for dest,source in expected.items():assert files[dest]==(ROOT/source).read_bytes()
  prefix='usr/share/doc/'+name+'/third-party/'
  inventory=json.loads(files[prefix+'inventory.json'])
  for p in inventory['packages']:
   for item in p['files']:
    key=prefix+p['name']+'-'+p['version']+'/'+item['file'];assert hashlib.sha256(files[key]).hexdigest()==item['sha256']
  if name=='rustusb-gui':
   assert b'--manifest /etc/rustusb/agent.json' in files['usr/share/applications/rustusb-gui.desktop']
   assert files['usr/share/icons/hicolor/64x64/apps/rustusb.png']==(ROOT/'apps/rustusb-gui/icons/icon.png').read_bytes()
   selector=next(p for p in inventory['packages'] if p['name']=='selectors')
   assert hashlib.sha256(files[prefix+'selectors-0.38.0/source.tar.gz']).hexdigest()==selector['source_archive_sha256']
  result=dict(file=deb.name,package_sha256=hashlib.sha256(deb.read_bytes()).hexdigest(),members=len(members),license_nodes=len(inventory['packages']),target=inventory['target'],source_head=inventory['source_head'],passed=True)
  results.append(result)
(OUT/'summary.json').write_text(json.dumps(dict(passed=True,packages=results),indent=2)+'\n')
print(json.dumps(dict(passed=True,packages=results)))

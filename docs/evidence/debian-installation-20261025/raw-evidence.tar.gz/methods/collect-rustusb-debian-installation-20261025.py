import datetime, gzip, hashlib, io, json, pathlib, subprocess, tarfile
ROOT=pathlib.Path('/home/ubuntu/github/usbip-client')
DEST=ROOT/'docs/evidence/debian-installation-20261025'
CASES=['jammy-dev01','jammy-dev02','noble-dev01','jammy-resume-dev01','noble-resume-dev01','jammy-resume-dev02','noble-resume-dev02','jammy-fresh','noble-fresh']
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
software=pathlib.Path('/tmp/rustusb-debian-software-final-20261025')
soft=json.loads((software/'summary.json').read_text())
assert soft['result']=='PASS' and all(soft['guards'].values())
records=[];files={}
def add(name,data):
 assert name not in files,name
 assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
 files[name]=data
for label in CASES:
 folder=pathlib.Path('/tmp/rustusb-package-'+label+'-20261025')
 summary=json.loads((folder/'summary.json').read_text())
 assert not summary['forced'] and summary['qemu_exit']==0 and summary['collect_exit']==0
 assert all(summary[k] for k in ['source_guard','binary_guard','head_guard'])
 if label.endswith('-fresh'):assert summary['passed'] and summary['first_qemu_exit']==0
 elif 'resume-dev02' in label:assert summary['passed'] and not summary['fresh_install_acceptance']
 else:assert not summary['passed']
 record={'case':label,**summary}
 for path in sorted(folder.iterdir()):
  if path.is_file():
   data=path.read_bytes()
   assert b'-----BEGIN PRIVATE KEY-----' not in data and b'-----BEGIN OPENSSH PRIVATE KEY-----' not in data,path
   if path.name=='guest-evidence.tar':
    with tarfile.open(fileobj=io.BytesIO(data)) as tar:
     for member in tar:
      assert not member.name.startswith('/') and '..' not in pathlib.PurePosixPath(member.name).parts
      assert not member.issym() and not member.islnk()
      if member.isfile():
       body=tar.extractfile(member).read()
       assert b'-----BEGIN PRIVATE KEY-----' not in body and b'-----BEGIN OPENSSH PRIVATE KEY-----' not in body,member.name
   add('cases/'+label+'/'+path.name,data)
 driver=pathlib.Path('/tmp/rustusb-package-'+label+'-driver-20261025.log')
 if driver.exists():add('cases/'+label+'/driver.log',driver.read_bytes())
 records.append(record)
for label,folder in [('software-final',software),('software-initial',pathlib.Path('/tmp/rustusb-debian-software-20261025'))]:
 for path in sorted(folder.iterdir()):
  if path.is_file() and path.suffix in ['.json','.log','.sh','.txt']:add(label+'/'+path.name,path.read_bytes())
for name,info in soft['inputs'].items():
 data=git('show',soft['head']+':'+name)
 assert sha(data)==info['sha256'] and len(data)==info['bytes'],name
 add('source/'+name,data)
methods=['download-rustusb-package-images-20261025.py','run-rustusb-debian-gates-20261025.py','run-rustusb-debian-gates-final-20261025.py','audit-rustusb-debs-20261025.py','audit-rustusb-debs-final-20261025.py','map-rustusb-debian-original-source-20261025.py','make-rustusb-package-resume-20261025.py','run-rustusb-package-development-resume-20261025.py','rustusb-package-development-resume-guest-20261025.py','observe-rustusb-package-vms-20261025.py','observe-rustusb-package-vms-dev02-20261025.py','collect-rustusb-debian-installation-20261025.py']
for name in methods:add('methods/'+name,(pathlib.Path('/tmp')/name).read_bytes())
for path in sorted(pathlib.Path('/tmp/rustusb-package-resume-methods-dev01-20261025').iterdir()):
 if path.is_file():add('methods/resume-dev01/'+path.name,path.read_bytes())
for group in ['v1','v2','v3','v4']:
 for path in sorted(pathlib.Path('/tmp/rustusb-debs-'+group+'-20261025').glob('build-*.json')):add('builds/'+group+'/'+path.name,path.read_bytes())
for path in sorted(pathlib.Path('/tmp').glob('rustusb-debs-build-*-20261025.log')):add('builds/logs/'+path.name,path.read_bytes())
for label in ['jammy','noble']:
 folder=pathlib.Path('/tmp/rustusb-package-images-20261025')/label
 for name in ['SHA256SUMS','SHA256SUMS.gpg','gpgv.log','receipt.json']:add('images/'+label+'/'+name,(folder/name).read_bytes())
for label in ['rustusb-debian-package-audit-20261025','rustusb-debian-package-audit-final-20261025']:
 for path in sorted((pathlib.Path('/tmp')/label).iterdir()):
  if path.is_file():add('package-audits/'+label+'/'+path.name,path.read_bytes())
add('source-mapping/original.json',pathlib.Path('/tmp/rustusb-debian-original-source-map-20261025.json').read_bytes())
for label,folder in [('debian',pathlib.Path('/tmp/rustusb-debian-research-20261025/selected-public')),('systemd',pathlib.Path('/tmp/rustusb-systemd-research-20261025'))]:
 for path in sorted(folder.rglob('*')):
  if path.is_file() and not path.is_symlink():add('primary-research/'+label+'/'+str(path.relative_to(folder)),path.read_bytes())
add('primary-research/NOTICE.txt',b'Primary reference captures retain their original upstream licensing and attribution. They are research evidence, not RustUSB product code relicensed under MIT. The repository research digests identify original providers and fixed source revisions. Debian/systemd source is not copied into the RustUSB product package.\n')
index={n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())}
DEST.mkdir(parents=True,exist_ok=False)
archive=DEST/'raw-evidence.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(files.items()):
    member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0
    tar.addfile(member,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 actual={m.name:{'bytes':m.size,'sha256':sha(tar.extractfile(m).read())} for m in tar if m.isfile()}
assert actual==index
(DEST/'members.json').write_text(json.dumps(index,indent=2)+'\n')
summary={'schema_version':1,'collected_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'software_head':soft['head'],'software_commands':soft['commands'],'source_count':len(soft['inputs']),'cases':records,'scope':'two final fresh Ubuntu amd64 package lifecycles; earlier failures and explicitly scoped development continuations retained','rust_core_gui_unchanged_from':'f174f434f7e86659692226fcd9b7e43b87a57e15','packages_built_at':'22d3c485c70eaf5b036a2b632771f559b4c88ad0','archive_members':len(index),'uncompressed_bytes':sum(v['bytes'] for v in index.values()),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'generated_private_keys_vm_images_package_and_elf_bytes_excluded':True,'roundtrip_verified':True}
(DEST/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
manifest={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(DEST.iterdir()) if p.is_file()}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['software_head','source_count','archive_members','uncompressed_bytes','archive_bytes','archive_sha256','roundtrip_verified']}))

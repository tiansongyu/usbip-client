from pathlib import Path
ROOT=Path('/home/ubuntu/github/usbip-client')
source=(ROOT/'scripts/qemu_package/guest.py').read_text()
tail=source.split("    runtime = Path('/run/rustusb-agent')\n",1)[1].split('\n\ndef after_reboot():',1)[0]
tail="    runtime = Path('/run/rustusb-agent')\n"+tail
resume="""
def resume():
    packages = json.loads((FIXTURE/'packages.json').read_text())
    first = [str(FIXTURE/name) for name in packages['first']]
    second = [str(FIXTURE/name) for name in packages['second']]
    data = Path('/var/lib/rustusb-agent')
    entry = pwd.getpwnam('rustusb')
    before = sha(data/'retained-sentinel')
    run(['/usr/bin/python3', '-I', '/usr/libexec/rustusb/package-control', 'prepare-agent'])
"""+tail+'\n'
anchor="if __name__ == '__main__':\n"
assert source.count(anchor)==1
source=source.replace(anchor,resume+'\n'+anchor).replace("{'install': install, 'after-reboot': after_reboot}","{'install': resume, 'after-reboot': after_reboot}")
guest=Path('/tmp/rustusb-package-development-resume-guest-20261025.py');guest.write_text(source)
driver=(ROOT/'scripts/qemu_package/run.py').read_text()
driver=driver.replace("ROOT = Path(__file__).resolve().parents[2]","ROOT = Path('/home/ubuntu/github/usbip-client')").replace("HERE = Path(__file__).resolve().parent","HERE = ROOT/'scripts/qemu_package'")
anchor="    receipt = json.loads(args.image_receipt.read_text())\n"
extra="""    previous = Path({'jammy': '/tmp/rustusb-package-jammy-dev02-20261025', 'noble': '/tmp/rustusb-package-noble-dev01-20261025'}[receipt['release']])
    development_backing = previous/'.private/disk.qcow2'
    shutil.copyfile('/tmp/rustusb-package-development-resume-guest-20261025.py', out/'actual-development-guest.py')
    (out/'development-provenance.json').write_text(json.dumps({'scope':'development continuation; not fresh installation acceptance','previous_case':previous.name,'private_backing_sha256':sha(development_backing),'actual_executed_guest_sha256':sha(out/'actual-development-guest.py')},indent=2)+'\\n')
"""
assert driver.count(anchor)==1;driver=driver.replace(anchor,anchor+extra)
old="    credentials = support.credentials(private, out)\n"
new="    credentials = previous/'.private/credentials'\n    for name in ('ca', 'server', 'client'): shutil.copyfile(credentials/(name+'.der'), out/(name+'-public.der'))\n"
assert driver.count(old)==1;driver=driver.replace(old,new)
driver=driver.replace("shutil.copyfile(HERE/'guest.py', fixture/'guest.py')","shutil.copyfile(out/'actual-development-guest.py', fixture/'guest.py')")
old="    subprocess.run(['ssh-keygen', '-q', '-t', 'ed25519', '-N', '', '-f', str(key)], check=True)\n"
new="    shutil.copyfile(previous/'.private/ssh-key', key); key.chmod(0o600)\n    shutil.copyfile(previous/'.private/ssh-key.pub', key.with_suffix('.pub'))\n"
assert driver.count(old)==1;driver=driver.replace(old,new)
old="'-b', str(args.image.resolve()), str(disk), '16G'"
assert driver.count(old)==1;driver=driver.replace(old,"'-b', str(development_backing), str(disk), '16G'")
driver=driver.replace("summary = {'passed': False,", "summary = {'scope': 'development_resume_only', 'fresh_install_acceptance': False, 'passed': False,")
driver=driver.replace("remote('mkdir -m 700 /var/tmp/rustusb-package-fixture', 'create-fixture')","remote('test -d /var/tmp/rustusb-package-fixture', 'existing-fixture')")
driver=driver.replace("summary['stages'].append('install-upgrade')","summary['stages'].append('resume-upgrade')")
Path('/tmp/run-rustusb-package-development-resume-20261025.py').write_text(driver)
compile(source,str(guest),'exec');compile(driver,'development driver','exec')
print('Created development-only continuation methods; full fresh acceptance remains required.')

import concurrent.futures, hashlib, json, pathlib, subprocess, urllib.request
ROOT = pathlib.Path('/tmp/rustusb-package-images-20261025')
ROOT.mkdir(mode=0o700, exist_ok=True)
def run(item):
    release, date, version = item
    dest = ROOT / release
    dest.mkdir(exist_ok=True)
    base = f'https://cloud-images.ubuntu.com/releases/{release}/release-{date}/'
    filename = f'ubuntu-{version}-server-cloudimg-amd64.img'
    for name in ('SHA256SUMS', 'SHA256SUMS.gpg', filename):
        with urllib.request.urlopen(base + name, timeout=120) as src, (dest/name).open('wb') as out:
            while chunk := src.read(4*1024*1024): out.write(chunk)
    p = subprocess.run(['gpgv', '--keyring', '/usr/share/keyrings/ubuntu-cloudimage-keyring.gpg', str(dest/'SHA256SUMS.gpg'), str(dest/'SHA256SUMS')], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (dest/'gpgv.log').write_bytes(p.stdout)
    p.check_returncode()
    expected = next(line.split()[0] for line in (dest/'SHA256SUMS').read_text().splitlines() if line.split()[-1].lstrip('*') == filename)
    h = hashlib.sha256()
    with (dest/filename).open('rb') as f:
        while chunk := f.read(4*1024*1024): h.update(chunk)
    assert h.hexdigest() == expected
    receipt = dict(release=release, date=date, url=base+filename, filename=filename, sha256=expected, bytes=(dest/filename).stat().st_size, signature_verified=True)
    (dest/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt), flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for value in pool.map(run, [('jammy','20261020','22.04'),('noble','20261017','24.04')]): pass

from pathlib import Path
import json,hashlib,subprocess
root=Path('/home/ubuntu/github/usbip-client')
d=json.loads((root/'docs/evidence/frontend-intent-recovery-20261025/summary.json').read_text())
changed=[n for n,v in d['inputs'].items() if hashlib.sha256((root/n).read_bytes()).hexdigest()!=v['sha256']]
assert set(changed)=={'scripts/qemu_frontend_recovery/run.py','scripts/qemu_frontend_recovery/guest.sh'},changed
for n in changed:
 assert (root/n).read_bytes()==subprocess.check_output(['git','show','10117a0e:'+n],cwd=root)
assert not subprocess.check_output(['git','diff','412b40ff','--','crates','apps','vendor','Cargo.toml','Cargo.lock'],cwd=root)
for n,v in d['binaries'].items():
 p=root/('apps/rustusb-gui/target/release/rustusb-gui' if n=='rustusb-gui' else 'target/release/'+n)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'] and p.stat().st_size==v['bytes']
result=dict(previous_source_head=d['head'],previous_input_count=len(d['inputs']),changed_inputs=changed,fixture_mapped_to='10117a0e',rust_core_gui_vendor_locks_unchanged_from='412b40ff',previous_inventory_includes_gui_workflow='.github/workflows/gui.yml' in d['inputs'],three_elfs_unchanged=True,passed=True)
Path('/tmp/rustusb-debian-original-source-map-20261025.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

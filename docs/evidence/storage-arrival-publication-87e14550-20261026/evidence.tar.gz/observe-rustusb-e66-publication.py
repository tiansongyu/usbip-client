import json,urllib.request,datetime,time
from pathlib import Path
p=Path('/tmp/rustusb-storage-arrival-publication-20261026');head='87e145503e217e35832636456eff231488f91f73'
u='https://api.github.com/repos/tiansongyu/usbip-client/actions/runs?head_sha='+head+'&per_page=30'
index=0
while True:
 index+=1
 with urllib.request.urlopen(urllib.request.Request(u,headers={'Accept':'application/vnd.github+json','User-Agent':'RustUSB-publication-check'}),timeout=30) as r:b=r.read()
 (p/f'runs-{index:03d}.json').write_bytes(b)
 rows=[x for x in json.loads(b)['workflow_runs'] if x['event']=='push' and x['head_sha']==head]
 print(json.dumps([{'id':x['id'],'name':x['name'],'status':x['status'],'conclusion':x['conclusion']}for x in rows]),flush=True)
 if len(rows)>=3 and all(x['status']=='completed' for x in rows):
  assert all(x['conclusion']=='success' for x in rows)
  (p/'runs-final.json').write_bytes(b);break
 time.sleep(25)

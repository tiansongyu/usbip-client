import pathlib,json,hashlib,subprocess,re,base64,tarfile,io,shutil
repo=pathlib.Path('/home/ubuntu/github/usbip-client');target=repo/'docs/evidence/tui-hotplug-permission-2dc888c-20261025'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=repo)
assert not git('status','--porcelain').strip();target.mkdir(exist_ok=False)
software=pathlib.Path('/tmp/rustusb-tui-interactions-software-2dc888c-20261025');s=read(software/'summary.json');assert s['result']=='PASS'and s['inputs_unchanged']and all(c['exit_code']==0 for c in s['commands'])
counts={n:sum(map(int,re.findall(r'test result: ok\. (\d+) passed;', (software/(n+'.log')).read_text())))for n in ['test-default','test-all','vendor']};assert counts=={'test-default':420,'test-all':516,'vendor':20}
for n in counts:
 results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (software/(n+'.log')).read_text());assert results and all(f=='0'and i=='0'for _,f,i in results)
for n,i in s['inputs_before'].items():assert sha((repo/n).read_bytes())==i['sha256']and git('show',s['head']+':'+n)==(repo/n).read_bytes()
full=next(c['binaries']for c in s['commands']if c['name']=='release-all');fullhash={n:i['sha256']for n,i in full.items()}
old=read(repo/'docs/evidence/tui-failure-retry-4ee6be3-20261025/software-summary.json');oldhash={n:i['sha256']for n,i in next(c['binaries']for c in old['commands']if c['name']=='release-all').items()}
restore=pathlib.Path('/tmp/rustusb-tui-interactions-build-selection-20261025');assert read(restore/'summary.json')['result']=='PASS'
for n,i in full.items():assert sha((repo/'target/release'/n).read_bytes())==i['sha256']
roots=[software,restore];rows=[];pty_pass=0;pty_red=0;expected_errors=0;blocks=0
cases=[('red','/tmp/rustusb-tui-interactions-red-all-20261025'),('single','/tmp/rustusb-tui-interactions-final-all-20261025'),('single','/tmp/rustusb-tui-interactions-final-tui-20261025'),('fault','/tmp/rustusb-tui-interactions-fault-ipv4-20261025'),('fault','/tmp/rustusb-tui-interactions-fault-ipv6-20261025'),('legacy','/tmp/rustusb-tui-interactions-legacy-ipv4-20261025')]
for kind,path in cases:
 root=pathlib.Path(path);q=read(root/'summary.json');roots.append(root);single=kind in ['red','single']
 assert q['result']==('FAIL'if kind=='red'else'PASS')
 if kind=='red':assert q['failure']=='actual first address / visible disappearance / new address sequence missing'
 if single:assert q['actual_qemu_wait']==0 and not q['forced_termination']and all(q['guards'].values())
 else:assert q['guest_exit_codes']=={'server':0,'client':0}and all(q[k]for k in ['source_guard','binary_guard','head_guard','clean_guard'])and q['facts']['assertion_count']==264
 if kind=='red':assert q['binary_sha256']==oldhash
 elif single and q['features']=='tui':assert q['binary_sha256']==read(restore/'summary.json')['minimal_qemu']
 else:assert q['binary_sha256']==fullhash
 for n,i in q['source_inputs'].items():
  data=(root/'source'/n).read_bytes();assert sha(data)==i['sha256']and len(data)==i['bytes']and git('show',q['head']+':'+n)==data
  if kind!='red':assert (repo/n).read_bytes()==data
 folders=[root/'tui-artifacts']if single else[root/(r+'-artifacts')for r in ['server','client']]
 children=0;errors=0
 for folder in folders:
  for p in sorted(folder.glob('tui-*.result')):
   prefix=p.name.removesuffix('.result');f=dict(line.split('=',1)for line in p.read_text().splitlines());expected='1'if single and prefix=='tui-deny'else'0'
   assert f['uid']=='1000'and f['exit']==expected and all(f[k]=='1'for k in ['waited','raw_observed','resized','restored','entered','left'])
   status=(folder/(prefix+'.status')).read_text();assert re.search(r'^Uid:\s+1000\s+1000\s+1000\s+1000$',status,re.M)and re.search(r'^Pid:\s+'+f['pid']+'$',status,re.M)
   assert all(re.search(r'^'+c+r':\s+0000000000000000$',status,re.M)for c in ['CapInh','CapPrm','CapEff','CapAmb'])
   assert(folder/(prefix+'.exe-sha256')).read_text().split()[0]==q['binary_sha256']['rustusb']
   tty=dict(line.split('=',1)for line in(folder/(prefix+'.termios')).read_text().splitlines());assert all(tty['before_'+k]==tty['after_'+k]for k in ['flags','speeds','cc'])
   children+=1;errors+=int(expected)
 if single:
  assert children==4 and errors==1
  folder=root/'tui-artifacts';state=read(folder/'tui-agent-after-denials.json');assert state==read(folder/'tui-agent-final.json')and state['jobs']==state['sessions']==state['requests']==[]and len(state['audit'])==2
  assert all(e['actor_uid']==1000 and e['action']=='denied'and e['failure']=='permission'for e in state['audit'])
  assert(folder/'agent-wait.txt').read_text().strip()=='0'
  policy=read(folder/'tui-actual-manifest.json');assert policy['operators']==[{'uid':1000,'profiles':['observe'],'actions':['read','audit']}]
  point={n:read(root/'guest-artifacts'/('point-'+n+'.json'))for n in ['empty','added','unbound','rebound','removed','readded']}
  assert [point[n]['begin']['device_count']for n in point]==[0,1,1,1,0,1]
  a=point['added']['devices'][0];b=point['readded']['devices'][0];assert a['device']['id']==b['device']['id']and a['device']['bus_id']==b['device']['bus_id']and a['stamp']!=b['stamp']
  assert a['device']['device_address']!=b['device']['device_address']
  for left,right in zip(list(point),list(point)[1:]):assert point[left]['begin']['counters']['usb_hints']<point[right]['begin']['counters']['usb_hints']
  if kind!='red':
   for c in ['root','json','notty']:assert(folder/('tui-'+c+'-wait.txt')).read_text().strip()=='1'
 else:
  assert children==(10 if kind=='legacy'else 19)and errors==0
  for role in ['server','client']:
   folder=root/(role+'-artifacts');final=read(folder/('agent-stopped-2.json'if role=='server'else'agent-final.json'));journal=read(folder/('root-stopped-2.json'if role=='server'else'root-final.json'))
   assert all(x['terminal']and x['cleanup']=='verified'for x in final['sessions'])and journal['records']==journal['exports']==[]
 if kind=='red':pty_red+=children
 else:pty_pass+=children;expected_errors+=errors
 rows.append({'name':root.name,'head':q['head'],'result':q['result'],'source_inputs':len(q['source_inputs']),'actual_pty':children,'expected_error_children':errors,'guest_wait':q.get('actual_qemu_wait',q.get('guest_exit_codes')),'binary_sha256':q['binary_sha256']})
 shutil.copyfile(root/'summary.json',target/(root.name+'-summary.json'))
assert pty_pass==56 and expected_errors==2 and pty_red==4
shutil.copyfile(software/'summary.json',target/'software-summary.json');shutil.copyfile(restore/'summary.json',target/'build-selection-summary.json')
entries=[];payloads={}
def add(p,name):
 data=p.read_bytes();assert not data.startswith(b'\x7fELF')and not re.search(rb'-----BEGIN (?:RSA |EC |ENCRYPTED )?PRIVATE KEY-----\r?\n',data)
 assert '.private'not in str(p)and 'target/'not in name and not p.name.endswith('-key.der')
 entries.append({'path':name,'original':str(p),'bytes':len(data),'sha256':sha(data)});payloads[name]=data
for root in roots:
 for p in sorted(root.rglob('*')):
  if p.is_file():add(p,root.name+'/'+str(p.relative_to(root)))
methods=[pathlib.Path(__file__),pathlib.Path('/tmp/run-rustusb-tui-interactions-gate-20261025.py'),pathlib.Path('/tmp/restore-rustusb-tui-interactions-all-20261025.py')]
methods +=[p for p in pathlib.Path('/tmp').glob('rustusb-tui-interactions-*-20261025.*')if p.is_file()and p.suffix in ['.py','.rs','.sh','.json','.log']and 'archive-review'not in p.name]
for p in sorted(set(methods)):add(p,'methods/'+p.name)
for kind,path in cases:
 root=pathlib.Path(path)
 if kind in ['red','single']:
  data=(root/'guest-evidence.log').read_bytes()
  for prefix,folder in [('MONITOR','guest-artifacts'),('TUI','tui-artifacts')]:
   pattern=rb'RUSTUSB_'+prefix.encode()+rb'_FILE_BEGIN name=([A-Za-z0-9_.-]+) bytes=(\d+) sha256=([0-9a-f]{64})\n(.*?)RUSTUSB_'+prefix.encode()+rb'_FILE_END name=\1\n'
   for m in re.finditer(pattern,data,re.S):
    raw=base64.b64decode(m[4]);assert len(raw)==int(m[2])and sha(raw)==m[3].decode()and raw==(root/folder/m[1].decode()).read_bytes();blocks+=1
 else:
  for role in ['server','client']:
   for m in re.finditer(rb'SECURE_ARTIFACT_BEGIN ([^\n]+) (\d+)\n(.*?)SECURE_ARTIFACT_END \1\n',(root/(role+'-evidence.log')).read_bytes(),re.S):
    raw=base64.b64decode(m[3]);assert len(raw)==int(m[2])and raw==(root/(role+'-artifacts')/m[1].decode()).read_bytes();blocks+=1
archive=target/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for name,data in sorted(payloads.items()):
  info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 assert len(tar.getmembers())==len(entries)
 for member in tar.getmembers():assert sha(tar.extractfile(member).read())==sha(payloads[member.name])
for e in entries:assert sha(pathlib.Path(e['original']).read_bytes())==e['sha256']
manifest={'result':'PASS','files':entries,'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'software_counts':counts,'software_inputs':len(s['inputs_before']),'qemu':rows,'passed_pty':pty_pass,'expected_unresolved_exit1':expected_errors,'failed_run_pty':pty_red,'guest_base64_blocks_redecoded':blocks,'scope':'Same-author raw/source/identity review without importing run verifiers, not new USB execution or independent security audit. Original935 red remains FAIL. Final two single guests and three paired managed regressions:56 PTYs, two are correctly expected exit1. Six fast guard commands have no live proc samples. Minimal and all features have distinct actual ELF. No keys/ELF/targets/private host output.'}
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:manifest[k]for k in ['result','software_counts','software_inputs','qemu','passed_pty','expected_unresolved_exit1','failed_run_pty','guest_base64_blocks_redecoded','archive']}))

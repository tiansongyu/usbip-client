import pathlib,subprocess,json,hashlib,datetime
repo=pathlib.Path('/home/ubuntu/github/usbip-client');out=pathlib.Path('/tmp/rustusb-tui-interactions-build-selection-20261025');out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=repo).decode().strip()
source=pathlib.Path('/tmp/rustusb-tui-interactions-final-tui-20261025');q=json.loads((source/'summary.json').read_text());assert q['result']=='PASS'and q['features']=='tui'
assert q['build_command']==['cargo','build','--workspace','--release','--locked','--features','rustusb-cli/tui']
assert not git('status','--porcelain')and git('rev-parse','HEAD')==q['head']
for n,i in q['binary_sha256'].items():assert sha(repo/'target/release'/n)==i
minimal_metadata={n:{'bytes':(repo/'target/release'/n).stat().st_size,'sha256':sha(repo/'target/release'/n)}for n in q['binary_sha256']}
argv=['cargo','tree','-p','rustusb-cli','--features','tui','-e','normal','--locked']
r=subprocess.run(argv,cwd=repo,capture_output=True);(out/'minimal-cli-tree.stdout').write_bytes(r.stdout);(out/'minimal-cli-tree.stderr').write_bytes(r.stderr);assert r.returncode==0
assert not any(n in r.stdout for n in [b'rustusb-rust-backend',b'nusb v',b'rusb v',b'libusb'])
argv=['cargo','build','--workspace','--all-features','--release','--locked']
with(out/'restore-all.log').open('wb')as f:r=subprocess.run(argv,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0
s=json.loads(pathlib.Path('/tmp/rustusb-tui-interactions-software-2dc888c-20261025/summary.json').read_text());expected=next(c['binaries']for c in s['commands']if c['name']=='release-all')
actual={n:{'bytes':(repo/'target/release'/n).stat().st_size,'sha256':sha(repo/'target/release'/n)}for n in expected};assert actual==expected
assert not git('status','--porcelain')and git('rev-parse','HEAD')==q['head']
summary={'result':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':q['head'],'minimal_qemu':q['binary_sha256'],'minimal_binary_metadata':minimal_metadata,'minimal_normal_cli_excludes_rust_backend_nusb':True,'restored_all':actual,'restore_command':argv,'restore_exit':r.returncode,'scope':'Distinct actual QEMU feature artifacts and final all-feature restoration, not another software or USB execution'}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))

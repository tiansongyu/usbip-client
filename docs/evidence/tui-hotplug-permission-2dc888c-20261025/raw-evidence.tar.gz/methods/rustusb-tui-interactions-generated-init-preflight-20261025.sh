#!/bin/sh
# Only PID1 of the owned disposable VM may run these kernel/device operations.
set -eu
[ "$$" = 1 ] && [ "${RUSTUSB_QEMU_GUEST:-}" = 1 ] || exit 2
export PATH=/usr/bin:/bin:/sbin
mount -t proc proc /proc
case " $(cat /proc/cmdline) " in *' rustusb.monitor=local '*) ;; *) exit 2 ;; esac
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
mount -t tmpfs tmpfs /tmp
mount -t tmpfs -o mode=0755 tmpfs /run
/bin/busybox stty -F /dev/ttyS1 raw -echo 115200 clocal -hupcl
exec >/dev/ttyS1 2>&1
WATCH_PID=
KERNEL_PID=
STAGE=boot
# Disposable PID1 composition only; no production testing RPC.
TUI_PID='' AGENT_PID=''
tui_wait() {
    for tui_poll in $(seq 1 500); do
        [ ! -f "$TUI_PREFIX.$1" ] || return 0
        kill -0 "$TUI_PID"; sleep 0.05
    done
    return 1
}
tui_signal() { cat /proc/uptime > "$TUI_PREFIX.$1"; }
tui_launch() {
    TUI_PREFIX="/tmp/tui-$1"
    (exec 5<&-; exec /usr/bin/setpriv --reuid=1000 --regid=1000 --clear-groups /usr/bin/tui-interaction-pty "$1" "$TUI_PREFIX") & TUI_PID=$!
}
tui_join() { wait "$TUI_PID"; TUI_PID=''; }
tui_actor() {
    tui_child=$(cat "$TUI_PREFIX.pid")
    [ "$(readlink "/proc/$tui_child/exe")" = /usr/bin/rustusb ]
    [ "$(awk '/^Uid:/{print $2 ":" $3 ":" $4 ":" $5}' "/proc/$tui_child/status")" = 1000:1000:1000:1000 ]
    {
        echo "PID=$tui_child"
        cat "/proc/$tui_child/status" "/proc/$tui_child/stat"
        echo "EXE=$(readlink "/proc/$tui_child/exe")"
        sha256sum "/proc/$tui_child/exe"
        tr '\000' ' ' < "/proc/$tui_child/cmdline"; echo
        for tui_fd in /proc/"$tui_child"/fd/*; do
            echo "FD=$(basename "$tui_fd") TARGET=$(readlink "$tui_fd")"
            cat "/proc/$tui_child/fdinfo/$(basename "$tui_fd")"
        done
        echo NETLINK_TABLE; cat /proc/net/netlink
    } > "/tmp/tui-actor-$1.txt"
}
frontend_setup() {
    mkdir -p /dev/pts /run/agent /var/lib/rustusb/agent /home/operator/.config/rustusb
    mount -t devpts devpts /dev/pts
    chown 2000:2000 /run/agent /var/lib/rustusb/agent
    chmod 711 /run/agent; chmod 700 /var/lib/rustusb/agent
    chown 1000:1000 /home/operator /home/operator/.config /home/operator/.config/rustusb
    chmod 700 /home/operator /home/operator/.config /home/operator/.config/rustusb
    chown 2000:2000 /etc/rustusb/server-key.der
    chmod 600 /etc/rustusb/server-key.der
    tui_key="native:usb-$(printf '%064d' 1)"
    tui_pin=$(sha256sum /etc/rustusb/client.der | awk '{print $1}')
    jq -n --arg key "$tui_key" --arg pin "$tui_pin" '{schema_version:1,broker_uid:2000,listen:"127.0.0.1:3241",devices:[$key],principals:[{id:"qemu-client",pins:[$pin],devices:[$key]}],ca_certificates:["/etc/rustusb/ca.der"],certificate_chain:["/etc/rustusb/server.der"],private_key:"/etc/rustusb/server-key.der"}' > /etc/rustusb/server.json
    jq -n '{schema_version:1,broker_uid:2000,helper_socket:"/run/rustusb/control.sock",control_directory:"/run/agent",data_directory:"/var/lib/rustusb/agent",profiles:[{id:"observe",backend:"native",config:"/etc/rustusb/server.json"}],operators:[{uid:1000,profiles:["observe"],actions:["read","audit"]}]}' > /etc/rustusb/agent.json
    chmod 644 /etc/rustusb/server.json /etc/rustusb/agent.json
    cp /etc/rustusb/server.json /tmp/tui-actual-server.json
    cp /etc/rustusb/agent.json /tmp/tui-actual-manifest.json
    stat -c '%u:%a:%h' /etc/rustusb/agent.json /etc/rustusb/server.json /etc/rustusb/server-key.der > /tmp/tui-config-stat.txt
    /usr/bin/setpriv --reuid=1000 --regid=1000 --clear-groups /bin/sh -c '[ ! -r /etc/rustusb/server-key.der ]'
    echo 0 > /tmp/tui-operator-key-unreadable.txt
    (exec 5<&-; exec /usr/bin/setpriv --reuid=2000 --regid=2000 --clear-groups /usr/bin/rustusb agent --config /etc/rustusb/agent.json run > /tmp/agent.stdout 2> /tmp/agent.stderr) & AGENT_PID=$!
    for tui_poll in $(seq 1 200); do
        if /usr/bin/setpriv --reuid=1000 --regid=1000 --clear-groups /usr/bin/rustusb agent --config /etc/rustusb/agent.json profiles > /tmp/tui-agent-profiles.json 2> /tmp/tui-agent-profiles.stderr; then break; fi
        kill -0 "$AGENT_PID"; sleep 0.05
    done
    jq -e '.journal_healthy and .response=={result:"profiles",profiles:[{id:"observe",backend:"native"}]}' /tmp/tui-agent-profiles.json > /dev/null
    cat "/proc/$AGENT_PID/status" "/proc/$AGENT_PID/stat" > /tmp/agent-identity.txt
    sha256sum "/proc/$AGENT_PID/exe" > /tmp/agent-exe-sha256.txt
    [ ! -e /var/lib/rustusb/agent/state.json ]
}
frontend_remaining() {
    STAGE=frontend-preferences
    printf '%s\n' '{"schema_version":1,"options":{"refresh_seconds":3,"auto_refresh":false,"monochrome":true}}' > /home/operator/.config/rustusb/preferences.json
    chown 1000:1000 /home/operator/.config/rustusb/preferences.json; chmod 600 /home/operator/.config/rustusb/preferences.json
    cp /home/operator/.config/rustusb/preferences.json /tmp/tui-preferences-initial.json
    tui_launch preferences
    tui_wait defaults-shown
    cmp /tmp/tui-preferences-initial.json /home/operator/.config/rustusb/preferences.json
    printf '%s\n' '{"schema_version":1,"options":{"refresh_seconds":5,"auto_refresh":false,"monochrome":true}}' > /home/operator/.config/rustusb/preferences.json
    cp /home/operator/.config/rustusb/preferences.json /tmp/tui-preferences-changed.json
    stat -c '%u:%a:%h' /home/operator/.config/rustusb/preferences.json > /tmp/tui-preferences-changed-stat.txt
    tui_signal changed
    tui_join
    cmp /tmp/tui-preferences-changed.json /home/operator/.config/rustusb/preferences.json
    STAGE=frontend-reload-permission
    tui_launch reload-error
    tui_wait ready
    chmod 644 /home/operator/.config/rustusb/preferences.json
    stat -c '%u:%a:%h' /home/operator/.config/rustusb/preferences.json > /tmp/tui-preferences-error-stat.txt
    tui_signal changed
    tui_join
    cmp /tmp/tui-preferences-changed.json /home/operator/.config/rustusb/preferences.json
    chmod 600 /home/operator/.config/rustusb/preferences.json
    STAGE=frontend-agent-denied
    [ ! -e /var/lib/rustusb/agent/state.json ]
    tui_launch deny
    tui_join
    cp /var/lib/rustusb/agent/state.json /tmp/tui-agent-after-denials.json
    jq -e '.jobs==[] and .sessions==[] and .requests==[] and (.audit|length)==2 and all(.audit[]; .actor_uid==1000 and .action=="denied" and .failure=="permission")' /tmp/tui-agent-after-denials.json > /dev/null
    [ ! -d /sys/module/usbip_host ] && [ ! -d /sys/module/vhci_hcd ]
    cat /proc/net/tcp /proc/net/tcp6 > /tmp/tui-tcp-after.txt
    kill -TERM "$AGENT_PID"
    set +e; wait "$AGENT_PID"; tui_wait_status=$?; set -e
    echo "$tui_wait_status" > /tmp/agent-wait.txt
    [ "$tui_wait_status" = 0 ] && [ ! -e "/proc/$AGENT_PID" ] && [ ! -e /run/agent/control.sock ]
    AGENT_PID=''
    cp /var/lib/rustusb/agent/state.json /tmp/tui-agent-final.json
    cmp /tmp/tui-agent-after-denials.json /tmp/tui-agent-final.json
    [ ! -e /run/rustusb/control.sock ]
    echo 'TUI_NO_USB_OWNERS modules_absent=true helper_socket_absent=true admitted_requests=0'
}
frontend_collect() {
    mkdir -p /tmp/tui-frozen
    for tui_file in /tmp/tui-* /tmp/agent-* /tmp/agent.stdout /tmp/agent.stderr; do
        [ -f "$tui_file" ] || continue
        tui_name=$(basename "$tui_file")
        cp "$tui_file" "/tmp/tui-frozen/$tui_name" || return 1
        tui_frozen="/tmp/tui-frozen/$tui_name"
        tui_bytes=$(wc -c < "$tui_frozen")
        [ "$tui_bytes" -le 1048576 ] || return 1
        echo "RUSTUSB_TUI_FILE_BEGIN name=$tui_name bytes=$tui_bytes sha256=$(sha256sum "$tui_frozen" | awk '{print $1}')"
        base64 "$tui_frozen" || return 1
        echo "RUSTUSB_TUI_FILE_END name=$tui_name"
    done
}
frontend_cleanup() {
    frontend_status=$?
    trap - EXIT
    set +e
    for frontend_child in "$TUI_PID" "$AGENT_PID"; do
        [ -n "$frontend_child" ] || continue
        kill -TERM "$frontend_child" 2>/dev/null
        for frontend_poll in $(seq 1 100); do
            [ ! -e "/proc/$frontend_child/status" ] && break
            grep -q '^State:.*Z' "/proc/$frontend_child/status" && break
            sleep 0.05
        done
        if [ -e "/proc/$frontend_child/status" ] && ! grep -q '^State:.*Z' "/proc/$frontend_child/status"; then
            echo "RUSTUSB_TUI_FORCED_CHILD pid=$frontend_child"
            kill -KILL "$frontend_child"; frontend_status=1
        fi
        wait "$frontend_child"
    done
    frontend_collect || frontend_status=1
    # Pass the original result into the unchanged monitor collector/cleanup.
    frontend_result() { return "$frontend_status"; }
    frontend_result
    monitor_cleanup
}

collect() {
    prefix=$1
    mkdir -p /tmp/frozen-capture
    for file in /tmp/watch.jsonl /tmp/watch.stderr /tmp/kernel-events.log /tmp/kernel-events.stderr /tmp/actor-*.txt /tmp/point-*.json /tmp/stat-*.txt /tmp/*-wait.txt /tmp/independent-final.txt; do
        [ -f "$file" ] || continue
        name="$prefix$(basename "$file")"
        cp "$file" "/tmp/frozen-capture/$name" || return 1
        file="/tmp/frozen-capture/$name"
        echo "RUSTUSB_MONITOR_FILE_BEGIN name=$name bytes=$(wc -c < "$file") sha256=$(sha256sum "$file" | awk '{print $1}')"
        base64 "$file" || return 1
        echo "RUSTUSB_MONITOR_FILE_END name=$name"
    done
}
monitor_cleanup() {
    status=$?
    trap - EXIT
    # Failure diagnostics are copied before waiting for any still-live child.
    if [ "$status" != 0 ]; then
        if ! collect early-; then echo 'RUSTUSB_MONITOR_CAPTURE: FAIL early'; status=1; fi
    fi
    for pid in "$WATCH_PID" "$KERNEL_PID"; do
        [ -n "$pid" ] || continue
        kill -TERM "$pid" 2>/dev/null || true
    done
    for kind in watch kernel; do
        if [ "$kind" = watch ]; then pid=$WATCH_PID; else pid=$KERNEL_PID; fi
        [ -n "$pid" ] || continue
        for attempt in $(seq 1 40); do
            [ ! -e "/proc/$pid/status" ] && break
            grep -q '^State:.*Z' "/proc/$pid/status" && break
            sleep 0.05
        done
        if [ -e "/proc/$pid/status" ] && ! grep -q '^State:.*Z' "/proc/$pid/status"; then
            echo "RUSTUSB_MONITOR_FORCED_CHILD: $kind pid=$pid"
            kill -KILL "$pid" 2>/dev/null || true
            status=1
        fi
        set +e; wait "$pid"; result=$?; set -e
        echo "$result" >"/tmp/$kind-cleanup-wait.txt"
    done
    if ! collect ''; then echo 'RUSTUSB_MONITOR_CAPTURE: FAIL final'; status=1; fi
    if [ "$status" = 0 ]; then echo 'RUSTUSB_MONITOR_RESULT: PASS'; else echo "RUSTUSB_MONITOR_RESULT: FAIL stage=$STAGE exit=$status"; fi
    sync
    poweroff -f
}
trap frontend_cleanup EXIT
echo 'RUSTUSB_MONITOR_CHANNEL: ttyS1 kernel=ttyS0'
echo "RUSTUSB_MONITOR_BOOT kernel=$(uname -r)"
for name in usb-common usbcore evdev hid hid-generic usbhid xhci-hcd xhci-pci-renesas xhci-pci; do
    [ ! -f "/modules/$name.ko" ] || insmod "/modules/$name.ko"
done
# No helper, USB/IP driver, network interface or USB device node is opened by the watcher.
[ ! -d /sys/module/usbip_host ] && [ ! -d /sys/module/vhci_hcd ]
frontend_setup
/usr/bin/udevadm monitor --kernel --subsystem-match=usb --property >/tmp/kernel-events.log 2>/tmp/kernel-events.stderr &
KERNEL_PID=$!
/usr/bin/setpriv --reuid=2000 --regid=2000 --clear-groups env RUST_LOG=error /usr/bin/rustusb devices --watch --json >/tmp/watch.jsonl 2>/tmp/watch.stderr &
WATCH_PID=$!
wait_point() {
    name=$1
    minimum=$2
    predicate=$3
    for attempt in $(seq 1 200); do
        [ -e "/proc/$WATCH_PID" ] || return 1
        if jq -s -f /etc/monitor-point.jq /tmp/watch.jsonl >/tmp/candidate-point.json 2>/dev/null &&
           jq -e --argjson minimum "$minimum" ".begin.state == \"current\" and .end.revision > \$minimum and ($predicate)" /tmp/candidate-point.json >/dev/null; then
            cp /tmp/candidate-point.json "/tmp/point-$name.json"
            return 0
        fi
        sleep 0.05
    done
    return 1
}
actor() {
    name=$1
    {
        echo "PID=$WATCH_PID"
        cat "/proc/$WATCH_PID/status"
        cat "/proc/$WATCH_PID/stat"
        echo "EXE=$(readlink "/proc/$WATCH_PID/exe")"
        sha256sum "/proc/$WATCH_PID/exe"
        tr '\000' ' ' < "/proc/$WATCH_PID/cmdline"; echo
        for file in /proc/"$WATCH_PID"/fd/*; do
            echo "FD=$(basename "$file") TARGET=$(readlink "$file")"
            cat "/proc/$WATCH_PID/fdinfo/$(basename "$file")"
        done
        echo NETLINK_TABLE
        cat /proc/net/netlink
    } >"/tmp/actor-$name.txt"
    [ "$(awk '/^Uid:/{print $2 ":" $3 ":" $4 ":" $5}' "/proc/$WATCH_PID/status")" = 2000:2000:2000:2000 ]
    [ "$(awk '/^CapEff:/{print $2}' "/proc/$WATCH_PID/status")" = 0000000000000000 ]
}
stamp() {
    name=$1
    point=$2
    bus=$(jq -r '.devices[0].device.bus_id' "$point")
    {
        echo "BUS_ID=$bus"
        stat -Lc 'STAT_DEV=%d STAT_INODE=%i' "/sys/bus/usb/devices/$bus"
        echo "BUSNUM=$(cat "/sys/bus/usb/devices/$bus/busnum")"
        echo "DEVNUM=$(cat "/sys/bus/usb/devices/$bus/devnum")"
    } >"/tmp/stat-$name.txt"
}
STAGE=initial
wait_point empty -1 '.begin.device_count == 0'
actor initial
tui_launch hotplug
tui_wait ready
tui_actor initial
REV=$(jq -r '.end.revision' /tmp/point-empty.json)
echo 'RUSTUSB_MONITOR_REQUEST: add'
STAGE=add
wait_point added "$REV" '.begin.device_count == 1 and (.devices[0].device.interfaces | any(.class == 3 and .driver == "usbhid"))'
stamp first /tmp/point-added.json
tui_signal added
tui_wait added-shown
BUS=$(jq -r '.devices[0].device.bus_id' /tmp/point-added.json)
IFACE="$BUS:1.0"
[ "$(cat "/sys/bus/usb/devices/$IFACE/bInterfaceClass")" = 03 ]
REV=$(jq -r '.end.revision' /tmp/point-added.json)
STAGE=unbind
printf '%s' "$IFACE" >/sys/bus/usb/drivers/usbhid/unbind
wait_point unbound "$REV" '.begin.device_count == 1 and (.devices[0].device.interfaces | any(.class == 3 and .driver == null))'
REV=$(jq -r '.end.revision' /tmp/point-unbound.json)
STAGE=rebind
printf '%s' "$IFACE" >/sys/bus/usb/drivers/usbhid/bind
wait_point rebound "$REV" '.begin.device_count == 1 and (.devices[0].device.interfaces | any(.class == 3 and .driver == "usbhid"))'
REV=$(jq -r '.end.revision' /tmp/point-rebound.json)
echo 'RUSTUSB_MONITOR_REQUEST: remove'
STAGE=remove
wait_point removed "$REV" '.begin.device_count == 0'
[ ! -e "/sys/bus/usb/devices/$BUS" ]
tui_signal removed
tui_wait removed-shown
REV=$(jq -r '.end.revision' /tmp/point-removed.json)
echo 'RUSTUSB_MONITOR_REQUEST: readd'
STAGE=readd
wait_point readded "$REV" '.begin.device_count == 1 and (.devices[0].device.interfaces | any(.class == 3 and .driver == "usbhid"))'
stamp second /tmp/point-readded.json
actor before-stop
tui_signal readded
tui_wait readded-shown
tui_actor before-stop
tui_signal finish
tui_join
STAGE=stop
kill -TERM "$WATCH_PID"
set +e; wait "$WATCH_PID"; result=$?; set -e
echo "$result" >/tmp/watch-wait.txt
[ "$result" = 0 ] && [ ! -e "/proc/$WATCH_PID" ]
WATCH_PID=
echo 'RUSTUSB_MONITOR_REQUEST: final-remove'
STAGE=final-baseline
for attempt in $(seq 1 200); do [ ! -e "/sys/bus/usb/devices/$BUS" ] && break; sleep 0.05; done
[ ! -e "/sys/bus/usb/devices/$BUS" ]
find /sys/bus/usb/devices -maxdepth 1 -print >/tmp/independent-final.txt
[ ! -d /sys/module/usbip_host ] && [ ! -d /sys/module/vhci_hcd ]
frontend_remaining
STAGE=complete

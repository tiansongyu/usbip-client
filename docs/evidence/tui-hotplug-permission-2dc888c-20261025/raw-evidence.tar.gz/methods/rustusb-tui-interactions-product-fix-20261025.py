from pathlib import Path
p=Path('crates/rustusb-tui/src/terminal.rs');s=p.read_text();old='        self.selected[self.page] = selected.map(|i| rows[i].key.clone());';new='''        let key = selected.map(|i| rows[i].key.clone());
        if self.selected[self.page] != key {
            // A disappeared/replaced identity must not hide its new detail text.
            self.detail_scroll = 0;
        }
        self.selected[self.page] = key;''';assert s.count(old)==1;p.write_text(s.replace(old,new,1))

import pathlib, urllib.request, concurrent.futures, hashlib, json, datetime
r=pathlib.Path('/tmp/rustusb-storage-policy-usbfs-20261026')
jobs=[]
for ver in ['v5.15','v6.8']:
 for p in ['drivers/base/devtmpfs.c','drivers/base/core.c','fs/namei.c','fs/open.c','fs/read_write.c','fs/ioctl.c','security/device_cgroup.c','include/linux/device_cgroup.h','kernel/bpf/cgroup.c','include/linux/bpf-cgroup.h','Documentation/admin-guide/cgroup-v1/devices.rst','Documentation/admin-guide/cgroup-v2.rst','Documentation/bpf/prog_cgroup_sockopt.rst','security/security.c','security/selinux/hooks.c','security/apparmor/file.c','security/apparmor/lsm.c','Documentation/security/LSM.rst','include/uapi/linux/usbdevice_fs.h','include/uapi/linux/usb/ch9.h','drivers/usb/core/urb.c']:
  jobs.append((f'linux-{ver}/{p}',f'https://raw.githubusercontent.com/torvalds/linux/{ver}/{p}'))
for ver in ['v249','v255']:
 for p in ['rules.d/50-udev-default.rules.in','rules.d/70-uaccess.rules.in','rules.d/73-seat-late.rules.in','src/udev/udev-builtin-uaccess.c','src/shared/acl-util.c','man/systemd.resource-control.xml','LICENSE.GPL2','LICENSE.LGPL2.1','LICENSES/README']:
  jobs.append((f'systemd-{ver}/{p}',f'https://raw.githubusercontent.com/systemd/systemd/{ver}/{p}'))
 for endpoint in ['commits/']:
  jobs.append((f'metadata/systemd-{ver}.json',f'https://api.github.com/repos/systemd/systemd/{endpoint}{ver}'))
for ver in ['249.11-0ubuntu3','255.4-1ubuntu8']:
 jobs.append((f'ubuntu/udev_{ver}_amd64.deb',f'https://archive.ubuntu.com/ubuntu/pool/main/s/systemd/udev_{ver}_amd64.deb'))
def get(pair):
 p,u=pair
 try:
  b=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'RustUSB-source-research/1'}),timeout=50).read();d=r/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
  return {'path':p,'url':u,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'fetched_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ok'}
 except Exception as e:return {'path':p,'url':u,'status':'error','error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:a=list(pool.map(get,jobs))
(r/'sources-e67.json').write_text(json.dumps(a,indent=2)+'\n')
for x in a:
 if x['status']!='ok':print(x['path'],x['error'])
print('downloaded',sum(x['status']=='ok' for x in a),'of',len(a))

import pathlib,urllib.request,json,hashlib,datetime
r=pathlib.Path('/tmp/rustusb-storage-policy-usbfs-20261026');a=[]
for ver in ['v249','v255']:
 sha=json.loads((r/f'metadata/systemd-{ver}.json').read_text())['sha']
 for p in ['src/libsystemd/sd-device/device-private.c','src/libsystemd/sd-device/sd-device.c','src/udev/udev-event.c']:
  if (r/f'systemd-{ver}/{p}').exists():continue
  dst=f'systemd-{ver}/{p}';u=f'https://raw.githubusercontent.com/systemd/systemd/{sha}/{p}'
  try:
   b=urllib.request.urlopen(u,timeout=45).read();d=r/dst;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
   a.append({'path':dst,'url':u,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'fetched_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ok'})
  except Exception as e:a.append({'path':dst,'url':u,'status':'error','error':str(e)})
(r/'sources-acl.json').write_text(json.dumps(a,indent=2)+'\n');print([(x['path'],x['status']) for x in a])

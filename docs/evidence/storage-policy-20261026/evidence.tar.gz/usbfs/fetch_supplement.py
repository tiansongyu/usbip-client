import pathlib,urllib.request,json,hashlib,datetime,concurrent.futures
r=pathlib.Path('/tmp/rustusb-storage-policy-usbfs-20261026');old=json.loads((r/'sources-e67.json').read_text());jobs=[]
for x in old:
 if x['status']=='error' and '429' in x['error']:
  jobs.append((x['path'],x['url'].replace('/v6.8/','/e8f897f4afef0031fe618a8e94127a0934896aba/')))
for p in ['rules.d/70-uaccess.rules','rules.d/73-seat-late.rules','LICENSES/README.md']:
 jobs.append((f'systemd-v249/{p}',f'https://raw.githubusercontent.com/systemd/systemd/v249/{p}'))
for ver in ['249.11-0ubuntu3','255.4-1ubuntu8']:
 jobs.append((f'ubuntu/systemd_{ver}_amd64.deb',f'https://archive.ubuntu.com/ubuntu/pool/main/s/systemd/systemd_{ver}_amd64.deb'))
for p in ['man/udev.xml','src/udev/udev-rules.c','src/udev/udev-node.c','src/udev/udev-event.c']:
 jobs.append((f'systemd-v255/{p}',f'https://raw.githubusercontent.com/systemd/systemd/v255/{p}'))
def get(pair):
 p,u=pair
 try:
  b=urllib.request.urlopen(u,timeout=45).read();d=r/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
  return {'path':p,'url':u,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'fetched_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ok'}
 except Exception as e:return {'path':p,'url':u,'status':'error','error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:a=list(p.map(get,jobs))
(r/'sources-supplement.json').write_text(json.dumps(a,indent=2)+'\n')
for x in a:
 if x['status']!='ok':print(x['path'],x['error'])
print('downloaded',sum(x['status']=='ok' for x in a),'of',len(a))

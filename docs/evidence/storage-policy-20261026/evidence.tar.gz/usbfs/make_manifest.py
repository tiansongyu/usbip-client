import pathlib,json,hashlib,re
r=pathlib.Path('/tmp/rustusb-storage-policy-usbfs-20261026')
manifest=[]; failures=[]; bad=[]; reused=[]
for f in sorted(r.glob('sources-*.json')):
 data=json.loads(f.read_text())
 for e in data:
  row=dict(e,manifest=f.name)
  if e.get('status')!='ok':failures.append(row);continue
  p=r/e['path']
  if not p.is_file():bad.append({'manifest':f.name,'path':e['path'],'reason':'missing'});continue
  actual=hashlib.sha256(p.read_bytes()).hexdigest()
  row['current_sha256']=actual;row['matches_recorded_hash']=actual==e['sha256']
  if not row['matches_recorded_hash']:bad.append(row)
  if p.suffix in ['.c','.h','.xml','.in','.rules','.rst']:
   text=p.read_text(errors='replace')[:4000]
   row['spdx_in_original']=re.findall(r'SPDX-License-Identifier:\s*([^\r\n*<]+)',text)
  manifest.append(row)
  if f.name in ['sources-inherited.json','sources-new.json','sources-sg.json']:reused.append(row)
(r/'ORIGINALS.json').write_text(json.dumps(manifest,indent=2)+'\n')
(r/'FETCH-FAILURES.json').write_text(json.dumps(failures,indent=2)+'\n')
(r/'REUSED-E66.json').write_text(json.dumps(reused,indent=2)+'\n')
(r/'VERIFICATION.json').write_text(json.dumps({'recorded_successes':len(manifest),'unique_paths':len(set(e['path'] for e in manifest)),'recorded_failures':len(failures),'reused_E66_records':len(reused),'mismatches_or_missing':bad},indent=2)+'\n')
print((r/'VERIFICATION.json').read_text())

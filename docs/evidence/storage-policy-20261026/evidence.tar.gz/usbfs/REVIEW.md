# E67 USBFS access lifecycle and arrival enrollment review

Status: independent source review and proposed guest experiments, 2026-10-26. No repository changes, compilation, QEMU execution, host device/process inspection, or product storage authorization were performed by this research agent. The parent is implementing its own guest fixture. This report does not supply a completed storage handoff, cache-drain proof, USBFS storage backend, or hardware acceptance.

The existing E66 validation was read before this review. It records successful final stock Linux USB/IP Native mechanism trials and retains the earlier QEMU LUN 1 sense failure and forced-disposal trials. In particular, the cache fault must remain on **LUN 0** for QEMU 6.2: its REQUEST_SENSE handling for nonzero LUN is a separate emulator limitation. This review does not reinterpret those results.

## Findings that change the design

1. **Corrected hypothesis:** an already registered USBFS file description is invalidated when the generic USB device driver is unbound during stock `usbip bind`. Its next writable-FD GET_DESCRIPTOR ioctl should fail with `ENODEV` (19). The FD is still open; its `usb_dev_state` is no longer connected. This is stronger than chmod, but weaker than a complete withdrawal of all previously admitted operations.
2. A root-opened writable USBFS FD newly acquired while the same generation is bound to `usbip-host`, then delegated to a capability-free ordinary user, remains a control channel after chmod and device deauthorization. DEVICE-recipient GET_DESCRIPTOR uses ep0 and does not claim an interface. Stable ADDRESS and CONFIGURED states are accepted. For the normal QEMU fixture, expect exactly 18 descriptor bytes. Read-only FDs fail this ioctl with `EPERM` (1), including after logical disconnect, because the write-mode gate runs first.
3. **chmod + ACL removal + generic unbind is not a complete proof of prior capability withdrawal.** An open that already passed VFS permission checking may register after the synchronous USBFS removal notification. A synchronous control ioctl that already passed USBFS checks can drop the device lock before submission and is not on the USBFS async-pending list killed by that notification. These are source-derived admissible schedules, not experimentally reproduced races in this report.
4. A defensible first product claim is conditional **arrival enrollment from a known controlled birth**, with trusted privileged actors, closed permission/ACL policy before birth, no alternate accessible raw-device nodes or FD delegation, and default device denial across reboot/HCD generations. A late census or chmod does not establish that history.
5. Keep Native and USBFS claims separate. An interface-claim failure does not prove ep0 control exclusion. Neither raw access exclusion nor Native stub binding proves storage ownership, filesystem quiescence, per-LUN cache durability, or safe recovery after a write/flush fault.

## Fixed source identities and method

| Component | Fixed identity | Use |
| --- | --- | --- |
| Linux v5.15 | `8bb7eca972ad531c9b149c0a51ab43a417385813` | Upstream fixed implementation; not a claim that Ubuntu's downstream kernel is byte-identical |
| Linux v6.8 | `e8f897f4afef0031fe618a8e94127a0934896aba` | Same distinction |
| QEMU v6.2.0 | `44f28df24767cf9dca1ddc9b23157737c4cbb645` | Reused E66 sources and original sense/cache conclusions |
| sg3_utils release-1.46 | `b81d7816ca45f02bb3d50e4adde0222e8b66c2eb` | Reused E66 originals; no new storage command execution |
| systemd v249 | `f6278558da0304ec6b646bb172ce4688c7f162a5` | Udev/ACL implementation; tag-resolution API response retained |
| systemd v255 | `db11bab38ccf1ed257f310d29070843d4c58ea01` | Udev/ACL implementation; tag-resolution API response retained |
| Ubuntu release-base packages | `udev` and `systemd` `249.11-0ubuntu3`, `255.4-1ubuntu8`, amd64 | Official archive packages downloaded and extracted, not installed; exact package bytes/hashes retained |

Methods: primary upstream source inspection; official Ubuntu archive package extraction using `dpkg-deb -x`; official systemd versioned manual browsing; SHA-256 verification against inherited and new download receipts. All output is confined to this directory. The base Ubuntu packages are **not asserted to be the actual upgraded packages in either guest**. The parent must record the guest's package versions and rules independently.

`ORIGINALS.json` contains source URL, saved path, SHA-256, byte length, fetch time and SPDX where present. `REUSED-E66.json` preserves inherited URL/hash records independently. `FETCH-FAILURES.json` retains the 404 and 429 responses rather than presenting them as successful retrievals. `VERIFICATION.json` records 223 successful receipt entries, 219 unique original paths, 142 inherited E66 receipt entries, and no missing/hash-mismatched originals after copying the two initially omitted inherited web originals. `SHA256SUMS` inventories regular files, including extracted package files, separately from source receipts.

Raw source files preserve original SPDX/license comments. Linux COPYING and GPL-2.0 text, QEMU COPYING/LICENSE, sg3_utils COPYING, systemd GPL2/LGPL2.1 texts, and Ubuntu package copyright files are retained. Systemd C/rules files have file-specific GPL/LGPL licenses; its manual XML identifies LGPL-2.1-or-later. Do not relicense these originals with the independently authored probe. The probe carries an MIT SPDX identifier and is an uncompiled specimen.

## Source map

Paths below are relative to `linux-v5.15/` and `linux-v6.8/`; line references identify the saved originals. Immutable primary-source links are provided for the central paths.

| Mechanism | v5.15 | v6.8 |
| --- | --- | --- |
| USBFS connected predicate | `drivers/usb/core/devio.c:167` | `devio.c:180` |
| Async kill loop | `devio.c:640` | `devio.c:660` |
| Control recipient/state checks | `devio.c:856` | `devio.c:878` |
| USBFS open and registration | `devio.c:1010` | `devio.c:1032` |
| Synchronous control | `devio.c:1105`, calls `usb_control_msg` outside device lock | `devio.c:1136,1166`, local URB submit/wait outside device lock |
| RESET and SET_CONFIGURATION | `devio.c:1396,1440` | `devio.c:1499,1543` |
| ioctl write-mode gate | `devio.c:2502` | `devio.c:2605` |
| Removal notification clears USBFS list | `devio.c:2747` | `devio.c:2858` |
| Generic driver disconnect | `drivers/usb/core/generic.c:253` | `generic.c:269` |
| Device-driver unbind, called with device lock | `drivers/usb/core/driver.c:303` | `driver.c:306` |
| Device deauthorization | `drivers/usb/core/hub.c:2616` | `hub.c:2669` |
| Unconfigure skips ep0 | `drivers/usb/core/message.c:2027` | `message.c:2063` |
| Default devtmpfs mode | `drivers/base/devtmpfs.c:110,126` | `devtmpfs.c:114,130` |
| Open permission before driver open | `fs/namei.c:3426,3428`; `fs/open.c:942` | `namei.c:3643,3645`; `open.c:902,1084` |
| Per-ioctl LSM hook | `fs/ioctl.c:868` | `fs/ioctl.c:865` |

Primary originals: [Linux 5.15 devio](https://github.com/torvalds/linux/blob/8bb7eca972ad531c9b149c0a51ab43a417385813/drivers/usb/core/devio.c), [Linux 6.8 devio](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/devio.c), [6.8 generic disconnect](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/generic.c#L269), [6.8 notification](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/notify.c#L48), [6.8 device deauthorization](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/hub.c#L2669).

## Correction: pre-bind and post-bind cohorts are different

The initial task hypothesis and first research message grouped chmod, deauthorization, and Native binding as operations through which an old writable FD would survive. That grouping was wrong. The contradictory source chain is:

1. The stock bind tool unbinds the currently bound generic USB device driver before binding `usbip-host`.
2. `usb_generic_driver_disconnect` calls `usb_notify_remove_device` before unconfiguring.
3. `notify.c` uses a blocking notifier chain. `usbdev_notify` synchronously calls `usbdev_remove`.
4. `usbdev_remove` runs `destroy_all_async`, wakes waiters, and removes each registered `usb_dev_state` from `udev->filelist` using `list_del_init`.
5. `connected(ps)` tests that list membership as well as the physical NOTATTACHED state. Future ordinary ioctls on a writable old file description fail `ENODEV` after acquiring the USB device lock.

The same inode and numeric FD can therefore remain visible while the old USBFS state is invalid. `dup`, inheritance, or SCM_RIGHTS of that **same** old file description does not revive it. A fresh `open` is a different cohort: the driver allocates a new `usb_dev_state` and registers it without checking generic-versus-stub ownership or `authorized` at this point. Descriptor recipient checks matter later.

The original hypothesis is withdrawn only as stated above; this correction does not justify claiming generic unbind revokes every pre-admitted operation.

### What the blocking notification actually waits for

`destroy_async` removes a pending async request from its list, drops its spinlock, calls `usb_kill_urb`, then drops the URB reference. This is real cancellation/completion of those **tracked asynchronous URBs**, not merely a process-death observation. Completed async requests may still be reaped through the dedicated disconnected-allowed ioctl cases.

Synchronous `USBDEVFS_CONTROL` is different. In v5.15 it unlocks the device before calling `usb_control_msg`; in v6.8 it unlocks before `usbfs_start_wait_urb` submits/waits for a locally allocated URB. Neither path adds that URB to `ps->async_pending`. The unconfiguration path skips ep0. It follows that synchronous notify completion is not a proof that every previously checked synchronous control ioctl has returned, or that none can submit afterward. A submitted request may finish later; a thread scheduled after the unlock but before submit can resume after notify. The subsequent next ioctl from that invalidated file description should fail; the already admitted call is a distinct operation. No return-code set is invented for this unexecuted adversarial schedule.

### Open racing permission closure and notification

The relevant ordered steps in `namei.c`/`open.c` are permission checking, `vfs_open`, security-file-open, then the device's open method. Inside `usbdev_open`, device lookup precedes taking the USB device lock, and registration happens after it. No second DAC/ACL check is performed immediately before list insertion.

An admissible schedule is: task A passes old node permissions; administrator closes mode/ACL and starts generic unbind; A has not yet registered; unbind holds the device lock and clears currently registered states; A later acquires the lock and registers a new state. For same-generation logical unbind, NOTATTACHED does not exclude A. Closing node permissions prevents fresh permission checks from succeeding, but does not retroactively fail one that already succeeded. No bounded sleep or `/proc/*/fd` scan proves the absence of such an in-flight open.

A controlled fixture that deliberately owns all relevant processes can stop admitting opens and actually wait for those processes/operations; that proves its controlled process set, not a general-purpose live-host guarantee. Arrival denial from before creation avoids having an earlier permission-granted untrusted cohort in the stated trusted environment.

## Exact first probe and expected results

Use a true control ioctl, not `read(fd, ...)`, which accesses cached descriptors. The safe first request is a standard IN DEVICE GET_DESCRIPTOR, wValue `0x0100`, wIndex 0, length 18, timeout 2000 ms. It does not reset the device, choose a configuration, claim an interface, or issue a SCSI command.

```c
unsigned char data[18] = {0};
struct usbdevfs_ctrltransfer q = {
    .bRequestType = USB_DIR_IN | USB_TYPE_STANDARD | USB_RECIP_DEVICE,
    .bRequest = USB_REQ_GET_DESCRIPTOR,
    .wValue = USB_DT_DEVICE << 8,
    .wIndex = 0, .wLength = sizeof data, .timeout = 2000, .data = data
};
errno = 0;
int result = ioctl(fd, USBDEVFS_CONTROL, &q);
int saved_errno = result < 0 ? errno : 0;
```

The fixture should reject unexpected returns instead of accepting a broad transport-error class. On expected success require result 18, descriptor length 18, descriptor type 1, and the fixture's expected VID/PID. A syscall return of -1 and the listed errno is the userspace failure form.

| Stage, same pinned USB generation and idle normal QEMU device | RW FD expectation | RO FD expectation | Meaning |
| --- | --- | --- | --- |
| Root opens before generic unbind, then delegates after dropping identity/caps | GET_DESCRIPTOR result 18 | `EPERM` 1 | Initial working cohort |
| Same FDs after canonical node chmod/ACL closure | 18 | 1 | Mode change does not recheck existing file mode |
| Same registered FDs after stock `usbip bind` completed | `ENODEV` 19 | 1 | Generic unbind invalidated registered pre-bind cohort |
| Root freshly opens while `usbip-host` is bound, delegates, then closes root copies | 18 | 1 | Post-bind cohort is independent |
| Post-bind FDs after mode/ACL closure | 18 | 1 | Root-open delegation cannot be revoked by chmod |
| Post-bind FDs after device `authorized=0`, stable state ADDRESS/configuration 0 | 18 | 1 | Device deauthorization is not generic disconnect |
| Post-bind FDs after successful same-generation reset, normal stable ADDRESS/CONFIGURED | 18, conditional on no disconnect/re-enumeration | 1 | Reset is not inherently list invalidation; exclude from minimum non-destructive probe |
| Post-bind FDs after idle stock `usbip unbind`, same generation, generic rebound, authorization/interface policy still blocks local drivers | Expected 18; verify as a separate experiment | 1 | Stub disconnect does not itself issue USBFS removal notification |
| Same writable FD after actual disconnect/physical generation loss | `ENODEV` 19 | 1 | Do not reopen and call it the same FD/generation |
| Fresh ordinary-user `open(O_RDWR)` after root0600 and no granting ACL | `open` fails `EACCES` 13 | N/A | Only this new open is denied |
| Fresh ordinary-user `open(O_RDONLY)` under same root0600 closure | N/A | `open` fails `EACCES` 13 | Both modes denied by DAC |
| Fresh ordinary-user RO open under stock root:root0664, no restrictive LSM/cgroup | N/A | open succeeds; ioctl `EPERM` 1 | Readable device node is not writable USBFS control |

These precise predictions assume the fixture's normal upstream-compatible behavior and no independent enforcing LSM or device cgroup rejection. If an additional policy rejects at an earlier layer, record it as a different cause; do not broaden expectedcodes to hide it. The actual Ubuntu downstream kernels must be observed.

`usbfs_fd_probe.c` supplies an exact, deliberately uncompiled guest-only specimen for `delegate` and `fresh` modes. In delegate mode the child closes inherited originals, drops real/effective/saved UID/GID, supplementary groups and all capability sets, sets no-new-privileges, and receives RW/RO FDs via SCM_RIGHTS. The root closes its copies before the child emits READY. Each `g STAGE` command logs the same child's FDs and executes only GET_DESCRIPTOR. `q` closes both; the root reports an actual waitpid result. There is no raw RESET/SET_CONFIGURATION operation in the specimen. Parent may adapt it to its existing fixture; compilation and real guest results belong to the parent, not this review.

### Required evidence around the probes

Record the selected QMP device identity/backing filenames, both guest boot IDs, dedicated PCI BDF/controller ancestry, both root hubs, USB sysfs path/inode, busnum/devnum, authorized/config/interface state, current driver and absence of target SCSI/block descendants. Record the node's `stat` device/inode/rdev/mode/owner, effective numeric ACL, actual UID/GID/groups/capabilities, actual process PID/start time and FDs. Recheck these before and after each planned lifecycle step. Bus ID, VID/PID and serial alone are not durable identity or authorization.

The harness should retain an opened sysfs directory/known generation receipt and compare current topology to it, not treat a newly resolved same-name path as the old device. Capture original child exit/wait and original FD close, not a replacement process's zero resources. For SCM_RIGHTS, include that the receiver is already unprivileged and root originals closed before its ioctl. An inherited descriptor after dropping IDs is also a useful separately labelled test, but is not an SCM_RIGHTS transfer.

Do not mount or perform bulk storage requests for this raw-access experiment. Use E66's new ordinary-file disks if the broader fixture still needs a mass-storage device; all USBFS probes here are device-descriptor reads.

## Deauthorization, reset, and stock unbind

`usb_deauthorize_device` takes the device lock, sets `authorized=0`, and calls `usb_set_configuration(...,-1)`. It does not call generic disconnect or the USBFS removal notifier. Its purpose is interface/configuration denial, not a raw-control ACL. `check_ctrlrecip` admits UNAUTHENTICATED, ADDRESS, and CONFIGURED; the device-recipient request takes no interface-claim path. `usb_submit_urb` likewise admits control transfers before CONFIGURED. This explains why a prior interface-claim ENODEV does not settle the DEVICE request.

The writable USBFS API also contains RESET and SET_CONFIGURATION paths. They have operation-specific restrictions, such as existing interface claims and dropped-privilege masks; they do not simply require the caller currently be root. `USBDEVFS_DROP_PRIVILEGES` is not a universal revocation mechanism for all device-recipient controls. A benign successful GET_DESCRIPTOR proves retained control access, not that every dangerous control will succeed. Avoid performing reset/reconfiguration merely to prove the first fact.

`stub_driver` in `drivers/usb/usbip/stub_dev.c:527` has no `generic_subclass` flag. Thus its disconnect callback releases the port and shuts down USB/IP state without automatically executing generic disconnect. Stock `usbip unbind` then removes match_busid and explicitly requests rebind (`tools/usb/usbip/src/usbip_unbind.c:61–86`); `stub_main.c:199` calls `device_attach`. Generic re-probe can configure the device and publish interfaces when authorized. Keeping interfaces denied is necessary for an idle mechanism test; stock unbind is **not** proposed as the product's safe release policy. Preserve E66's retain-stub/no-auto-reimport recovery boundary.

## Node birth, Ubuntu rules, and ACLs

The Linux USB devnode callback (`drivers/usb/core/usb.c:585` in v6.8) supplies the path but no mode/UID/GID override. `devtmpfs_create_node` starts with root UID/GID and falls back to 0600. Core device creation calls devtmpfs node creation before the ADD uevent (`drivers/base/core.c:3613,3620`). This describes a newly created kernel node; a preexisting conflicting inode, an alternate node, or a different `/dev` setup is not covered merely by citing this default.

The official extracted Ubuntu base packages differ from that birth state:

| Saved Ubuntu file | Relevant behavior |
| --- | --- |
| `ubuntu/jammy-base/lib/udev/rules.d/50-udev-default.rules:50` | USB device MODE 0664 |
| `ubuntu/noble-base/usr/lib/udev/rules.d/50-udev-default.rules:69` | Same |
| both `70-uaccess.rules` | Category-based tags, including camera/scanner/security-token/media categories; does not universally tag all mass storage |
| both `73-seat-late.rules:16` | Current `uaccess` tag queues the uaccess builtin |

The permission/ACL chain is significant:

- Udev final assignment for owner/group/mode is implemented in v249 `udev-rules.c:1929–1999`, v255 `2376–2463`.
- Rule processing computes final node permissions before the worker executes its RUN list (v249 `udevd.c:489,499`; v255 `udev-worker.c:198,208`, `udev-event.c:390`). Consequently, a later uaccess RUN can grant ACL access after final mode application.
- Uaccess selects the active seat user, then calls `devnode_acl`. That code grants read/write and recalculates the ACL mask (v249 `devnode-acl.c:131,143`; v255 `119,129`). `MODE:=0600` does not make that ACL grant impossible.
- `TAG-="uaccess"` before stock 73 prevents stock RUN enqueue. A tag removal after enqueue does not remove an already queued RUN. `TAG:=` is not a supported final tag assignment: v255's parser explicitly treats it as ordinary assignment.
- Tag removal changes the current tag set. Existing historical all-tags entries may remain, but both reviewed logind ACL enumeration paths check `sd_device_has_current_tag` before adding ACLs. Removing a tag is still not the same operation as removing an ACL already present on the inode.

[Versioned udev manual](https://www.freedesktop.org/software/systemd/man/249/udev.html) describes lexical rule ordering and final assignments. [Pinned uaccess implementation](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/udev/udev-builtin-uaccess.c) and [ACL implementation](https://github.com/systemd/systemd/blob/db11bab38ccf1ed257f310d29070843d4c58ea01/src/shared/devnode-acl.c) supply the actual execution semantics.

### Narrow candidate guest policy

Install before creating the fixture device, and include it in the boot/initramfs policy wherever USB can appear before the real root's rules are loaded. Substitute the exact dedicated controller BDF; do not apply the example to arbitrary host USB.

```udev
# 00-rustusb-enrollment.rules
ACTION!="remove", SUBSYSTEM=="usb", ENV{DEVTYPE}=="usb_device", KERNELS=="0000:00:07.0", OWNER:="root", GROUP:="root", MODE:="0600"

# 72-rustusb-enrollment.rules
ACTION!="remove", SUBSYSTEM=="usb", ENV{DEVTYPE}=="usb_device", KERNELS=="0000:00:07.0", TAG-="uaccess"
```

This is a **candidate for a controlled ruleset**, not a standalone universal enrollment policy. `KERNELS` matches ancestors; verify the actual PCI ancestry for both root hubs. Scope must survive the chosen platform's boot topology or fail closed on mismatch. All parent-match keys in a rule must refer to the same parent; avoid combining a PCI BDF with a different USB parent's attributes in one rule.

Audit every effective rule directory and precedence override, including `/etc`, `/run`, `/usr/local/lib`, and `/usr/lib` or the distro's `/lib` alias. A rule between 70 and 72 can invoke `IMPORT{builtin}="uaccess"` immediately; another rule can queue a builtin or arbitrary helper directly, re-add tags, or adjust ACLs independently. Those actions can create a transient grant despite later mode/tag observations. Existing udev workers may still be processing an older rule snapshot. A rules reload plus current-node snapshot does not establish that there was never a grant.

For a fresh known generation with no existing ACL, these stock-rule overrides can maintain root-only canonical-node access under the stated trusted ruleset. For an existing node, explicitly inspect/remove any named ACL as a guest experiment and label it as closing future opens; it does not revoke already open descriptions or retroactively close the races above. Do not infer “no ACL” from octal mode alone.

The actual guest evidence should include package versions, SHA-256 of all effective rules and relevant installed binaries/package manifests, `udevadm info` properties/current tags, numeric `getfacl` output, logind/seat state, udev-event completion, and repeated exact nonroot open attempts. `udevadm test` explains a ruleset; actual node/ACL and real syscalls remain the test outcome. Perform such commands only inside the authorized disposable guests. A headless guest with no active seat may not exercise the ACL-grant case; use a controlled rule/tag/seat negative if claiming that path was tested.

## Durable enrollment boundary

A narrow proposed enrollment receipt can legitimately say that the **controlled policy** admitted no delegated writable USBFS FD for a known new generation only when its history is established, not inferred from the current FD census. Required premises are:

- The OS starts from a trusted boot profile; privileged services and administrators are trusted not to create alternate raw nodes, pass writable FDs, change ACLs, or enable unintended local driver/probe paths.
- Device denial is in force before this device generation can appear. `usbcore.authorized_default=0` initializes new HCD device policy; setting only the existing root-hub sysfs value is volatile. Interface denial must be set and checked before authorizing the selected device.
- Canonical devtmpfs root0600 birth and the entire udev/ACL/seat policy maintain no untrusted write grant, including initramfs/early boot and ruleset updates. On policy uncertainty or topology mismatch, do not enroll a new generation.
- Ordinary principals have no accessible alternate character-device node for the same rdev, no device-node-creation bypass, and no allowed privileged FD broker. USBFS looks up devices by inode rdev, not by canonical pathname. A char189 alias in another mount namespace is a separate opening path.
- Every privileged open during enrollment is deliberately owned and actually closed/retired or retained by the authorized owner; no successful FD delegation is hidden behind process-death or unrelated new-owner evidence.
- Enrollment is scoped to boot/controller/device generation and policy identity. HCD recreation, device removal, lost policy continuity, or an unverified startup rejects continuity until a new controlled enrollment is established.

The implementation can report these premises and its evidence explicitly. It cannot turn them into protection against a malicious root who can modify the kernel/policy. A `/proc` scan may expose a known conflict, but cannot prove the absence of in-flight opens, pending SCM_RIGHTS, all namespaces, inherited hidden references, or future privileged delegation.

### Boot and HCD fixture

In v6.8 `hcd.c:2821`, every `usb_add_hcd` copies the module parameter into the new HCD device policy. The function also sets interface-authorized by default at `2840`. `sysfs.c:917` changes only the current HCD policy. Source-equivalent behavior exists in v5.15. Therefore compare:

1. Runtime-only root-hub device default0, then an authorized guest-only unbind/rebind of the dedicated test HCD: newly created hubs should return to the parameter default1 unless the parameter was also changed.
2. Actual guest reboot with recorded kernel command line `usbcore.authorized_default=0`: new HCD/root hubs should inherit device default0. Both USB2/USB3 logical root hubs must be observed.
3. A fresh target born under device default0 initially has no active config/local BOT/UAS binding. Interface default initially1 is expected until explicitly set0. Set/check interface default0 before authorizing exactly the selected generation for Native use.

A global USB boot-denial setting affects the guest's other USB input devices; use serial/network console and only the disposable guest, not the host. This is a validation fixture, not a recommendation to silently alter a user's production boot policy. Boot results do not show cache durability or that a late live handoff is solved.

## Existing enforcement choices, kept narrow

| Existing mechanism | Useful boundary | Limits relevant to E67 |
| --- | --- | --- |
| Root0600 + controlled udev/ACL policy from birth | New canonical-node opens by ordinary users; simplest dedicated-appliance baseline | Existing FDs, old permission-checked opens, alternate raw nodes, privileged delegation, unexpected early rules remain separate |
| Device cgroup v1 or cgroup-BPF v2; systemd DevicePolicy/DeviceAllow | New opens and mknod checked by device type/major/minor, covering path aliases for confined processes | Does not recheck USBFS ioctl on an already held file description or provide an SCM_RIGHTS receive policy; every relevant process must be in scope; major/minor reuse is not durable controller identity |
| Existing enforcing SELinux policy | VFS per-ioctl and file-receive hooks can deny use/receipt even when DAC alone would allow it | Requires correctly deployed labels/domain policy, current credentials, audited USB ioctl access, and tests; does not cancel an ioctl already admitted or solve storage flush ownership |
| Existing AppArmor policy | File opening and SCM_RIGHTS receive checks can narrow a known service's delegation surface | Reviewed v5.15/v6.8 AppArmor registers file_receive/file_permission but no file_ioctl hook; do not assert generic held-USBFS-ioctl revocation merely because AppArmor is installed |
| Custom BPF-LSM or kernel change | Could introduce a purpose-built admission/revocation boundary | New substantial product/security component; not needed to run this fixture and not proposed as an already completed or mature plug-in solution |

Linux `fs/namei.c` calls `devcgroup_inode_permission`; `include/linux/device_cgroup.h` maps MAY_READ/MAY_WRITE to the rdev policy. `security/device_cgroup.c:860` invokes cgroup BPF then the legacy device controller. `fs/ioctl.c:865` instead calls the LSM ioctl hook before invoking the file operation. SELinux's `hooks.c:3696` checks current credentials and ioctl permission; `3954` checks received files. AppArmor `lsm.c:538` handles file_receive. None of these source facts proves a guest's active policy without runtime evidence.

Systemd v249/v255 already exposes DevicePolicy/DeviceAllow. [Versioned resource-control manual](https://www.freedesktop.org/software/systemd/man/255/systemd.resource-control.html) describes eBPF device filtering. Its selector is a device path or device group, ultimately device-number based; it does not provide an immutable per-USB-controller enrollment identity. Prefer existing administrator deployment when present. Do not add a host-wide cgroup/LSM framework merely to replace the controlled-guest permissions experiment.

## Minimum effective guest matrix and reporting limits

Run both kernels as the source role if claiming coverage of both Ubuntu versions. Use the parent fixture's two full guests and new ordinary-file QEMU storage; this agent did not execute these rows.

| Row | Required action/evidence | Expected judgment |
| --- | --- | --- |
| A | Pre-generic-unbind delegated RW/RO FDs; same child before chmod, after chmod, after stock bind | RW 18 → 18 → ENODEV19; RO EPERM1 throughout |
| B | Newly opened post-stub delegated RW/RO FDs; same child after chmod and device deauthorize | RW18 in stable ADDRESS; RO1; source remains stub/no local block |
| C | Fresh nonroot RW and RO opens after effective root0600/no granting ACL; actual ioctl on stock-readable RO node as separate control | EACCES13 for both closed-policy opens; stock RO ioctl1 |
| D | Scoped udev final-mode/tag rules installed before new device birth, deliberately known stock/category ACL conditions, actual resulting ACL/current tags and fresh opens | Specific rule-policy behavior, no broad claim from headless/no-seat absence |
| E | Runtime root-hub default0 versus new HCD; real boot0 versus fresh HCD; both hubs | Demonstrates volatile policy loss and separately persistent boot parameter behavior |
| F, optional | Post-bind cohort through idle stock unbind with interface denial retained and no local block | Observe expected RW18/RO1 separately; never call this product release support |
| G, optional | Physical device removal with original cohort retained | Same RW FD19; RO1; no reopen/substitution |

Do not classify races as passed simply because sequential rows pass. The open race and already-admitted synchronous-control race need controlled instrumentation for direct reproduction; this review supplies the source schedule and the resulting claim limit. Do not add destructive control requests to the minimum matrix. If later reproducing them, use disposable idle disks, one deliberately held operation, exact syscall/notification markers, and retain every unexpected outcome.

Even a complete pass of this matrix establishes only the specified USBFS access/policy lifecycle in these emulated environments. It does not grant product storage export, establish old block-cache drain, prove every holder absent, guarantee persistence after a flush error, revoke all old capabilities on an uncontrolled live host, or satisfy hardware/whole-phase acceptance.

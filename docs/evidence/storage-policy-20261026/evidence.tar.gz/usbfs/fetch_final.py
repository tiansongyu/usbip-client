import pathlib,urllib.request,json,hashlib,datetime,concurrent.futures
r=pathlib.Path('/tmp/rustusb-storage-policy-usbfs-20261026');jobs=[]
for ver,sha in [('v5.15','8bb7eca972ad531c9b149c0a51ab43a417385813'),('v6.8','e8f897f4afef0031fe618a8e94127a0934896aba')]:
 for p in ['drivers/usb/core/notify.c','kernel/notifier.c']:
  jobs.append((f'linux-{ver}/{p}',f'https://raw.githubusercontent.com/torvalds/linux/{sha}/{p}'))
for ver in ['v249','v255']:
 sha=json.loads((r/f'metadata/systemd-{ver}.json').read_text())['sha']
 for p in ['src/shared/devnode-acl.c','src/udev/udev-worker.c','src/udev/udevd.c','src/udev/udev-rules.c','man/udev.xml']:
  if not (r/f'systemd-{ver}/{p}').exists():jobs.append((f'systemd-{ver}/{p}',f'https://raw.githubusercontent.com/systemd/systemd/{sha}/{p}'))
 if ver=='v249':
  for p in ['rules.d/70-uaccess.rules.m4','rules.d/73-seat-late.rules.in']:
   jobs.append((f'systemd-{ver}/{p}',f'https://raw.githubusercontent.com/systemd/systemd/{sha}/{p}'))
for name,url in [('udev249.html','https://www.freedesktop.org/software/systemd/man/249/udev.html'),('resource-control255.html','https://www.freedesktop.org/software/systemd/man/255/systemd.resource-control.html')]:jobs.append(('official-docs/'+name,url))
def get(pair):
 p,u=pair
 try:
  b=urllib.request.urlopen(u,timeout=45).read();d=r/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
  return {'path':p,'url':u,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'fetched_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ok'}
 except Exception as e:return {'path':p,'url':u,'status':'error','error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:a=list(p.map(get,jobs))
(r/'sources-final.json').write_text(json.dumps(a,indent=2)+'\n')
for x in a:
 if x['status']!='ok':print(x['path'],x['error'])
print('downloaded',sum(x['status']=='ok' for x in a),'of',len(a))

/* SPDX-License-Identifier: MIT
 * E67 guest-only source specimen. NOT compiled or executed by research agent.
 * Commands: delegate NODE UID GID; fresh NODE ro|rw UID GID.
 * delegate opens RW+RO as root, passes them by SCM_RIGHTS AFTER child drops all
 * IDs/groups/capabilities, then closes root copies before child reports READY.
 * Child stdin: "g STAGE\n" performs DEVICE GET_DESCRIPTOR on both held FDs;
 * "q\n" closes them. No RESET, SET_CONFIGURATION, bulk or storage requests.
 * Caller must pin this disposable guest USB generation independently.
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <grp.h>
#include <inttypes.h>
#include <linux/capability.h>
#include <linux/usb/ch9.h>
#include <linux/usbdevice_fs.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/sysmacros.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static void die(const char *s) { perror(s); exit(2); }
static unsigned long number(const char *s) {
    char *e; errno = 0; unsigned long n = strtoul(s, &e, 10);
    if (errno || !*s || *e || n == 0 || n >= 4294967295UL) {
        fprintf(stderr, "invalid nonroot identity\n"); exit(2);
    }
    return n;
}
static void stamp(const char *stage, const char *kind, int fd) {
    struct stat st; struct timespec ts;
    if (fstat(fd, &st) || clock_gettime(CLOCK_MONOTONIC, &ts)) die("identity");
    int flags = fcntl(fd, F_GETFL); if (flags < 0) die("F_GETFL");
    printf("{\"event\":\"fd\",\"stage\":\"%s\",\"kind\":\"%s\",\"pid\":%ld,\"uid\":%lu,\"euid\":%lu,\"gid\":%lu,\"fd\":%d,\"flags\":%d,\"inode\":%ju,\"dev\":%ju,\"major\":%u,\"minor\":%u,\"mode\":%u,\"node_uid\":%lu,\"node_gid\":%lu,\"mono_sec\":%jd,\"mono_nsec\":%ld}\n",
        stage,kind,(long)getpid(),(unsigned long)getuid(),(unsigned long)geteuid(),
        (unsigned long)getgid(),fd,flags,(uintmax_t)st.st_ino,(uintmax_t)st.st_dev,
        major(st.st_rdev),minor(st.st_rdev),(unsigned)(st.st_mode & 07777),
        (unsigned long)st.st_uid,(unsigned long)st.st_gid,(intmax_t)ts.tv_sec,ts.tv_nsec);
    if (!S_ISCHR(st.st_mode) || major(st.st_rdev) != 189) {
        fprintf(stderr,"not USBFS character device\n"); exit(2);
    }
}
static void drop(uid_t uid, gid_t gid) {
    struct __user_cap_header_struct h={.version=_LINUX_CAPABILITY_VERSION_3,.pid=0};
    struct __user_cap_data_struct z[2]={{0},{0}}, got[2]={{0},{0}};
    if (setgroups(0,NULL) || setresgid(gid,gid,gid) || setresuid(uid,uid,uid)) die("drop ids");
    if (syscall(SYS_capset,&h,z) || prctl(PR_SET_NO_NEW_PRIVS,1,0,0,0)) die("drop caps");
    if (syscall(SYS_capget,&h,got)) die("capget");
    uid_t a,b,c; gid_t d,e,f;
    if (getresuid(&a,&b,&c) || getresgid(&d,&e,&f)) die("getresids");
    int groups=getgroups(0,NULL); if (groups<0) die("getgroups");
    if (a!=uid || b!=uid || c!=uid || d!=gid || e!=gid || f!=gid || groups!=0 ||
        got[0].effective || got[1].effective || got[0].permitted || got[1].permitted ||
        got[0].inheritable || got[1].inheritable) {
        fprintf(stderr,"privilege closure failed\n"); exit(2);
    }
    printf("{\"event\":\"dropped\",\"pid\":%ld,\"uid\":%lu,\"gid\":%lu,\"groups\":0,\"cap_eff\":0,\"cap_prm\":0,\"cap_inh\":0,\"no_new_privs\":1}\n",
        (long)getpid(),(unsigned long)uid,(unsigned long)gid);
}
static void descriptor(int fd, const char *kind, const char *stage) {
    unsigned char data[18]={0};
    struct usbdevfs_ctrltransfer q={.bRequestType=USB_DIR_IN|USB_TYPE_STANDARD|USB_RECIP_DEVICE,
        .bRequest=USB_REQ_GET_DESCRIPTOR,.wValue=USB_DT_DEVICE<<8,.wIndex=0,
        .wLength=sizeof data,.timeout=2000,.data=data};
    stamp(stage,kind,fd); errno=0; int r=ioctl(fd,USBDEVFS_CONTROL,&q); int e=r<0?errno:0;
    printf("{\"event\":\"get_descriptor\",\"stage\":\"%s\",\"kind\":\"%s\",\"pid\":%ld,\"result\":%d,\"errno\":%d,\"length\":%u,\"type\":%u,\"vid\":%u,\"pid_usb\":%u}\n",
        stage,kind,(long)getpid(),r,e,data[0],data[1],(unsigned)data[8]|((unsigned)data[9]<<8),
        (unsigned)data[10]|((unsigned)data[11]<<8));
}
static void close_report(int fd, const char *kind) {
    errno=0; int r=close(fd); int e=r<0?errno:0;
    printf("{\"event\":\"closed\",\"pid\":%ld,\"kind\":\"%s\",\"fd\":%d,\"result\":%d,\"errno\":%d}\n",(long)getpid(),kind,fd,r,e);
    if(r) exit(2);
}
static int open_node(const char *node, int mode) {
    if(strncmp(node,"/dev/bus/usb/",13)!=0) { fprintf(stderr,"bad node prefix\n");exit(2); }
    return open(node,mode|O_CLOEXEC|O_NOFOLLOW);
}
int main(int argc,char **argv) {
    setvbuf(stdout,NULL,_IONBF,0);
    bool delegate=argc==5 && !strcmp(argv[1],"delegate");
    bool fresh=argc==6 && !strcmp(argv[1],"fresh") && (!strcmp(argv[3],"ro")||!strcmp(argv[3],"rw"));
    if(!delegate&&!fresh) {fprintf(stderr,"usage: %s delegate NODE UID GID | fresh NODE ro|rw UID GID\n",argv[0]);return 2;}
    uid_t uid=(uid_t)number(argv[fresh?4:3]); gid_t gid=(gid_t)number(argv[fresh?5:4]);
    if(geteuid()!=0) {fprintf(stderr,"launcher must be guest root\n");return 2;}
    int sv[2], fds[2]={-1,-1}; if(socketpair(AF_UNIX,SOCK_SEQPACKET|SOCK_CLOEXEC,0,sv))die("socketpair");
    if(delegate) {
        fds[0]=open_node(argv[2],O_RDWR);if(fds[0]<0)die("root open rw");
        fds[1]=open_node(argv[2],O_RDONLY);if(fds[1]<0)die("root open ro");
        stamp("root_open","rw",fds[0]);stamp("root_open","ro",fds[1]);
    }
    pid_t child=fork();if(child<0)die("fork");
    if(child==0) {
        if(close(sv[0]))die("child close sv");
        if(delegate) {if(close(fds[0])||close(fds[1]))die("close inherited originals");}
        drop(uid,gid);
        if(fresh) {
            const char *kind=argv[3];errno=0;int fd=open_node(argv[2],!strcmp(kind,"rw")?O_RDWR:O_RDONLY);int e=fd<0?errno:0;
            printf("{\"event\":\"fresh_open\",\"kind\":\"%s\",\"pid\":%ld,\"result\":%d,\"errno\":%d}\n",kind,(long)getpid(),fd,e);
            if(fd>=0) {descriptor(fd,kind,"fresh");close_report(fd,kind);}
            if(close(sv[1]))die("fresh close sv");return 0;
        }
        if(send(sv[1],"R",1,MSG_NOSIGNAL)!=1)die("ready");
        char byte; struct iovec iov={.iov_base=&byte,.iov_len=1};
        union {struct cmsghdr align;unsigned char b[CMSG_SPACE(sizeof fds)];} control={0};
        struct msghdr m={.msg_iov=&iov,.msg_iovlen=1,.msg_control=control.b,.msg_controllen=sizeof control.b};
        if(recvmsg(sv[1],&m,MSG_CMSG_CLOEXEC)!=1 || (m.msg_flags&(MSG_CTRUNC|MSG_TRUNC)))die("recvmsg");
        struct cmsghdr *c=CMSG_FIRSTHDR(&m);
        if(!c||c->cmsg_level!=SOL_SOCKET||c->cmsg_type!=SCM_RIGHTS||c->cmsg_len!=CMSG_LEN(sizeof fds)||CMSG_NXTHDR(&m,c)) {fprintf(stderr,"bad rights\n");return 2;}
        memcpy(fds,CMSG_DATA(c),sizeof fds);
        if(recv(sv[1],&byte,1,0)!=1||byte!='C')die("root closed barrier");
        if(close(sv[1]))die("child close channel");
        stamp("held","rw",fds[0]);stamp("held","ro",fds[1]);
        puts("{\"event\":\"READY\"}");
        char line[128];while(fgets(line,sizeof line,stdin)) {
            if(!strcmp(line,"q\n"))break;
            char stage[100],extra;
            if(sscanf(line,"g %99s %c",stage,&extra)!=1||strspn(stage,"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-")!=strlen(stage)) {
                fprintf(stderr,"bad command\n");return 2;
            }
            descriptor(fds[0],"rw",stage);descriptor(fds[1],"ro",stage);
        }
        close_report(fds[0],"rw");close_report(fds[1],"ro");return 0;
    }
    if(close(sv[1]))die("parent close sv");
    if(delegate) {
        char byte;if(recv(sv[0],&byte,1,0)!=1||byte!='R')die("drop barrier");
        struct iovec iov={.iov_base=(void*)"F",.iov_len=1};
        union {struct cmsghdr align;unsigned char b[CMSG_SPACE(sizeof fds)];} control={0};
        struct msghdr m={.msg_iov=&iov,.msg_iovlen=1,.msg_control=control.b,.msg_controllen=sizeof control.b};
        struct cmsghdr *c=CMSG_FIRSTHDR(&m);c->cmsg_level=SOL_SOCKET;c->cmsg_type=SCM_RIGHTS;c->cmsg_len=CMSG_LEN(sizeof fds);memcpy(CMSG_DATA(c),fds,sizeof fds);
        if(sendmsg(sv[0],&m,MSG_NOSIGNAL)!=1)die("sendmsg");
        close_report(fds[0],"root_rw");close_report(fds[1],"root_ro");
        if(send(sv[0],"C",1,MSG_NOSIGNAL)!=1)die("closed barrier");
    }
    if(close(sv[0]))die("parent close channel");
    int status;pid_t w;do{w=waitpid(child,&status,0);}while(w<0&&errno==EINTR);if(w!=child)die("waitpid");
    printf("{\"event\":\"waitpid\",\"child\":%ld,\"raw_status\":%d,\"exited\":%s,\"exit_code\":%d,\"signal\":%d}\n",(long)child,status,WIFEXITED(status)?"true":"false",WIFEXITED(status)?WEXITSTATUS(status):-1,WIFSIGNALED(status)?WTERMSIG(status):0);
    return WIFEXITED(status)?WEXITSTATUS(status):2;
}

# E66: Linux USB arrival quarantine component research

Status: proposed mechanism, source-audited, not executed or product-supported. Date: 2026-10-26. Scope: Linux v5.15 `8bb7eca972ad531c9b149c0a51ab43a417385813`, v6.8 `e8f897f4afef0031fe618a8e94127a0934896aba`. No repository changes, host USB/modules/process/device inspection, builds or QEMU runs were performed. Only this `/tmp/rustusb-storage-arrival-linux-20261026` directory was written.

## Decision summary

**A viable candidate for real prevention of local BOT/UAS binding is pre-arrival, persistent interface authorization denial on a dedicated controller's USB buses, combined with default device denial and a restricted USBFS access lifecycle.** This is materially stronger than scanning for zero consumers. The relevant kernel paths check authorization before invoking an interface driver or permitting an interface claim.

Recommended first experimental envelope:

1. An explicitly reserved, initially empty, direct root-port controller. Include every logical root bus associated with that controller, including xHCI's USB2/USB3 buses. No external hub or unrelated device in the first experiment.
2. Before the target is physically/QMP connected, establish and retain both `authorized_default=0` and `interface_authorized_default=0`. Verify the actual HCD/bus generation and root-owned policy before connection; do not describe a later udev response as pre-arrival protection.
3. A fresh target generation starts with `device.authorized=0`. Prefer binding this still-unauthorized USB **device** to Native `usbip-host` first, then have trusted root/helper explicitly authorize that target device. No user receives a writable USBFS descriptor at any time from device creation onward.
4. Keep interface default denial for the initial and every remotely selected configuration. Explicit device authorization creates interfaces with authorized=0 while Native already owns the port. Native operates directly on URBs and does not need a local BOT/UAS interface driver. Authorizing the device before Native bind is also covered by the interface gate in the source, but is not the selected first fixture order.
5. Retain bus defaults through helper/usbipd crashes, disconnect and Native unbind/module cleanup. Restore local interface authorization only during an explicit, separately validated release workflow after peer storage quiescence; do not use automatic rollback-to-1 on error or process exit.

This candidate can prevent local class drivers within that envelope. It does **not** revoke writable USBFS FDs, defend against trusted-host root changing policy, survive arbitrary HCD recreation with runtime sysfs values alone, prove media durability, or by itself complete actual safe storage sharing. Ordinary stock-kernel USBFS forwarding cannot claim an interface while it remains unauthorized; Native is the promising first backend.

## Source provenance

`manifest.json` records every source attempt, URL, exact commit, hash, byte length, licensing notice and reused-file provenance. GitHub raw returned HTTP 429 for 36 initial requests; those failures remain in the manifest. Twenty-four original files were recovered from the previously hashed E65 source bundles; remaining originals were retrieved from the kernel.googlesource.com mirror at the same exact commits. The web tool successfully opened the official v6.8 authorization documentation and fixed-commit GitHub driver/sysfs pages; it could not open the googlesource HTML paths, although the separate primary source retrieval of their base64 raw endpoints succeeded. No failure is relabeled as a successful fetch.

Kernel COPYING, GPL-2.0, Linux-syscall-note and license rules are included. Preserve per-file SPDX/copyright notices. Do not copy GPL implementation into MIT Rust code. `line-index.tsv` maps principal symbols to both versions. All line citations below refer to the archived originals. Ubuntu GA/HWE patches and configuration still require guest verification.

## Device and interface authorization are different gates

| Mechanism | v5.15 source | v6.8 source | Verified effect |
|---|---|---|---|
| New device authorization | `core/usb.c:582-601,720` | `core/usb.c:605-624,741` | Constructor samples HCD device policy. Root hub is always authorized. `NONE` denies new non-root devices; `INTERNAL` trusts port topology, not device identity. |
| HCD policy initialization | `core/hcd.c:2824-2847` | `core/hcd.c:2821-2840` | Device default derives from `usbcore.authorized_default`; interface-default bit is initially set to 1 unconditionally. |
| Runtime default stores | `core/sysfs.c:924-988` | `core/sysfs.c:917-981` | Change the HCD default fields; they do not retroactively change all existing devices/interfaces. |
| Generic USB configuration | `core/generic.c:242+` | `core/generic.c:242-265` | Generic probe does not configure an unauthorized device. For an authorized device it chooses a configuration. |
| Explicit device authorize | `core/hub.c:2631+` | `core/hub.c:2684-2719` | Sets device authorization and chooses/sets a configuration, which creates interfaces. |
| Configuration construction | `core/message.c:1957+,2072` | `core/message.c:1993+,2108` | Unauthorized devices are forced into configuration 0; each newly created interface samples the current HCD interface default. |
| Interface driver probe | `core/driver.c:318-341` | `core/driver.c:321-344` | Rejects owned devices, unauthorized devices and unauthorized interfaces **before** driver matching/probe proceeds. |
| Explicit interface claim | `core/driver.c:535-550` | `core/driver.c:538-553` | Rejects unauthorized interfaces even when a caller bypasses normal matching. This includes USBFS claims. |
| Per-interface authorize | `core/message.c:1788-1819` | `core/message.c:1785-1816` | Deauthorization force-unbinds an already bound interface. Authorization changes the bit but does not itself initiate probing. |

The official ABI states that an unauthorized interface cannot be probed or claimed (`Documentation/ABI/testing/sysfs-bus-usb:1-20`). It also requires a separate `drivers_probe` step after authorizing an interface, with all interfaces needed by a multi-interface driver authorized first. This is a real kernel binding gate, not an inference from empty sysfs.

Important limits:

- Interface denial leaves the USB device configured and its endpoint structures available. It is a **local interface-binding** restriction, not a universal USB command firewall.
- Device denial and default denial do not revoke open USBFS file descriptions. USBFS opening is still possible subject to node access policy; later commands have their own checks.
- Writing `interface_authorized_default=0` after the target interfaces already exist does not repair the pre-arrival guarantee. A current `authorized=0` state cannot prove an interface was never bound.
- Device default mode 2 (“internal”) is not appropriate for storage enrollment: it classifies the physical port connection type and is not an authenticated device identity.

Primary links: [official interface authorization ABI](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/Documentation/ABI/testing/sysfs-bus-usb#L1), [probe gate](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/driver.c#L321), [new interface default](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/message.c#L2108).

## Native usbip-host compatibility

`stub_probe()` is a `usb_device_driver` probe, not an interface-driver probe. In v5.15 `stub_dev.c:308-392` and v6.8 `310-394`, it checks the bus-ID table, rejects hubs and VHCI-attached devices, creates its state and claims the parent hub port. There is no requirement for an active configuration, an authorized interface or an already bound storage driver. `usb_probe_device()` (`core/driver.c:249+`) does not apply the interface authorization gate.

The Native bind utility first unbinds the current USB device driver and then binds usbip-host (`tools/usb/usbip/src/usbip_bind.c`, v6.8 `154-170`). Generic disconnect unconfigures the device (`core/generic.c:267-275`). This unconfigured state is expected: `tools/usb/usbip/libsrc/usbip_common.c:154-171` explicitly tolerates empty `bConfigurationValue`/`bNumInterfaces` because the client chooses the configuration after attaching.

Remote SET_CONFIGURATION is handled through `usb_set_configuration()` (`stub_rx.c:130-147`); newly created interfaces therefore inherit interface-default 0. Remote SET_INTERFACE uses the kernel endpoint/alternate-setting path. Native eventually calls `usb_submit_urb()` (`stub_rx.c` v6.8 `584-597`), whose general state/endpoint checks (`core/urb.c:368-409`) do not require an interface driver's claim or interface authorization bit. Thus **device authorized=1 + interface authorized=0** is source-compatible with Native transport. Actual USB enumeration, BOT read/write and release under this state must still be demonstrated.

Do not retain device authorized=0 as the claimed working transfer state: `usb_set_configuration()` forces configuration 0, leaving no normal host bulk endpoint state. Also, stub special-request interception is not a strict authorization wrapper: it still submits the original request afterward (`stub_rx.c:583-597`), and the SET_CONFIGURATION helper returns zero even after logging some setup errors. Only actual remote enumeration/data and observed source kernel state can establish useful behavior.

Once bound, the Native port owner gives a second local probe barrier: `usb_hub_claim_port()` (`hub.c` v6.8 `1994-2007`) sets a port owner; `usb_device_is_owned()` (`2039-2046`) is checked by interface probe. This is not a raw USBFS FD lock and should not replace persistent interface denial across cleanup or reconfiguration.

Native unbind and module exit can reattach the generic USB device driver (`stub_main.c:199-237,242-274,418`; unbind tool writes `rebind`). Keeping interface-default 0 means any configuration created by that generic reattachment still cannot bind BOT/UAS. An automatic cleanup path that restores default 1 would remove that guarantee.

Primary links: [stub probe](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/usbip/stub_dev.c#L310), [expected unconfigured export](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/tools/usb/usbip/libsrc/usbip_common.c#L154), [remote configuration](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/usbip/stub_rx.c#L130).

## USBFS descriptors and privilege boundaries

### What the code checks

`usbdev_open()` (v5.15 `core/devio.c:1010+`, v6.8 `1032-1086`) retains a USB device/state reference and checks connection/resume state. It does not deny open merely because `authorized` or the interface bits are zero, nor because Native owns the port.

`usbdev_do_ioctl()` (v5.15 `2494+`, v6.8 `2597-2643`) checks the **original file mode** for `FMODE_WRITE`, then connected state. It does not perform a general CAP_SYS_ADMIN check, re-evaluate current node permissions or enforce device/interface authorization globally. Consequently, a non-root process that previously received an unrestricted writable USBFS FD still has these command paths:

| Operation | Kernel path | Consequence while interfaces remain unauthorized |
|---|---|---|
| CLAIMINTERFACE / bulk requiring claim | `devio.c:779-850` → `driver.c:538-553` | New unauthorized claim fails. Interface-recipient control also normally goes through this check. |
| CONTROL, vendor/device recipient | `devio.c:878-939,1166-1180` | Vendor requests return early from recipient checks; device-recipient control has no interface claim gate. These can communicate with or disturb the device. |
| RESET | `devio.c:1499-1523` | Normally invokes `usb_reset_device`. “Privileges dropped” only restricts specified cases involving another claimed interface. It is not a universal reset ban. |
| SETCONFIGURATION | `devio.c:1543-1588` | Rejects already-claimed interfaces; otherwise resets the same configuration or creates another. Persistent default 0 protects new local bindings, but hardware/transport state can still change. |
| CONNECT | `devio.c:2316-2367` | Calls `device_attach`; authorization/ownership probe gates remain effective. Ioctl return alone is not proof of a binding; device_attach can return no binding. |
| DISCONNECT_CLAIM | `devio.c:2460-2492` | May release a driver first; final claim still rejects unauthorized interface. Not a safe storage handoff primitive. |
| Raw standard SET_CONFIGURATION via CONTROL | Recipient/URB path above | Can issue a wire request outside the dedicated kernel configuration ioctl. It must be treated as interference; do not claim host metadata always tracks arbitrary raw control traffic. |

`USBDEVFS_DROP_PRIVILEGES` is useful least-privilege support but is not revocation and does not remove all device-level control paths. Changing node permissions, writing authorized=0, or observing zero FD matches cannot prove all previously passed/duplicated/registered descriptors are gone.

### Supported actor model

- **Ordinary non-root without a writable USBFS FD:** pre-arrival node policy plus interface authorization can form the intended boundary. Upstream devtmpfs initially creates root-owned nodes with mode 0600 (`drivers/base/devtmpfs.c:114-134`), and USB's devnode callback does not override mode (`core/usb.c:585-593`). Actual udev rules, ACLs, group grants, containers and descriptor passing can broaden access; deployment must preserve no-write-access from creation, not chmod it away afterward. Read-only USBFS opens do not pass ioctl's write-mode gate.
- **Ordinary non-root with a previously granted writable USBFS FD:** excluded from an exclusive transfer guarantee. Interface denial still blocks a new local BOT/UAS binding, but the user can issue control/reset operations and affect Native transfer. A guest negative must demonstrate this boundary rather than claiming isolation based solely on the user's UID.
- **Trusted broker/helper:** allowed to retain narrowly controlled device capabilities. A helper crash must leave the quarantine policy in the kernel; surviving/restarted code must not automatically restore authorization or adopt old capabilities as a new generation.
- **External initial-namespace root able to write sysfs / alter device policy (including the requested CAP_SYS_ADMIN root scenario):** outside the defendable boundary. The authorization stores are governed by sysfs access permissions, not an owner-only immutable lease. Such root can set defaults or interface authorization to 1, trigger probes, grant USBFS access, replace services or recreate controllers. CAP_SYS_ADMIN alone in an unrelated restricted container does not magically grant write access to host sysfs; specify actual namespace/DAC/LSM authority.
- **Hostile USB firmware or arbitrary kernel code:** not solved by class descriptors or these authorization flags. The mechanism prevents selected host driver binding; it is not device authentication or a hardware write protector.

Primary links: [USBFS ioctl admission](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/devio.c#L2597), [control recipient exceptions](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/devio.c#L878), [initial devtmpfs mode](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/base/devtmpfs.c#L114).

## Reset, crash, replug and controller lifecycle

| Event | What can be inferred from the fixed sources | Required product boundary / experiment |
|---|---|---|
| Helper or usbipd process exits | HCD defaults and interface bits are kernel state, not scoped to that process. Native kernel driver/port ownership is also not equivalent to usbipd PID lifetime. | Keep defaults denied; do not auto-enable interfaces in finally/Drop/restart. Verify actual kernel owners separately from process death. |
| Native connection shutdown/reset | `stub_device_reset` calls USB reset, then marks status available/error (`stub_dev.c` v6.8 `212-241`). It does not set interface authorization to 1. | Observe no BOT/UAS binding during and after reset; no media-consistency claim from AVAILABLE. |
| Same configuration reset | `usb_reset_configuration` preserves interface objects and other usbcore state (`message.c` v6.8 `1665-1766`). | Existing zero authorization should remain zero; execute a negative with repeated RESETCONFIG/SETCONFIG-same. |
| USB device/port reset with unchanged descriptors | `usb_reset_and_verify_device` restores configuration/altsettings on existing objects (`hub.c` v6.8 `6052-6181`). Interface rebind goes through the original gate (`6216-6300`). | Prove old generation stayed pinned and no unauthorized interface was rebound. |
| Changed descriptors / failed restore | Reset invokes logical disconnect and returns ENODEV (`hub.c:6183-6187`). | Retire the original receipt; do not silently bless the newly enumerated device. Defaults must already deny that new generation. |
| Full SETCONFIGURATION / alternate config | New interfaces sample the current HCD default again. | Keep default 0 throughout; test nondefault configuration where fixture supports it. A one-time zero on old interface objects is insufficient. |
| Physical unplug/replug on same HCD | New device samples device default; interfaces subsequently sample interface default. | New generation begins unauthorized with both defaults held at 0. Never automatically inherit original session permission based on port/bus ID alone. |
| Native unbind or module unload | Driver releases port and may reattach generic device driver. Persistent interface default remains independent. | Verify generic reattach still creates only unauthorized interfaces and no local block child. |
| HCD remove/recreate / module reload / reboot | `usb_add_hcd` reinstalls interface default 1 and initializes device policy from the global module parameter (`hcd.c` v6.8 `2821-2840`). Runtime sysfs writes alone do not persist. | Either exclude this lifecycle from the supported runtime enrollment, or establish a separate earlier boot/controller-level default device-deny policy. A later udev event/monitor cannot close the interval before first probe. |

A dedicated test system could boot with `usbcore.authorized_default=0`, ensuring newly created HCDs start with device denial; the helper must still set interface default 0 before authorizing any device. This is a deployment option requiring explicit administrator scope because it affects USB devices broadly. It must not be silently introduced on an ordinary host. There is no corresponding audited interface-default boot parameter in these fixed sources; the HCD interface bit starts at 1.

Controller identity must encompass every associated HCD/root bus. A monitor detecting HCD replacement after the fact is useful for refusing further operations but does not retroactively prove that no local driver bound. If a guarantee across HCD destruction is required, runtime-only enrollment is insufficient.

External hubs add another issue: their hub interface is also subject to interface authorization, so blanket denial prevents downstream enumeration until that infrastructure is separately authorized. A first direct-root-port profile avoids claiming an unreviewed hub exception.

## Paths that are not sufficient

- **`match_busid` before arrival:** Native's device driver has neither id_table nor match callback (`stub_dev.c` v6.8 `527-537`). Generic competition checks `usb_driver_applicable()` (`driver.c:842-855`), which returns false in that case, while USB bus matching lets the driver's probe decide later (`858-879`). Thus a prepopulated match table does not prove generic configuration or a local storage probe cannot run first.
- **USB `driver_override`:** these fixed USB device/interface structs, sysfs attribute lists and USB matching code contain no USB driver_override implementation. This mechanism exists on other buses but is not an available USB-device guarantee here. This is a conclusion about the audited stock USB core, not an assertion about every out-of-tree distro addition.
- **udev deauthorize on target add:** asynchronous after the relevant kernel device/interface work; cannot prove first binding was prevented. A root-HCD default set before target addition is different.
- **O_EXCL plus scan:** covers cooperating block holders after local storage publication, not a pre-publication guard, and does not cover old raw/USBFS FDs.
- **Per-interface `authorized=0` only once:** later configuration creates new interface objects from the default; leaving the default at 1 loses the invariant.
- **Default interface denial alone with arbitrary USBFS writers:** prevents local BOT/UAS binding but leaves device-level control/reset interference.
- **Global class-driver blacklist/unload:** changes unrelated devices, can be reversed/reloaded, and does not constrain raw USBFS traffic. Not the proposed mechanism.
- **Restoring defaults on helper error:** removes the crash protection and can permit generic reattachment to create a local storage device before an explicit release.
- **Device authorized=0 as working export:** not established and normally prevents normal endpoint configuration. Keep device and interface authorization distinct.

## Mandatory guest-only experiments before accepting the candidate

These are planned cases, not results. Use synthetic disposable USB devices/images and an explicitly separate QEMU controller. Do not attach host storage. Capture policy before device_add, real target/HCD generation, kernel driver probe/bind observations, source block-child evidence, actual source/client processes, transport/Root receipts, data hashes and cleanup. An empty block scan is supporting evidence; the loaded driver positive control and admission-before-arrival ordering are essential.

1. **First-arrival fence:** establish both defaults 0 before QMP device_add. Observe device authorization 0, then explicitly authorize only the device. Interface stays 0; loaded BOT driver must not bind. Attempt explicit drivers_probe/class bind and USBFS claim; preserve actual return values and resulting state.
2. **Native positive:** from that state bind usbip-host; import into a second guest, require real client enumeration and small disposable write/read/flush cycle, while the source remains without a local storage driver/block device. The source's interfaces created by remote SETCONFIG remain unauthorized. This is the decisive proof that the guard permits actual storage transport.
3. **Positive control after explicit safe release:** in a separate controlled stage, authorize all required source interfaces and trigger drivers_probe. A source block device must then appear. This demonstrates the previous negative was not caused by missing BOT/UAS support.
4. **UAS independently:** repeat the binding gate with a UAS-capable fixture and installed UAS driver. Do not transfer BOT results to UAS without its own transport/streaming capability proof; Native UAS operational support is a separate measured question.
5. **Existing writable FD:** fixture root opens USBFS before device authorization and passes it to a non-root child. Show claim/interface operations fail under interface 0 while allowed device-level control and reset paths can still act. Product must not label this actor model isolated; do not rely on UID or chmod as revocation.
6. **Read-only and no-FD non-root controls:** verify read-only fd ioctl rejection, node permission/ACL denial of writable opens, and no local driver binding after non-root attempts. Record actual udev/ACL state from device creation, not only final chmod.
7. **SETCONFIG/RESET/CONNECT matrix:** same config, unconfigure/reconfigure, alternate config if supported, device reset, CONNECT and DISCONNECT_CLAIM. Require authorization remains 0 and no local class bind. Record that transport failure/interference can occur even while local binding remains fenced.
8. **Crash at each handoff boundary:** before device authorization; after authorization but before Native bind; after bind before import; during import. Kill only owned guest helper/daemon processes. Policy must remain 0 and restart must refuse silent adoption/auto-enable. Actual USB/transport cleanup is separately checked.
9. **Native unbind/module cleanup:** exercise supported guest unbind and module lifecycle after owned consumers stop; generic reattach must not create a local block device while defaults remain 0.
10. **Replug and descriptor change:** remove/readd on the same port, including changed synthetic identity. New target starts unauthorized and does not inherit the original grant. Test USB2/USB3 companion buses where available.
11. **HCD recreation negative:** show that a newly created controller/HCD resets interface default to 1 under normal boot defaults. The harness must declare the old enrollment invalid; it must not claim a runtime monitor prevents the already-open interval. Separately test an explicitly authorized default-deny boot environment if that is chosen for a stronger envelope.
12. **External root negative:** root changes interface/default authorization and probes it, demonstrating that host-administrator mutation is outside the boundary. Preserve this as an expected policy-bypass capability, not a product test “pass” for adversarial-root isolation.
13. **Missing/oversize/failed policy stores:** actual write/readback errors or HCD identity changes must leave enrollment unconfirmed; no target authorization, Native bind or automatic default restoration. Blocking sysfs writes remain actual owned tasks; a timeout cannot assert they were canceled.

## Adoption recommendation and remaining questions

Adopt the combination as a **proposed Native arrival-quarantine mechanism for a narrow, pre-enrolled fresh-device lifecycle**, then run the decisive Native storage positive and the negatives above. Do not yet enable general storage export, label arbitrary previously attached devices safe, or claim hardware/crash/media-durability acceptance.

The design still needs to choose:

- Stable-HCD runtime enrollment only, or a separately administered early default-deny deployment that also protects HCD recreation/reboot.
- Exact dedicated-controller identification, handling of xHCI companion buses, and whether any external hub topology is allowed.
- Enforcement of no non-broker writable USBFS access from node creation and explicit treatment of already issued descriptors. The current kernels expose no universal userspace USBFS FD revocation API in the audited paths.
- Storage-specific explicit release and uncertain-failure state, including remote filesystem/page/device-cache flush and no automatic local remount after fault.
- Whether a future USBFS backend needs an additional kernel mechanism or a different owned-port/pre-claim protocol. Simply authorizing its interface to satisfy claim removes the unauthorized-interface barrier and requires a separate race analysis; do not inherit the Native proof.

## Exact USBFS claim-negative contract for the selected fixture

Parent selected both defaults 0 → connect fresh target → bind Native while device authorized=0 → authorize device → actual IMPORT/SET_CONFIGURATION. For a new root USBFS FD opened after the source interface exists:

- Require original USB/HCD generation, CONFIGURED state, exact interface number, `authorized=0`, and no interface `dev.driver` before the operation.
- Require USBFS open to succeed. `usbdev_open()` has no `usb_device_is_owned()`/port-owner rejection (v6.8 `devio.c:1032-1076`, v5.15 `1010+`). Native's port claim does not itself make the node unopenable.
- Require `USBDEVFS_CLAIMINTERFACE` to fail with **ENODEV**, not an accepted set of unrelated errors. Its `claimintf()` path uses `usb_driver_claim_interface()`, which checks an already-bound interface first (EBUSY), then rejects `authorized=0` with ENODEV (v6.8 `driver.c:547-553`; v5.15 `544-550`). A newly opened FD has no already-claimed interface bit. The port-owner rejection is in `usb_probe_interface()` (v6.8 `334`), not this explicit claim path.
- Recheck the same generation/interface authorization and absence of local interface driver after close. Target disappearance, missing interface, earlier open failure, different errno or a successful claim fails the case; do not widen the error expectation. This keeps the evidence specific to the intended claim rejection rather than disconnect/permission accidents.
- Record syscall return/errno and metadata only; no USB payload logging is needed.

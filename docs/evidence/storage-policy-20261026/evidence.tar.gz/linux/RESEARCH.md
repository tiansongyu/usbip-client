# E67: durable USB controller enrollment and recovery

Status: proposed product component; source research only. Date: 2026-10-26. Starting project HEAD: `c6850e7d6e866f1b72fff7a29e370a290895013f`. Fixed Linux sources: v5.15 `8bb7eca972ad531c9b149c0a51ab43a417385813`, v6.8 `e8f897f4afef0031fe618a8e94127a0934896aba`.

This report follows the actual E66 design and validation: four final stock-tool mechanism pairs passed on Ubuntu `5.15.0-198-generic` and `6.8.0-147-generic`; RustUSB storage export remained disabled. E66 demonstrated runtime pre-arrival interface isolation and real remote two-LUN I/O, not persistent controller policy. Its three failed trials, nonzero-LUN sense limitation and forced client shutdowns remain unchanged. No host USB/block device, process, module, service or account was inspected or changed for E67 research. No build or QEMU was run. Only this `/tmp` directory was written.

## Finding and recommendation

A durable pre-arrival policy needs **device authorization denial in effect before each HCD is initialized**, including after reboot or HCD recreation. In the audited stock kernels the relevant bootstrap setting is the global `usbcore.authorized_default=0`. HCD construction copies that setting before publishing its root hub. Every new non-root USB device then starts unauthorized, before generic configuration and BOT/UAS interface probing.

The interface default still starts at **1** on every new HCD. The product must re-arm the selected controller by writing and verifying interface-default **0** on every associated root bus **before authorizing any target**. A persisted controller enrollment is not itself a current HCD receipt or a target grant.

Recommended first product envelope:

- Explicit administrator deployment of boot default device denial on a supported Ubuntu host. Do not silently edit GRUB/initramfs or toggle a global USB parameter as a side effect of enrolling one controller.
- A dedicated direct-root-port controller, with all logical root buses accounted for. E67 can arm it after a reboot/rebind while devices remain unauthorized under the boot policy.
- Root-only enrollment/reconciliation operations that persist intent, write only the two fixed defaults to 0, verify actual generations/readbacks and create a fresh runtime receipt. They do not authorize USB devices, export storage, reset PCI, unbind an HCD or restore defaults to 1.
- Independent future target admission and storage release. Existing or uncertain target/session history is not made safe by a new controller receipt.

Runtime `usbX/authorized_default=0` and `interface_authorized_default=0` remain useful for E66's controlled fresh hotplug, but cannot be advertised as durable across HCD reconstruction. Setting the **global module parameter** to 0 at runtime protects subsequently created HCDs, unlike a per-bus store, but does not prove earlier history and does not survive module/kernel reload without an appropriate persistent boot/module setting.

## Source provenance and limits

`manifest.json` records original URLs, fixed commits, hashes, bytes, license notices, failed attempts and E66 reuse provenance. `prior-e66/` preserves its complete report/manifest/receipt; `prior-and-api-checks.json` verifies those receipt hashes and the Git object hashes of three API-retrieved files. Kernel COPYING/GPL/syscall exception originals are retained. No GPL implementation should be copied into MIT Rust code.

New googlesource requests failed four times with a closed connection; three raw-GitHub fallback requests received 429; an Ubuntu guide URL returned 404. Those failed attempts remain separate from successful originals obtained later through GitHub's source API. Web browsing also reported inaccessible old Ubuntu URLs and a GNU manual timeout; no claim depends on the unavailable page. Six release-specific Ubuntu manuals and a Noble update-grub manual were retrieved; their original copyright notices are retained without asserting an unverified common license. The prior E66 36 HTTP-429 attempts remain in its preserved manifest.

These are upstream v5.15/v6.8 facts. Actual Ubuntu build options, initramfs loader configuration and distro patches must be recorded in the experiments. The relevant Ubuntu manuals currently identify Jammy kmod `29-1ubuntu1.1` and Noble kmod `31+20240202-2ubuntu7.2`; those website versions are not claims about the versions installed in an unobserved guest.

## Why boot default denial precedes probing

Paths below are relative to the Linux tree.

| Stage | v5.15 | v6.8 | Consequence |
|---|---|---|---|
| USB core composite module | `drivers/usb/core/Makefile:6-19` | same file, `6-19` | `hcd.o` belongs to usbcore, so its module parameter is `usbcore.authorized_default`. |
| Default parameter definition | `core/hcd.c:370-387` | `core/hcd.c:349-365` | Signed integer, default -1 (allow), exposed read-only to ordinary users and writable by owner. Only explicit 0 selects default device denial. |
| HCD policy initialization | `core/hcd.c:2824-2847` | `core/hcd.c:2821-2840` | `dev_policy` copies the global parameter; interface authorization is set to 1 independently. |
| Root hub registration follows initialization | `core/hcd.c`, remainder of `usb_add_hcd()` after the above | `core/hcd.c:2846-2981` | Bus allocation, root-hub construction, HCD start and root-hub registration occur after defaults are initialized. |
| New USB device construction | `core/usb.c:582-601,720` | `core/usb.c:605-624,741` | Root hub is always authorized; each non-root device samples HCD policy into its own `authorized` field. |
| Generic device configuration | `core/generic.c:242-265` | `core/generic.c:242-265` | An unauthorized device is not configured by generic probe. |
| Interface probe gate | `core/driver.c:318-341` | `core/driver.c:321-344` | Device/interface denial is checked before interface-driver binding. |
| Explicit later authorization | `core/hub.c:2631+` | `core/hub.c:2684-2719` | Sets device authorization and selects a configuration. This is why interface default must already be 0. |
| New configuration interfaces | `core/message.c:1957+,2072` | `core/message.c:1993+,2108` | Newly created interfaces copy the current HCD interface default. |

This supplies a kernel ordering argument rather than relying on the management service winning a race with enumeration. It prevents local class-driver publication within the trusted-host policy; it is not a universal USB command firewall or a guarantee against external privileged policy changes.

Primary sources: [HCD initialization](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/hcd.c#L2821), [device constructor](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/usb.c#L605), [interface initialization](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/message.c#L2108).

## Ubuntu boot and module configuration

The fixed kernel documentation explicitly supports module-prefixed parameters on the kernel command line. Built-in components require that route; normal modprobe also collects such parameters from `/proc/cmdline` for loadable modules (`Documentation/admin-guide/kernel-parameters.rst:18-28`, both tags). `usbcore.authorized_default` is documented at v5.15 `kernel-parameters.txt:5895+` and v6.8 `6838+`.

The practical canonical setting is:

```text
usbcore.authorized_default=0
```

It must be on the effective kernel command line of **every boot entry that claims persistent protection**, before the `--` separator. Merely writing a boot configuration file is not evidence that the running kernel consumed it. Verify the actual boot's command line, kernel version/build/config context and `/sys/module/usbcore/parameters/authorized_default`, then verify the current selected HCD defaults. A current value of 0 without valid boot provenance cannot prove a controller never initialized with allow earlier in this boot.

Both [Jammy modprobe](https://manpages.ubuntu.com/manpages/jammy/man8/modprobe.8.html) and [Noble modprobe](https://manpages.ubuntu.com/manpages/noble/man8/modprobe.8.html) document collecting module options from the kernel command line. An `options usbcore authorized_default=0` file is effective for loadable usbcore only if the loader sees it before the **first** load. If loading occurs in initramfs, the effective early configuration must be there; a later file in the real root filesystem does not retroactively affect the loaded module. It cannot configure built-in usbcore. Direct insmod or overriding load options are outside the normal modprobe assumption and must not be treated as equivalent evidence.

For Ubuntu images using initramfs-tools, its release-specific manuals document generating/updating the image, including explicit kernel selection; updating an image is still not proof of the next boot's effective module parameters. Noble's [update-grub manual](https://manpages.ubuntu.com/manpages/noble/man8/update-grub.8.html) describes regeneration of `/boot/grub/grub.cfg`. The product should report a missing prerequisite and a concrete administrator configuration plan rather than silently assuming every Ubuntu installation uses that boot path. An ARM board's firmware command line, cloud boot loader or QEMU `-append` may differ.

A QEMU `-append` experiment proves kernel parameter behavior. It does **not** by itself validate a product installer editing GRUB/initramfs. A persistent installed-image test must boot through the configured boot loader again and record the resulting command line. Recovery/fallback boot entries without the deny parameter do not satisfy the policy.

Global bootstrap denial affects non-root USB devices across controllers, including potentially boot storage, unlock/input and USB networking. A supported initial deployment should use non-USB boot/storage/management paths, or a separately reviewed early allowlist for essential controllers/devices. Administrators can explicitly allow other buses/devices after bootstrap while retaining the global future-HCD default 0; RustUSB enrollment must not silently authorize unrelated buses. A server that depends on a denied USB root volume cannot recover by reading a policy file from that same unavailable volume.

### Bounded boot-policy verification

`kernel/params.c` v6.8 `161-187` consumes arguments until `--`; `lib/cmdline.c:227-275` handles quotes; parameter name matching treats hyphen/underscore equivalently (`kernel/params.c:86-99`). Use a bounded parser that identifies the normalized exact key, handles/rejects quotes safely, detects duplicate/conflicting occurrences and stops at the actual separator. A substring search for `usbcore.authorized_default=0` is insufficient.

A conservative first API may accept only an unambiguous canonical 0 spelling and reject other forms as unsupported. It must also recognize conflicting equivalent-key forms rather than ignoring them. Invalid, missing, multiple, quoted-ambiguous, post-`--`, oversized or unreadable evidence is not boot assurance. Current global value must also be exactly 0. Such checks verify a trusted deployment contract; they are not remote attestation and cannot prove that another host root never changed the value transiently.

## There is no audited stock per-controller boot default here

The two fixed USB core implementations have a global module parameter and per-HCD runtime defaults; the audited xHCI/USB policy paths have no controller-address-specific boot authorization parameter. Several superficially related mechanisms do not provide the needed persistent per-controller guarantee:

| Mechanism | What it can do | Why it does not replace this bootstrap boundary |
|---|---|---|
| Per-root-hub sysfs defaults | Protect subsequent devices/interfaces for that HCD instance | Attribute exists only after root hub construction; values are reinitialized when the HCD is rebuilt. |
| udev RUN rule / systemd startup service | Configure discovered root hubs | `device_add()` creates the devtmpfs node and emits add uevent before proceeding to probe, without waiting for userspace policy completion (`drivers/base/core.c` v5.15 `3367-3396`, v6.8 `3613-3639`). Scheduling cannot establish a pre-probe guarantee. |
| PCI `driver_override=none` | Prevent a currently unbound PCI controller from matching a driver | Real PCI support exists (`pci-driver.c` v5.15 `135-176`, v6.8 `136-177`); the ABI explicitly says storing override does not unbind an existing driver. Once xHCI is intentionally bound, HCD construction still needs default denial before enumeration. Override is not a USB per-device setting and does not survive new PCI objects/reboot by itself. |
| Module blacklist / delayed xHCI load | Can delay a modular controller driver under a controlled boot loader | Cannot delay an already built-in/probed driver; no root-hub sysfs defaults exist before its bind. Loading usbcore with global denial first can bridge the gap, but that is the global mechanism again. |
| Temporarily set global 0 around one controller bind, then restore 1 | Can make that controlled HCD's initial policy deny | Other HCD creation can occur concurrently; later unexpected recreation of the enrolled HCD sees 1. It is not durable enrollment. |
| Port disable | v6.8 `core/port.c:47-127` can disconnect/power off a port at runtime | This interface is absent in the audited v5.15 port source and is neither an early per-controller boot policy nor persistent across port/HCD destruction. It can disconnect an already used device. Do not use it as automatic recovery. |
| Firmware gating or PCI/VFIO assignment to a dedicated VM | Can provide different physical or virtualization isolation | Requires a separately controlled platform/boot design. Not established by the current Linux USB/IP enrollment source audit. |

xHCI can create primary and shared HCDs for one PCI function: v5.15 `drivers/usb/host/xhci-pci.c:404-424`, v6.8 `601-621`. An enrollment limited to whichever `usbX` appeared first is incomplete. Track the actual PCI parent and the complete associated HCD/root-hub set, with a bounded maximum and explicit unsupported-topology result.

This does not prove that no specialized firmware/initramfs/kernel-extension architecture could implement a different boundary. It establishes that the generic stock APIs audited here do not expose a durable per-controller replacement for early device default denial. A custom kernel notifier/module or a carefully staged platform-specific loader would be a new design and security surface, not a hidden implementation detail.

Primary references: [PCI override ABI](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/Documentation/ABI/testing/sysfs-bus-pci#L323), [xHCI shared HCD creation](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/host/xhci-pci.c#L601), [device publication ordering](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/base/core.c#L3613).

## Proposed product contracts

These are API/state proposals, not existing RustUSB symbols. Keep the first increment root-only and preserve every existing storage-export denial. Enrollment must perform real durable policy work; it must not be renamed observation-only reporting or advertised as complete storage support.

### Separate four identities

1. `ControllerPolicyId` and policy revision: durable administrator intent for a selected dedicated controller. A selector can include stable canonical PCI topology plus vendor/device/subsystem identity and permitted controller driver. BDF alone is a location, not authenticated hardware identity.
2. `ControllerEpoch`: one boot and helper runtime epoch, the current PCI object, and every current HCD/root-hub object. HCD rebind can preserve the PCI object while replacing all HCDs; PCI remove/rescan can replace both; reboot replaces the boot/runtime epoch. Root bus numbers and sysfs paths can repeat.
3. `ArmedControllerReceipt`: fresh verified current-epoch observation after durable intent and successful default-0 operations. Retain live pins using the existing project identity/worker conventions while it is usable. Persisted inode/path observations are not a substitute for a live pin after helper death.
4. `TargetArrivalReceipt`: separate exact USB generation and its relationship to a current armed controller. This still needs target authorization, original storage history, exclusive USBFS capability policy and full storage admission. A new controller receipt cannot refresh an old target/session grant.

### Minimal root API

| Proposed operation | Inputs | Output / effects |
|---|---|---|
| `InspectControllerPolicy` | Validated controller selector or existing policy ID | Read-only boot/global/controller evidence and reason codes. No permission. |
| `EnrollController` | Root-authenticated caller, policy UUID, exact selector, expected policy revision, expected boot context | Durably records requested denial before sysfs mutations; writes only fixed default-0 attributes for the selected current HCD set; verifies all objects/readbacks; commits a new current-epoch receipt. No device authorization or export. |
| `ReconcileController` | Existing policy ID + expected revision | Revalidates boot/global policy and current topology; re-arms newly created HCDs to interface-default 0 if safe; issues a new receipt. Never adopts the old target or session identity. |
| `SuspendControllerAdmission` | Existing policy ID | Durably prevents new admissions while retaining kernel denial and existing actual-owner cleanup obligations. Does not restore 1. |
| `RetireControllerEnrollment` | Existing policy ID, explicit administrator intent, verified no active/pending owned device jobs and suitable empty/absent controller state | Retires durable enrollment without silently enabling a currently attached storage target or changing the global boot option. Local device authorization/release is a separate future command/contract. |

Requests must not accept arbitrary sysfs paths, arbitrary values, shell commands, PCI unbind/rebind, whole-driver unloading or automatic boot-loader edits. Resolve the fixed policy ID to trusted current paths internally. A controller state read or receipt is metadata and cannot be used as a generic helper USB capability.

### State machine

```text
Unenrolled
  -> EnrollmentPrepared (durable root intent, no target grant)
  -> Arming (actual fixed stores / readbacks owned and joined)
  -> Armed [current boot + helper epoch + PCI/HCD set]

Armed -- helper restart / boot change / HCD set change --> ReconcileRequired
ReconcileRequired -- verified boot/global deny + current objects --> Arming
Arming -- complete current readbacks + durable commit --> Armed (new receipt)

any state -- missing boot prerequisite / drift / unexpected authorized target --> AdmissionSuspended
any mutation -- unknown durable outcome / blocked actual worker --> Unconfirmed
AdmissionSuspended -- explicit repair + new complete verification --> Arming
Armed or AdmissionSuspended -- valid explicit retirement preconditions --> Retired
```

`EnrollmentPrepared`, `Arming`, `ReconcileRequired`, `AdmissionSuspended` and `Unconfirmed` never authorize a target. State names must not imply that a wall-clock deadline canceled a blocked sysfs or fsync operation.

### Mutation and recovery invariants

- Root private bounded/strict storage, expected revision/idempotency and atomic durability should reuse the project's established trusted-file/journal patterns. Do not overwrite older unknown outcomes or bypass outstanding actual owners.
- Commit desired denial before applying changes. For a newly rebuilt HCD under boot device-deny, a current state of device-default 0/interface-default 1 is expected and safely **not armed**. Lower interface default to 0, verify all root buses and commit the new receipt before any target authorizer can proceed.
- Keep a per-controller mutation owner across real sysfs I/O and verification. Serialize product target authorization against arming/reconciliation. A timeout or disconnected requester does not release an active blocking operation's slot.
- If any write/readback/durable update fails, retain achieved denial where present. Do not automatically restore old allow values. Return the actual partial/unknown outcome and a readable administrative recovery path.
- Unexpected authorized non-root devices, local interface drivers or an uncontrolled existing topology mean prior isolation is unproven. Do not repair that by forced deauthorization, unmount, reset or HCD unbind; these can disrupt active storage. Suspend admission and require an explicit appropriate recovery workflow.
- On helper restart, create a fresh helper epoch and revalidate rather than treating a persisted `Armed` label as live authority. On HCD recreation, keep the durable **intent** but invalidate the old receipt. Re-arming the controller may be automatic under that existing authorized intent and verified boot denial; authorizing a replacement target must not be automatic.
- Keep the global runtime parameter at 0 as a prerequisite for protection of future HCDs. A per-controller arm should not rewrite it. If it is observed as 1/-1/2/invalid, suspend new admission; restoring it afterward cannot erase the interval of lost assurance.
- Explicit administrative quarantine is not an orphaned device owner. Provide retirement/recovery status and keep it distinct from USB resource cleanup and from filesystem/media consistency. The failure path should not silently leave an unexplained permanent lock.

## What “fail closed” means across events

| Event | Preserved / invalidated state | Correct behavior |
|---|---|---|
| Product process crash, same kernel | Kernel defaults may remain denied; process-owned handles do not prove old jobs ended | Reconcile policy in a new helper epoch; preserve old unresolved jobs; do not issue replacement target grants. |
| HCD rebind, same PCI function | Runtime per-HCD defaults are recreated. Old HCD receipts invalid even if PCI directory remains | Boot/global 0 starts new devices denied while interface default is 1. Re-arm every new HCD before granting anything. |
| PCI remove/rescan | PCI and HCD objects can both change, potentially at the same BDF | Require current selector/topology agreement and fresh runtime receipts; never interpret BDF equality as continuity. |
| Reboot | Durable admin intent survives; all live controller/target/session receipts do not | Validate the actual new boot policy first. New unauthorized device objects are not evidence that old media writes were clean. |
| Target remains physically connected through reboot | New kernel USB generation, potentially old physical storage contents/history | Keep source local drivers blocked, but preserve storage-attention/recovery requirements. “Never published locally this boot” is not “safe to remount/export after previous crash.” |
| Boot without the parameter or with effective global allow | Kernel may publish local storage before the helper starts | Refuse durable admission; do not claim a late monitor or current sysfs0 prevented publication. This is an unsupported boot, not safely repaired history. |
| External root changes sysfs/default/module/boot settings | Kernel policy is mutable by privileged administrators | Outside the prevention guarantee. Detected drift revokes product admission, but no retrospective no-binding claim is possible. |

USBFS remains a separate boundary. E66 showed that interface authorization denies explicit interface claims but not every device-level ioctl on an existing writable USBFS FD. Global device default denial does not revoke that descriptor. The colleague's USBFS analysis is required before actual storage admission. No controller receipt should claim adversarial-root isolation, malicious-device authentication, media write protection or remote filesystem quiescence.

## Minimum QEMU acceptance proposal

All cases are **planned and unexecuted by this research**. Use Ubuntu 22.04 and 24.04 separately, record exact kernel/config/tool/image/source hashes and keep all failures. Dedicated virtual PCI controller, synthetic disposable media, virtio/non-USB guest boot and management NIC, no host device passthrough. Tests must distinguish kernel boot-policy behavior, product policy persistence, and Native storage I/O rather than adding them to one unqualified count.

1. **Cold boot with target already attached, default deny.** Provide the boot parameter before starting the guest. Before starting the product enrollment service, record actual command line, global value 0, new HCD device-default 0/interface-default 1, target unauthorized, no source BOT/UAS interface/block child. Keep the product absent/delayed at this first observation so successful isolation cannot be attributed to a fast userspace race.
2. **Product enrollment and restart.** Enroll the exact dedicated controller using the product root API. Require durable intent, both defaults 0 for the entire actual root-hub set, unchanged unrelated controllers, and a new current-epoch receipt. Restart the owned helper. Require revalidation/new helper epoch rather than replayed old live authority; no target is auto-authorized.
3. **Actual HCD rebind with the synthetic target still connected.** Unbind/rebind only the fixture's dedicated guest PCI controller after proving no active imported/storage writer owner. Record actual old/new HCD identities; PCI identity may stay unchanged. Before product reconciliation, expect the new root buses to show device-default 0/interface-default 1 and the new target unauthorized. Reject the old controller/target receipts. Reconcile into a fresh receipt with both defaults 0.
4. **Real guest reboot.** Preserve the durable policy file and boot configuration, reboot the guest, and require a different boot ID. Again observe device denial before product start. Old receipts cannot be reused. The service re-arms new HCDs from persisted intent; any physically persistent target has a new USB generation and no inherited target grant. A QEMU reset/quit that bypasses graceful shutdown must be recorded as a separate fault, not normal reboot evidence.
5. **Independent default-1 positive control.** In a separate disposable boot with effective default 1 and the BOT driver present, the same synthetic device must bind locally and produce the expected local block child before enrollment. The product must refuse durable arm and must not claim the controller was protected. As an additional narrow control, apply runtime per-bus zeros with a fresh fixture device, then rebind the HCD under global allow: the recreated HCD returns to allow. Preserve that exposure as the intended demonstration of E66's limit, not an accepted E67 state.
6. **Boot/current-value mismatch and malformed evidence.** Missing flag, post-`--` flag, duplicate/conflicting aliases and oversized data can be parser/unit cases; at least one guest case should have boot text 0 but a deliberate fixture-root runtime global change to 1. Product rejection must happen without USB authorization or a false historical repair claim.
7. **Mutation interruption.** Fail/crash the owned helper after durable prepared intent, between bus writes, after readback but before durable completion, and during a controlled writer barrier. Original operations must retain real owners and fail closed; new helper cannot infer completed mutation from requester death. Corrupt/missing/oversized/foreign-owned policy files must not reset defaults to allow or generate receipts.
8. **One actual data-path regression under the product-established policy per supported guest direction.** Continue using the existing E66 Native mechanism fixture only after a real current controller receipt is established. Verify the source interfaces remain denied through client configuration and real disposable LUN I/O/flush/detach. If RustUSB storage export remains blocked, label the split accurately: product controller policy + stock Native transfer, not integrated secure RustUSB storage support. Preserve E66's exact flush/LUN/layout and teardown limitations.

The first five scenarios on both kernels are the minimum evidence for claiming controller policy survives the demonstrated reboot/rebind lifecycle. They still do not cover permanent sysfs blocking, hardware power loss, every PCI error-recovery route, active-write crash recovery, live handoff from an already mounted disk, USBFS revocation, UAS or real hardware. Those remain explicit original-goal work, not replaced by successful enrollment.

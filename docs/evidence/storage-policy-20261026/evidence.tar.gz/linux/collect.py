from pathlib import Path
import hashlib,json,shutil,urllib.request,base64,concurrent.futures,datetime
r=Path('/tmp/rustusb-storage-policy-linux-20261026');prior=Path('/tmp/rustusb-storage-arrival-linux-20261026');revs=json.loads((prior/'revisions.json').read_text());sources=[]
for filename in ['receipt.json','manifest.json','RESEARCH.md','line-index.tsv','revisions.json']:
 t=r/'prior-e66'/filename;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes((prior/filename).read_bytes())
pm=json.loads((prior/'manifest.json').read_text());seen={}
for s in pm['sources']:
 if 'sha256' in s:seen[(s['version'],s['path'])]=s
for (v,p),s in seen.items():
 b=(prior/'sources'/v/p).read_bytes();assert hashlib.sha256(b).hexdigest()==s['sha256'];t=r/'sources'/v/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b);sources.append(dict(s,reused_from=str(prior/'sources'/v/p)))
newpaths=['drivers/usb/host/xhci-pci.c','drivers/usb/host/xhci.c','drivers/pci/pci-driver.c','drivers/pci/pci-sysfs.c','Documentation/ABI/testing/sysfs-bus-pci','drivers/usb/core/port.c','drivers/usb/core/Makefile','Documentation/admin-guide/kernel-parameters.rst','drivers/base/core.c','drivers/base/bus.c','init/main.c','kernel/params.c','lib/cmdline.c']
def fetch(t):
 v,p=t;c=revs[v];u=f'https://kernel.googlesource.com/pub/scm/linux/kernel/git/torvalds/linux/+/{c}/{p}?format=TEXT'
 try:
  raw=urllib.request.urlopen(u,timeout=45).read();b=base64.b64decode(raw,validate=True);f=r/'sources'/v/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b);return dict(version=v,commit=c,path=p,url=u,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),license=next((l.strip() for l in b.decode(errors='replace').splitlines()[:40] if 'SPDX-License-Identifier:' in l),'See original file notices and kernel COPYING'))
 except Exception as e:return dict(version=v,commit=c,path=p,url=u,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:sources+=list(ex.map(fetch,[(v,p) for v in revs for p in newpaths]))
(r/'manifest.json').write_text(json.dumps({'date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':sources,'prior_failures_preserved_at':'prior-e66/manifest.json'},indent=2)+'\n');(r/'revisions.json').write_text(json.dumps(revs,indent=2)+'\n')
repo=Path('/home/ubuntu/github/usbip-client');context=[]
for p in ['docs/requirements.md','docs/research/storage-arrival-quarantine-design.md','docs/research/storage-arrival-quarantine-validation.md']:
 b=(repo/p).read_bytes();f=r/'project-context'/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b);context.append({'path':p,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
(r/'project-context.json').write_text(json.dumps({'starting_head':'c6850e7d6e866f1b72fff7a29e370a290895013f','context':context},indent=2)+'\n')
print({'sources':sum('sha256' in s for s in sources),'new_failures':[s for s in sources if 'error' in s]})

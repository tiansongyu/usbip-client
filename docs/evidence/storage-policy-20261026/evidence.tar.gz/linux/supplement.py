from pathlib import Path
import urllib.request,hashlib,json,concurrent.futures
r=Path('/tmp/rustusb-storage-policy-linux-20261026');m=json.loads((r/'manifest.json').read_text());revs=json.loads((r/'revisions.json').read_text());tasks=[]
for s in m['sources']:
 if 'error' in s:
  v,p=s['version'],s['path'];tasks.append((f'sources/{v}/{p}',f'https://raw.githubusercontent.com/torvalds/linux/{revs[v]}/{p}',v,revs[v],p,'Kernel per-file SPDX and COPYING'))
for release in ['jammy','noble']:
 for name,section in [('modprobe','8'),('modprobe.d','5'),('update-initramfs','8')]:
  url=f'https://manpages.ubuntu.com/manpages/{release}/man{section}/{name}.{section}.html';tasks.append((f'public/ubuntu/{release}/{name}.{section}.html',url,release,None,name,'Original Ubuntu-rendered upstream manual copyright retained; consult page notices'))
tasks.append(('public/ubuntu/kernel-boot-parameters.html','https://documentation.ubuntu.com/real-time/en/rt-conf/how-to/modify-kernel-boot-parameters/',None,None,'kernel-boot-parameters','Canonical Ubuntu documentation; preserve footer and linked licensing notices'))
def get(t):
 local,u,v,c,p,license=t
 try:
  response=urllib.request.urlopen(u,timeout=30);b=response.read();out=r/local;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b);return dict(version=v,commit=c,path=p,local_path=local,url=u,final_url=response.url,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),license=license)
 except Exception as e:return dict(version=v,commit=c,path=p,local_path=local,url=u,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:new=list(ex.map(get,tasks))
m['sources']+=new;(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print({'fetched':sum('sha256' in s for s in new),'errors':[{'url':s['url'],'error':s['error']} for s in new if 'error' in s]})

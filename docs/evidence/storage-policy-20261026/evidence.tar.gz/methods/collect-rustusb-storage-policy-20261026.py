import gzip,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
R=Path('/home/ubuntu/github/usbip-client');D=R/'docs/evidence/storage-policy-20261026';assert not D.exists()
roots={n:Path('/tmp/rustusb-storage-policy-'+n+'-20261026') for n in ['jammy','noble','regression-jammy','regression-noble','software','linux','usbfs','audit']}
files={};keys=[];omitted=[]
def sha(d):return hashlib.sha256(d).hexdigest()
for prefix,root in roots.items():
 for p in sorted(root.rglob('*')):
  if p.is_symlink() or not p.is_file():continue
  if '.private' in p.parts:
   if p.name=='ssh-key':keys.append(p.read_bytes())
   continue
  if '__pycache__' in p.parts or p.suffix=='.pyc':continue
  n=prefix+'/'+p.relative_to(root).as_posix();data=p.read_bytes()
  if prefix=='usbfs' and p.relative_to(root).parts[0]=='ubuntu':
   reason=None
   try:data.decode('utf-8')
   except UnicodeDecodeError:reason='non-text extracted package payload'
   if b'\0' in data or p.suffix=='.deb' or data.startswith(b'\x7fELF'):reason='binary package or extracted payload'
   if reason:omitted.append({'path':n,'bytes':len(data),'sha256':sha(data),'reason':reason});continue
  files[n]=data
for f in ['/tmp/run-rustusb-storage-policy-gates-20261026.py','/tmp/audit-rustusb-storage-policy-20261026.py',__file__]:files['methods/'+Path(f).name]=Path(f).read_bytes()
H='54a6b7a1d411ea063a81ee6468911a87bf057684'
for n in subprocess.check_output(['git','ls-tree','-r','--name-only',H,'scripts/qemu_storage_policy','scripts/qemu_storage_arrival','scripts/qemu_installed_usb/vm.py'],cwd=R,text=True).splitlines():files['fixture-sources/'+H+'/'+n]=subprocess.check_output(['git','show',H+':'+n],cwd=R)
files['excluded-package-payloads.json']=(json.dumps(omitted,indent=2)+'\n').encode()
def scan(n,d):
 assert not n.startswith('/') and '..' not in Path(n).parts and '.private' not in Path(n).parts,n
 assert not d.startswith((b'\x7fELF',b'QFI\xfb',b'!<arch>')),n
 assert not re.search(rb'-----BEGIN (?:OPENSSH |RSA |EC |DSA )?PRIVATE KEY-----\s*\n',d),n
 assert not re.search(rb'(?i)(?:[?&]X-Amz-Signature=|[?&]sig=[A-Za-z0-9%]{24})',d),n
 assert not any(k in d for k in keys),n
 if n.endswith('.tar'):
  with tarfile.open(fileobj=io.BytesIO(d)) as t:
   for m in t.getmembers():
    assert m.isdir() or m.isfile(),(n,m.name)
    if m.isfile():scan(m.name,t.extractfile(m).read())
for n,d in files.items():scan(n,d)
D.mkdir(parents=True);a=D/'evidence.tar.gz'
with a.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as t:
 for n,d in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(d);m.mode=0o644;m.mtime=0;t.addfile(m,io.BytesIO(d))
m={'scope':'E67 two policy runs and two original normal arrival regressions; all pass; eight normally exiting QEMU processes; software and fixed-source research retained separately','archive':a.name,'sha256':sha(a.read_bytes()),'archive_bytes':a.stat().st_size,'members':{n:{'bytes':len(d),'sha256':sha(d)} for n,d in sorted(files.items())},'excluded':'private directories, keys, disks, executable and binary package payloads, pycache; symlinks recorded by research rather than followed','excluded_package_files':len(omitted),'actual_private_keys_checked':len(keys)}
with tarfile.open(a) as t:
 assert set(t.getnames())==set(files)
 for x in t.getmembers():assert t.extractfile(x).read()==files[x.name]
(D/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
(D/'README.md').write_text('''# Storage boot policy and USBFS lifetime evidence

See the [validation report](../../research/storage-controller-enrollment-validation.md). Two Ubuntu policy runs and two original normal arrival-transfer regressions pass at clean `54a6b7a1`. The eight actual QEMU processes exit normally. Software records contain 1,148 core and 18 GUI executions. The unavailable original outer software-tool terminal response is explicitly recorded; the runner-owned child exit observations remain intact.

The archive includes raw guest evidence, original methods, exact fixture sources, a same-author record audit and two separate source reviews. Research hypotheses and proposed API contracts are not product implementation. Original download failures, prior-source provenance and license files remain. No private keys, disk images, executable or binary package payloads are published. `excluded-package-payloads.json` retains their sizes and hashes; symlinks are recorded, not followed. Research manifests can therefore name deliberately excluded originals.

`manifest.json` hashes every included member; all members were read back after compression. This archive does not replace E66's preserved failed trials or claim storage export, hardware acceptance, universal USBFS revocation or safe disk recovery.
''')
print(json.dumps({'members':len(files),'raw_bytes':sum(map(len,files.values())),'gzip_bytes':m['archive_bytes'],'sha256':m['sha256'],'excluded_package_files':len(omitted),'private_keys_checked':len(keys)}))

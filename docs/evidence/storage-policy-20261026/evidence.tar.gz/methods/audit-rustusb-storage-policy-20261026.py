import hashlib,json,subprocess,tarfile
from pathlib import Path
R=Path('/home/ubuntu/github/usbip-client');O=Path('/tmp/rustusb-storage-policy-audit-20261026');H='54a6b7a1d411ea063a81ee6468911a87bf057684'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def gitfile(n):return subprocess.check_output(['git','show',H+':'+n],cwd=R)
s=load(Path('/tmp/rustusb-storage-policy-software-20261026/summary.json'));assert s['head']==H and s['result']=='PASS' and all(s['guards'].values())
assert [(c['exit'],c['passed'],c['failed'],c['ignored']) for c in s['commands']]==[(0,1148,0,0),(0,18,0,0)]
for n,v in s['inputs'].items():assert len(gitfile(n))==v['bytes'] and sha(gitfile(n))==v['sha256'],n
for n,v in s['binaries'].items():assert sha((R/n).read_bytes())==v['sha256']
report={'head':H,'software_inputs':len(s['inputs']),'scope':'same-author raw-record review; no runner import, new USB execution or independent security audit','runs':{}}
for name in ['jammy','noble','regression-jammy','regression-noble']:
 p=Path('/tmp/rustusb-storage-policy-'+name+'-20261026');r=load(p/'result.json');v=load(p/'provenance.json');assert r['passed'] and r['head']==H and all(r['guards'].values())
 for n,h in v['inputs'].items():assert sha(gitfile(n))==(h['sha256'] if isinstance(h,dict) else h),n
 detail={'source_inputs':len(v['inputs']),'qemu_exits':r['qemu_exits']}
 if not name.startswith('regression'):
  d=load(p/'observations.json');assert r['qemu_exits']==[0,0] and r['collection_exit']==0 and r['kernel_integrity'] and r['backing_zero_after_actual_exit']
  assert len({x['pid'] for x in r['actual_process_exits']})==2
  assert d['1-prepare']['boot_id']!=d['2-prepare']['boot_id'] and d['2-prepare']['global_default']=='0'
  assert d['2-prepare']['cmdline'].split().count('usbcore.authorized_default=0')==1
  cmd=load(p/'boot-2-qemu.json')['command'];assert any('usb-storage,id=policy-storage' in x for x in cmd)
  assert 'usb-storage' in [i['driver'] for i in d['1-local']['interfaces']] and d['1-local']['blocks']
  with tarfile.open(p/'guest-evidence.tar') as t:
   for cohort,expected in [('pre_bind',[(18,0), (18,0),(-1,19)]),('post_bind',[(18,0)]*4)]:
    c=d['1-descriptors'][cohort];ready=c['identity']['ready'];assert ready['uid']==ready['gid']==65534 and ready['groups']==ready['cap_eff']==0
    rows=c['observations'];assert [(x['held_rw']['rc'],x['held_rw']['errno']) for x in rows]==expected
    for i,x in enumerate(rows):
     assert x['pid']==ready['pid'] and x['state']['generation']==c['identity']['generation']
     assert (x['held_ro']['rc'],x['held_ro']['errno'])==(-1,1)
     assert (x['fresh_open_rc'],x['fresh_open_errno'])==((0,0) if cohort=='pre_bind' and i==0 else (-1,13))
     assert not x['state']['blocks'] and all(a['authorized']=='0' and a['driver'] is None for a in x['state']['interfaces'])
    e=json.load(t.extractfile('./probe-'+cohort.replace('_','-')+'-exit.json'));assert e['actual_exit']==0
    closed=json.loads(e['remaining_stdout']);assert closed['phase']=='closed'
   detail['guest_evidence_regular_members']=sum(x.isfile() for x in t.getmembers())
  for key,n in [('1-recreate-1','1'),('2-recreate-0','0')]:
   z=d[key];assert z['before']['generation']!=z['after']['generation']
   assert {tuple(x['identity']) for x in z['old_roots'].values()}.isdisjoint({tuple(x['identity']) for x in z['new_roots'].values()})
   assert all(x['authorized_default']==n and x['interface_authorized_default']=='1' for x in z['new_roots'].values())
   assert bool(z['after']['blocks'])==(n=='1')
  for key in ['2-cold']:
   x=d[key];assert x['authorized']=='0' and not x['blocks'] and not x['interfaces'] and not x['acl'] and x['node_stat']['mode']==0o600
  x=d['2-authorize'];assert x['before']['generation']==x['after']['generation'] and x['after']['authorized']=='1'
  assert not x['after']['blocks'] and x['after']['interfaces'] and all(i['authorized']=='0' and i['driver'] is None for i in x['after']['interfaces'])
  assert (p/'guest/.private/storage.raw').read_bytes()==bytes(64*1024*1024)
 else:
  assert r['qemu_exits']=={'server':0,'client':0} and r['backing_readback_after_actual_qemu_exit']
 report['runs'][name]=detail
report['passed']=True;(O/'review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))

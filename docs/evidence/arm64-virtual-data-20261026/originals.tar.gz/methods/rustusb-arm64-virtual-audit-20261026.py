import hashlib,json,pathlib,struct,subprocess

root=pathlib.Path('/home/ubuntu/github/usbip-client')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reports=[]
for family in [4,6]:
    out=pathlib.Path('/tmp/rustusb-arm64-virtual-v4-20261026' if family==4 else '/tmp/rustusb-arm64-virtual-v6-ready-20261026')
    read=lambda n:json.loads((out/n).read_text())
    summary=read('summary.json');provenance=read('provenance.json')
    assert summary['passed'] and not summary['errors'] and all(summary['guards'].values())
    assert summary['qemu_exits']=={'server':0,'client':0}
    assert summary['controller_exits']=={'client':0,'server':0}
    assert read('host-owner-receipt.json')['actual_tool_exit']==0
    head=summary['fixture_head'];mapped=0
    for name,digest in provenance['inputs'].items():
        data=subprocess.check_output(['git','show',head+':'+name],cwd=root)
        assert hashlib.sha256(data).hexdigest()==digest
        mapped+=1
    current_frozen={name:sha(pathlib.Path(name))==digest for name,digest in provenance['frozen'].items()}
    assert all(current_frozen.values())
    paired=0;identities={};catalogs=[];held=[];released=[];snapshots=[];channels=[]
    for role in ['server','client']:
        public=out/role/'artifacts'
        for req in sorted(public.glob('*-request.json')):
            index=req.name.split('-')[0];request=json.loads(req.read_text())
            response=json.loads((public/(index+'-response.json')).read_text())
            original=list((out/role).glob(index+'-*-response.json'))
            assert len(original)==1 and json.loads(original[0].read_text())==response and response['ok']
            action=request['action'];data=response['data'];paired+=1
            if action=='setup':
                identities[role]=data
                assert 'aarch64' in data['identity'] and '\narm64\n' in data['identity']
                assert data['elfs']['/usr/bin/rustusb']['sha256']=='fcd4b2d35c3ed4c88d1ee284302d44c117e555b995248f9254c63136d5795993'
                if role=='client':
                    helper=data['helper']['process'];assert helper['exe_sha256']=='a3b8f928c9e23e40b3d149a93ef419bb7a09ae5fb1d5d1b71ad9487a9b00e4f0'
                    uidline=next(s for s in helper['status'].splitlines() if s.startswith('Uid:'))
                    assert uidline.split()[1:]==['0']*4
            if action=='catalog':catalogs.append(data)
            if action=='attach':held.append(data)
            if action=='detach':released.append(data)
            if action=='snapshot':snapshots.append(data['snapshot'])
        assert json.loads((out/role/'controller-wait.json').read_text())['exit']==0
        if role=='client':
            final=json.loads((public/'controller-cleanup.json').read_text())['helper_final']
            assert final['MainPID']=='0' and final['ActiveState']=='inactive'
    assert len(catalogs)==3 and catalogs==[catalogs[0]]*3
    assert {x['device_key'] for x in catalogs[0]}=={'virtual:hid','virtual:cdc-acm'}
    assert len(held)==len(released)==2 and len(snapshots)==4
    for cycle in [1,2]:
        public=out/'client/artifacts'
        rx=f'RUSTUSB-RX-{cycle}-0001:0123456789abcdef\n'.encode()
        tx=f'RUSTUSB-TX-{cycle}-0001:fedcba9876543210\n'.encode()
        assert (public/f'rx-{cycle}.bin').read_bytes()==rx
        assert (public/f'tx-{cycle}.bin').read_bytes()==tx
        assert (public/f'echo-{cycle}.bin').read_bytes()==tx
        raw=(public/f'input-{cycle}.bin').read_bytes();assert len(raw)%24==0
        events=[struct.unpack('<qqHHi',raw[i:i+24])[2:] for i in range(0,len(raw),24)]
        assert (1,cycle+1,1) in events and (1,cycle+1,0) in events
        rows=held[cycle-1]['kernel']['journal']['records'];assert len(rows)==2
        for profile in ['hid','serial']:
            events=[json.loads(x) for x in (public/f'{profile}-{cycle}.events').read_text().splitlines()]
            connected=[e for e in events if e.get('event')=='connected'];assert len(connected)==1
            assert any(e.get('event')=='disconnected' and e['cleanup_verified'] is True for e in events)
            wait=json.loads((public/f'{profile}-{cycle}-wait.json').read_text());assert wait['exit']==0 and not wait['observation_timeout']
            receipt=connected[0]['receipt'];channels.append(receipt['channel_id'])
            row=next(r for r in rows if r['channel_id']==receipt['channel_id'])
            assert row['state']['receipt']==receipt['kernel'] and row['target']==receipt['target']
            proc=held[cycle-1][profile]['identity']
            assert row['owner']['uid']==identities['client']['uid'] and row['owner']['pid']==proc['pid'] and row['owner']['starttime']==proc['starttime']
            assert proc['exe_sha256']==identities['client']['elfs']['/usr/bin/rustusb']['sha256']
        release=released[cycle-1]
        assert all(release['gone'].values()) and len(release['gone'])==2
        assert release['snapshot']['journal']=={'schema_version':1,'records':[],'exports':[]}
        for item in release['snapshot']['vhci']:
            assert all(int(s.split()[2])==4 for s in item['text'].splitlines() if s.startswith(('hs ','ss ')))
        for offset,leased in [(0,True),(1,False)]:
            devices=snapshots[2*(cycle-1)+offset]['devices']
            assert len(devices)==2 and all(d['leased']==leased and d['configuration']==int(leased) for d in devices)
            if not leased:assert all(d['pending_urbs']==d['hid_queued_reports']==d['cdc_queued_bytes']==0 for d in devices)
            hid=next(d for d in devices if d['profile']=='hid_keyboard');cdc=next(d for d in devices if d['profile']=='cdc_acm')
            assert hid['counters']['hid_taps']==cycle
            assert (cdc['counters']['cdc_out_bytes'],cdc['counters']['cdc_in_bytes'],cdc['counters']['cdc_injected_bytes'])==(35*cycle,70*cycle,35*cycle)
    assert len(set(channels))==4
    packet=read('packet-review.json')
    assert all(v['port_3240_rst_families']==[4,6] and len(v['flows'])>=16 for v in packet.values())
    reports.append({'family':family,'fixture_head':head,'product_head':summary['product_head'],'mapped_inputs':mapped,
                    'paired_raw_requests_responses':paired,'unique_original_channels':len(channels),'io_cycles':2,
                    'injected_bytes':70,'client_out_bytes':70,'echo_bytes':70,'qemu_exits':summary['qemu_exits'],
                    'broker_uids':{r:i['uid'] for r,i in identities.items()},'passed':True})
target=pathlib.Path('/tmp/rustusb-arm64-virtual-audit-20261026.json')
target.write_text(json.dumps({'scope':'Same-author read-only original evidence cross-check, not another USB execution or independent security audit.',
                              'method_sha256':sha(pathlib.Path(__file__)),'cases':reports,'passed':True},indent=2)+'\n')
print(target.read_text())

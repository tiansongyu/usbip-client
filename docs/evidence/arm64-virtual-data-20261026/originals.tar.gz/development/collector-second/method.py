import gzip,hashlib,io,json,pathlib,re,subprocess,tarfile

root=pathlib.Path('/home/ubuntu/github/usbip-client')
destination=root/'docs/evidence/arm64-virtual-data-20261026'
destination.mkdir(parents=True,exist_ok=True)
assert not list(destination.iterdir()), "Never overwrite an existing evidence artifact"
sha=lambda data:hashlib.sha256(data).hexdigest()
members={};origins={};private_values=[]
cases={'ipv4':'/tmp/rustusb-arm64-virtual-v4-20261026',
       'ipv6-install-failure':'/tmp/rustusb-arm64-virtual-v6-20261026',
       'ipv6-ready':'/tmp/rustusb-arm64-virtual-v6-ready-20261026'}
allowed={'.json','.jsonl','.stdout','.stderr','.log','.pcap','.der'}
def add(name,data,origin):
    assert name not in members and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
    members[name]=data;origins[name]=origin
for label,directory in cases.items():
    base=pathlib.Path(directory)
    for p in sorted(base.rglob('*')):
        if not p.is_file():continue
        relative=p.relative_to(base)
        if '.private' in relative.parts:
            if p.name in ('ssh-key','ca-key.pem','ca-key.der','server-key.pem','server-key.der','client-key.pem','client-key.der'):
                private_values.append(p.read_bytes())
            continue
        assert not p.is_symlink()
        assert len(relative.parts)<=3 and (p.suffix in allowed or 'artifacts' in relative.parts),relative
        add('cases/'+label+'/'+relative.as_posix(),p.read_bytes(),str(p))
    provenance=json.loads((base/'provenance.json').read_text());head=provenance['fixture_head']
    source_names=['scripts/qemu_arm64/virtual.py','scripts/qemu_arm64/virtual_guest.py',
                  'scripts/qemu_arm64/arm_vm.py','scripts/qemu_installed_usb/vm.py',
                  'scripts/qemu_installed_usb/guest.py','scripts/qemu/run-secure-qemu.py',
                  'scripts/qemu/run-native-qemu.py','scripts/qemu/run-physical-qemu.py',
                  'docs/research/arm64-virtual-data-design.md']
    for name in source_names:
        key='executed-source/'+head+'/'+name
        if key not in members:
            data=subprocess.check_output(['git','show',head+':'+name],cwd=root)
            assert sha(data)==provenance['inputs'][name]
            add(key,data,'git:'+head+':'+name)
for name in ['rustusb-arm64-virtual-audit-20261026.py','rustusb-arm64-virtual-audit-20261026.json',
             'rustusb-arm64-virtual-collect-20261026.py']:
    p=pathlib.Path('/tmp')/name;add('methods/'+name,p.read_bytes(),str(p))
development=pathlib.Path('/tmp/rustusb-arm64-virtual-development-20261026')
for p in sorted(development.rglob('*')):
    if p.is_file():add('development/'+p.relative_to(development).as_posix(),p.read_bytes(),str(p))
for name,data in members.items():
    assert '.private' not in pathlib.PurePosixPath(name).parts
    assert not data.startswith(b'\x7fELF') and not data.startswith(b'QFI\xfb')
    assert re.search(rb'-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----\r?\n[A-Za-z0-9+/=]{32,}', data) is None, name
    assert all(not value or value not in data for value in private_values),name
    assert b'X-Amz-Signature=' not in data and b'SharedAccessSignature=' not in data,name
    if name.endswith('-public-artifacts.stdout'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
            for m in t.getmembers():
                if m.isdir() and m.name=='.':continue
                relative=m.name.removeprefix('./');assert m.isfile() and '/' not in relative
                target=str(pathlib.PurePosixPath(name).parent/'artifacts'/relative)
                assert t.extractfile(m).read()==members[target]
archive=destination/'originals.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for name,data in sorted(members.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    assert [m.name for m in tar.getmembers()]==sorted(members)
    assert all(tar.extractfile(name).read()==data for name,data in members.items())
manifest={'schema_version':1,'members':[{'name':n,'bytes':len(d),'sha256':sha(d),'origin':origins[n]}
                                       for n,d in sorted(members.items())]}
(destination/'originals-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
summary={'schema_version':1,'cases':{label:json.loads((pathlib.Path(d)/'summary.json').read_text()) for label,d in cases.items()},
         'read_only_audit':json.loads(pathlib.Path('/tmp/rustusb-arm64-virtual-audit-20261026.json').read_text()),
         'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,
                    'members':len(members),'raw_bytes':sum(len(d) for d in members.values())},
         'privacy':{'actual_private_key_files_excluded_and_scanned':len(private_values),'member_roundtrip':True,
                    'disks_firmware_packages_executables_excluded':True,'nested_public_tar_members_verified':True}}
(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'archive':summary['archive'],'privacy':summary['privacy']}))

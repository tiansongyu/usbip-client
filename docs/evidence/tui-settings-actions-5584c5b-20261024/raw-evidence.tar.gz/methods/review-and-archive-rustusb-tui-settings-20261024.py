import pathlib,json,hashlib,subprocess,re,base64,tarfile,io,shutil
repo=pathlib.Path('/home/ubuntu/github/usbip-client');target=repo/'docs/evidence/tui-settings-actions-5584c5b-20261024'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=repo)
assert not git('status','--porcelain').strip();target.mkdir(exist_ok=False)
software=pathlib.Path('/tmp/rustusb-tui-settings-software-5584c5b-20261024');s=read(software/'summary.json')
assert s['result']=='PASS'and s['inputs_unchanged']and all(c['exit_code']==0 for c in s['commands'])
counts={name:sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',(software/(name+'.log')).read_text())))for name in ['test-default','test-all','vendor']};assert counts=={'test-default':417,'test-all':513,'vendor':20}
for name,item in s['inputs_before'].items():
 data=(repo/name).read_bytes();assert sha(data)==item['sha256']and git('show',s['head']+':'+name)==data
all_binary=next(c['binaries']for c in s['commands']if c['name']=='release-all')
roots=[software];qrows=[];actual_pty=0
for kind in ['actions','settings-regression']:
 for family in ['ipv4','ipv6']:
  root=pathlib.Path('/tmp/rustusb-tui-'+kind+'-'+family+('-first'if kind=='actions'else'')+'-20261024');q=read(root/'summary.json');roots.append(root)
  assert q['result']=='PASS'and q['guest_exit_codes']=={'server':0,'client':0}and all(q[k]for k in ['source_guard','binary_guard','head_guard','clean_guard'])
  assert q['facts']['assertion_count']==264
  assert q['binary_sha256']=={n:i['sha256']for n,i in all_binary.items()}
  for name,item in q['source_inputs'].items():
   data=(repo/name).read_bytes();assert sha(data)==item['sha256']and len(data)==item['bytes']and git('show',q['head']+':'+name)==data
  children=0
  for role in ['server','client']:
   folder=root/(role+'-artifacts')
   for result in sorted(folder.glob('tui-*.result')):
    prefix=result.name.removesuffix('.result');fields=dict(line.split('=',1)for line in result.read_text().splitlines());assert fields['uid']=='1000'and fields['exit']=='0'
    assert all(fields[k]=='1'for k in ['waited','raw_observed','resized','restored','entered','left'])
    status=(folder/(prefix+'.status')).read_text();assert re.search(r'^Uid:\s+1000\s+1000\s+1000\s+1000$',status,re.M)
    assert re.search(r'^Pid:\s+'+fields['pid']+r'$',status,re.M)
    assert all(re.search(r'^'+cap+r':\s+0000000000000000$',status,re.M)for cap in ['CapInh','CapPrm','CapEff','CapAmb'])
    assert(folder/(prefix+'.exe-sha256')).read_text().split()[0]==all_binary['rustusb']['sha256']
    tty=dict(line.split('=',1)for line in (folder/(prefix+'.termios')).read_text().splitlines());assert all(tty['before_'+k]==tty['after_'+k]for k in ['flags','speeds','cc'])
    children+=1
   final=read(folder/('agent-stopped-2.json'if role=='server'else'agent-final.json'));journal=read(folder/('root-stopped-2.json'if role=='server'else'root-final.json'))
   assert all(x['terminal']and x['cleanup']=='verified'for x in final['sessions']);assert journal['records']==[]and journal['exports']==[]
   for profile in (['server']if role=='server'else['hid','serial']):
    for epoch in [1,2]:
     receipt=read(folder/f'start-{profile}-{epoch}.json');assert receipt['response']['result']=='started'and receipt['response']['replayed']==(kind=='actions')
     if kind=='actions':
      prefix=f'tui-start-{profile}-{epoch}'
      before=read(folder/(prefix+'-before.json'));after=read(folder/(prefix+'-after.json'));retry=read(folder/(prefix+'-after-retry.json'));old={r['id']for r in before['requests']};new=[r for r in after['requests']if r['id']not in old]
      assert len(new)==1 and new[0]['uid']==1000 and new[0]['profile']==profile and new[0]['job_id']==receipt['response']['job']['id']and after['requests']==retry['requests']
  assert children==(19 if kind=='actions'else 10);actual_pty+=children
  qrows.append({'name':root.name,'head':q['head'],'inputs':len(q['source_inputs']),'actual_pty':children,'guest_exits':q['guest_exit_codes']})
  shutil.copyfile(root/'summary.json',target/(root.name+'-summary.json'))
assert actual_pty==58
shutil.copyfile(software/'summary.json',target/'software-summary.json')
entries=[];payloads={}
def add(p,name):
 data=p.read_bytes();assert not data.startswith(b'\x7fELF')and not re.search(rb'-----BEGIN (?:RSA |EC |ENCRYPTED )?PRIVATE KEY-----\r?\n',data)
 assert '.private'not in str(p)and 'target/'not in name
 entries.append({'path':name,'original':str(p),'bytes':len(data),'sha256':sha(data)});payloads[name]=data
for root in roots:
 for p in sorted(root.rglob('*')):
  if p.is_file():add(p,root.name+'/'+str(p.relative_to(root)))
methods=[pathlib.Path(__file__),pathlib.Path('/tmp/run-rustusb-tui-settings-gate-20261024.py'),pathlib.Path('/tmp/rustusb-tui-actions-first-pty-driver-20261024.c')]
methods+=sorted(pathlib.Path('/tmp').glob('rustusb-tui-settings-development-*-20261024.log'))
methods+=sorted(pathlib.Path('/tmp').glob('rustusb-tui-actions-*-first-20261024-driver.log'))
methods+=sorted(pathlib.Path('/tmp').glob('rustusb-tui-settings-regression-*-20261024-driver.log'))
for p in methods:add(p,'methods/'+p.name)
blocks=0
for root in roots[1:]:
 for role in ['server','client']:
  for m in re.finditer(rb'SECURE_ARTIFACT_BEGIN ([^\n]+) (\d+)\n(.*?)SECURE_ARTIFACT_END \1\n',(root/(role+'-evidence.log')).read_bytes(),re.S):
   data=base64.b64decode(m[3]);assert len(data)==int(m[2])and data==(root/(role+'-artifacts')/m[1].decode()).read_bytes();blocks+=1
archive=target/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for name,data in sorted(payloads.items()):
  info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 assert len(tar.getmembers())==len(entries)
 for m in tar.getmembers():assert sha(tar.extractfile(m).read())==sha(payloads[m.name])
for e in entries:assert sha(pathlib.Path(e['original']).read_bytes())==e['sha256']
manifest={'result':'PASS','files':entries,'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'software_counts':counts,'software_inputs':len(s['inputs_before']),'qemu':qrows,'actual_pty':actual_pty,'guest_base64_blocks_redecoded':blocks,'scope':'Same-author raw/source/identity review without importing original verifier. Not new USB execution or independent security audit. Actual Start receipts in action cases are safe replayed CLI readbacks of original acknowledged UI starts, not lost-ACK UI tests. No ELF/keys/host-private output.'}
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:manifest[k]for k in ['result','software_counts','software_inputs','qemu','actual_pty','guest_base64_blocks_redecoded','archive']}))

import datetime, hashlib, json, os, pathlib, shutil, subprocess, time
repo = pathlib.Path('/home/ubuntu/github/usbip-client')
out = pathlib.Path('/tmp/rustusb-tui-settings-software-5584c5b-20261024')
out.mkdir(exist_ok=False)
def git(*args):
    return subprocess.check_output(['git',*args],cwd=repo).decode().strip()
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def inputs():
    names = subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z'],cwd=repo).split(b'\0')
    selected = {}
    for name in sorted(set(os.fsdecode(n) for n in names if n)):
        path = repo/name
        if path.is_file() and (name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','scripts/check.sh'] or name.startswith('.cargo/') or name.startswith('vendor/') or (name.startswith('crates/') and path.suffix in ['.rs','.toml'])):
            selected[name] = {'bytes':path.stat().st_size,'sha256':digest(path)}
    return selected
def save():
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
summary = {'head':git('rev-parse','HEAD'),'status_before':git('status','--porcelain'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'host_uid':os.geteuid(),'inputs_before':inputs(),'commands':[],'result':'FAIL'}
save()
if summary['status_before']: raise RuntimeError('clean source required')
for name in summary['inputs_before']:
    dest=out/'source'/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(repo/name,dest)
steps = [
 ('fmt',['cargo','fmt','--all','--','--check']),
 ('clippy-default',['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings']),
 ('test-default',['cargo','test','--workspace','--locked']),
 ('release-default',['cargo','build','--workspace','--release','--locked']),
 ('docs-default',['cargo','doc','--workspace','--no-deps','--locked']),
 ('clippy-all',['cargo','clippy','--workspace','--all-targets','--all-features','--locked','--','-D','warnings']),
 ('test-all',['cargo','test','--workspace','--all-features','--locked']),
 ('release-all',['cargo','build','--workspace','--all-features','--release','--locked']),
 ('docs-all',['cargo','doc','--workspace','--all-features','--no-deps','--locked']),
 ('vendor',['cargo','test','--manifest-path','vendor/nusb/Cargo.toml','--lib','--features','tokio','--locked','--target-dir','target/nusb-tests']),
]
try:
    for name,argv in steps:
        started=time.monotonic()
        env=os.environ.copy()
        if name.startswith('docs-'): env['RUSTDOCFLAGS']='-D warnings'
        with (out/(name+'.log')).open('wb') as log:
            run=subprocess.run(argv,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
        item={'name':name,'argv':argv,'exit_code':run.returncode,'seconds':time.monotonic()-started}
        if name.startswith('release-') and run.returncode==0:
            item['binaries']={exe:{'bytes':(repo/'target/release'/exe).stat().st_size,'sha256':digest(repo/'target/release'/exe)} for exe in ['rustusb','rustusb-helper']}
        summary['commands'].append(item)
        save()
        print(name,run.returncode,flush=True)
        if run.returncode: raise RuntimeError('failed '+name)
    summary['result']='PASS'
except Exception as error:
    summary['error']=repr(error)
finally:
    summary['inputs_after']=inputs()
    summary['head_after']=git('rev-parse','HEAD')
    summary['status_after']=git('status','--porcelain')
    summary['inputs_unchanged']=summary['inputs_before']==summary['inputs_after']
    if not summary['inputs_unchanged'] or summary['head_after']!=summary['head'] or summary['status_after']!=summary['status_before']: summary['result']='FAIL'
    summary['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
print(json.dumps({'result':summary['result'],'source_inputs':len(summary['inputs_before']),'output':str(out)}),flush=True)
raise SystemExit(0 if summary['result']=='PASS' else 1)

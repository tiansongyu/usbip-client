# E68 Native controller follow-up review

Reviewed commit `b7ff08f267aeda14f9de0575b647d688e2948a79`, using `git show` so concurrent working-tree changes do not become review inputs. Only this report was written. No repository edits, builds, test execution, QEMU, host USB or process inspection were performed.

Input SHA-256:

- `crates/rustusb-native/src/controller.rs`: `2817668b239af04bbce6f158c06fbc52eb055cf0af686d706d1dc18aeddfc0dc`.
- `crates/rustusb-native/src/controller/tests.rs`: `6d4b7682819ca3260d3289f2179c970202350ce2c32eb0d8b8e805aee5b862cb`.

The parent reports ten targeted Native tests and the complete 1,206-check software gate passing. Those results were not executed independently by this reviewer. The subsequent default-build physical-journal refusal is outside the reviewed commit and is not covered by this conclusion.

## Conclusion

All four findings from `REVIEW-IMPLEMENTATION.md` are addressed for their stated contracts. I found no remaining P1 issue in those fixes. The new scope APIs preserve the important distinction between an original historical Native path and a current physical generation. Two narrow hardening points remain below; neither demonstrates misclassification of a valid canonical path produced by the real kernel, nor revocation of previously delegated USBFS descriptors.

The module provides bounded repeated observations and original-object targeting. It does not provide an atomic topology snapshot, continuous exclusion against an external administrator, or proof that a device was never briefly authorized between observations. The two-Ubuntu guest validation should retain these limits and its actual failures.

## Original findings

| Finding | Reviewed correction | Result |
| --- | --- | --- |
| R1: implicit preparation and stale state after prepare/arm failure | `pin` starts with `initial: None` at line 547. `prepare` clears it before any read at line 873 and sets it only after selector, boot and denial checks. `arm` takes it at lines 891–894; it never prepares internally and never restores it after success or failure. | Addressed. Direct open→arm, failed prepare and failed arm cannot establish or reuse preparation. |
| R2: incomplete observation tail | `observe` performs two complete `observe_once` calls and requires equal results at lines 593–604. Each pass repeats the original physical chain and boot/global checks at lines 795–799. | Addressed as a bounded consistency check. The tests inject boot/global/root/attribute/arrival changes between passes. No atomicity claim is justified. |
| R3: dropped alias and ancestor trust chains | `DirectoryChain` retains every ordinary directory FD. Environment retains the PCI/USB alias, driver, usbcore and proc chains; the physical PCI chain is retained separately. Checks reopen each component with NOFOLLOW and compare against the original identity and trusted metadata. | Addressed for the original steady drift cases. Intermediate aliases, ancestor modes and same-object path replacement are no longer silently accepted on later observations. |
| R4: skipped root interface and unexpected directories | The original root interface is retained; each pass compares it with the current child, checks class `09` and the `hub` driver at lines 700–715. Unexpected real directories at root level are refused at lines 720–733. | Addressed for absent/replaced/unbound/wrong-owner root interfaces and unknown direct directories. Normal hub port children remain below the validated interface. |

Writer safety remains sound: writable attributes are opened relative to the retained root, compared with the original attribute identity, written once with the fixed two-byte denial value, and read back from that same writer. Failures do not trigger an allow-value rollback. The after-observation is required before success. These checks do not cancel an already executing blocking sysfs operation.

## F1 — an observed inspection error leaves earlier preparation usable

Priority: **P2**, narrow public API lifecycle consistency. Location: `controller.rs:867–870`.

`inspect()` returns `self.observe()` without clearing `initial` on error. The following sequence is permitted by the source:

1. Explicit successful `prepare(expected_selector, expected_boot)` saves a valid baseline.
2. The same arrival becomes authorized, or another checked trust/topology condition becomes invalid.
3. `inspect()` actually observes that invalid condition and returns an error.
4. The same objects are restored to the baseline values.
5. `arm()` still has the old saved baseline and can succeed.

This finding is specifically about **a failure already observed by this object**. It does not claim that repeated userspace observations can detect an external root change that occurs and disappears entirely between reads; that historical-exposure problem remains an explicit deployment/trust limitation. It also does not claim the current daemon caller retries after inspection failure.

A small correction is to clear preparation when `inspect` returns an error. Alternatively make all explicit inspections revoke preparation and document that stronger API rule, provided the caller sequence supports it. There is no need for another abstraction or a claim of continuous monitoring.

Targeted test: prepare → modify an arrival to authorized1 → inspect error → restore authorized0 on the same objects → arm must still refuse without stores → a new explicit prepare is required. Keep the original observation error; do not replace it with a fabricated historical-exposure verdict.

## F2 — malformed historical USB path chains can return unrelated

Priority: **P2 for the documented malformed-input contract**, not an observed valid-kernel-path scope failure. Locations: `controller.rs:811–815`, `948–983`.

`original_controller` correctly rejects paths outside `/sys/devices`, parent components, missing roots, root-only paths and non-BusId children. It compares controller paths by components, so a similar BDF string is not treated as the selected controller. It deliberately does not consult a possibly replaced current bus alias, which is appropriate for a retained Native registration.

The parser nevertheless accepts individually valid but mutually inconsistent names such as:

- `.../usb2/3-1`;
- `.../usb2/2-1/2-9.2`;
- `.../usb2/2-1.2` with a missing parent device component.

If the prefix names another controller, these return `Ok(false)` even though the method promises malformed historical scope is an error. Existing registration validation does not close this exact gap: `export_channel.rs:420–451` checks the `/sys/devices` prefix, absence of parent components, saved fields and descriptor equality, but does not validate the root bus and parent-port chain. The journal is root-controlled and normal capture uses a canonical kernel path, so this is corrupt/unsupported input handling rather than an unprivileged attack demonstrated here.

The small correction is to parse the root bus once, require every child BusId to have that bus, require a direct first child, and require each subsequent child to extend the previous port chain by exactly one level. Preserve legitimate non-PCI historical controller prefixes: scope classification is not permission to use that controller. Do not introduce a blanket PCI-name requirement or consult current topology for an old gone Native path. Add selected/unselected malformed-chain tests so both fail closed. If maintainers intentionally support a weaker structural grammar, narrow the comment and document why that still supplies sufficient historical scope.

## Exact physical-generation scope

`contains_physical_generation` at lines 818–865 requires the saved boot, resolves the current BusId under trusted sysfs, retains/checks its complete physical chain, and twice compares the saved sysfs device/inode with the opened object and current alias. It checks saved busnum and devnum, classifies the canonical physical ancestry, and checks the boot again. Gone, replacement and another-boot receipts return the conservative unknown-scope error rather than being excluded as unrelated. The explicit tests cover both selected and unrelated exact live generations, address changes, gone devices and replacement directories.

Ignoring `node_device`/`node_inode` here is appropriate: this method only recovers controller scope from an exact sysfs generation and never opens USBFS or claims descriptor closure. The daemon must still validate the complete receipt and retain its original actual-owner/journal rules. In particular, an inability to inspect an old physical generation cannot be converted to “not this controller.”

The selected controller's full preparation/arming checks remain separate. A successful scope classification is not a fresh export permission, an atomic proof that the owner remains live, or a retirement event. Scope checks need the helper's existing mutation serialization and complete active/pending owner collection; this Native module alone cannot prove those daemon properties.

## Real sysfs compatibility and QEMU gate

The fixed Linux v5.15/v6.8 material retained in the preceding reviews supports the intended normal layout: xHCI PCI driver `xhci_hcd`, direct primary/shared root hubs, normal authorized1 root devices, root class/interface class09, and the hub interface owner `hub`. Device default denial does not require changing root authorized1. Unauthorized generic USB devices can have an empty `bConfigurationValue`; the scalar reader accepts that empty value. The parser deliberately supports a strict subset of boot command-line syntax and does not reinterpret rejected syntax as safe.

There is one conditional compatibility observation, not a reason to relax validation in advance: Linux can publish wakeup class metadata beneath a device when wakeup is enabled. The current whitelist rejects an extra real `wakeup` directory. In fixed v6.8, `drivers/base/core.c:3167–3237` creates class glue directories; `drivers/base/power/wakeup_stats.c:127–176` creates a wakeup-class child whose parent is the device; `drivers/base/power/wakeup.c:311–331` enables/registers the source. This does not establish that the intended QEMU roots actually expose the directory. The parent will capture actual guest sysfs evidence and preserve any failure before considering a narrowly justified metadata classification. Unknown USB descendants must remain rejected.

Primary source references for that conditional observation: [fixed Linux core.c](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/base/core.c#L3167), [fixed wakeup_stats.c](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/base/power/wakeup_stats.c#L127), [fixed wakeup.c](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/base/power/wakeup.c#L311). Linux source is GPL-2.0; existing saved-source hashes and provenance remain in the prior research manifests. The two power files were consulted as fixed public source views, not added to the saved-source manifest by this report.

No evidence here permits storage export, claims USBFS revocation, proves cache closure, or changes the original hardware and fault-validation limits.

## Review method and retained limitations

Read-only inspection used `git show b7ff08f2:<path>`, `nl`, `sed`, `rg` and SHA-256 over the two committed module files. Cross-checks included the committed Native export registration validator and Native journal loader. Two initial lookup guesses (`registration.rs`, `registration/`) and a guessed `controller-enrollment-design.md` name did not exist; the actual `export_channel.rs`, `native_state.rs` and storage-prefixed design were located instead. No missing-path read was treated as a successful check.

The current report supplements the preserved initial review; it does not rewrite the original findings or development failures. A later changed commit needs its own source attribution and relevant validation, rather than inheriting the b7ff08f2 hashes above.

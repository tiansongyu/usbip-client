# E68 Linux controller enrollment implementation review

Status: implementation advice and negative-test design, not executed validation. Baseline `0c3dd04cce607e7255382b266ca120a85535c8d8`, 2026-10-26. The `rustusb-development` and `writing-technical-design` skills and E67 design/validation were read. This is the parent-requested independent component review; no additional component skill was created. All writes are confined to this directory. No repository changes, builds, QEMU, host device/process inspection, or network download occurred.

The recommended increment is a root-only, durable administrator enrollment intent plus a fresh, explicitly bounded controller observation/arming operation. It lowers only selected current root-hub interface defaults to zero and verifies the whole controller. It does not authorize a target, transfer a USBFS FD, enable storage export, restore a previous allow value, repair an uncontrolled live-storage history, or declare old storage caches safe.

## Reuse small existing patterns

| Existing baseline source | Reuse | Do not infer or copy into the new path |
| --- | --- | --- |
| `crates/rustusb-native/src/import_power.rs:35–118,121–205` | NOFOLLOW child opens from an already pinned directory; metadata identity; bounded seek/read; exactly one sysfs store; same-FD readback; final generation recheck | Its entry path follows a particular pre-authorized USB bus alias; controller enrollment needs its own fixed root/sysfs/PCI trust chain. Do not make its existing public behavior broader. |
| `crates/rustusb-native/src/import_power_tests.rs:97–153,197–223` | Last-moment alias replacement test; replacement must remain unwritten; short/interrupted store invoked once | Equal-sized fixture-file writes only prove FD targeting, not real sysfs callback semantics. |
| `crates/rustusb-logging/src/storage/linux.rs:49–108,133–175` | Open trusted ancestors one component at a time; stat/open/stat identity comparison; directory enumeration through retained FD | Sysfs is not a private log: do not require 0700/0600 or nlink1, create attributes, chmod them, or fsync them. |
| `crates/rustusb-daemon/src/native_state.rs:130–260` | Root-controlled journal-directory walk and fresh open-description locking for durable enrollment intent | Do not repurpose existing Native/USBFS disk schemas or reinterpret their old records as controller grants. |
| `crates/rustusb-daemon/src/storage.rs:5–26` | UID check before reading/acquiring quota; actual blocking closure retains its permit after its waiter disappears | Enrollment mutates, so it also needs the existing helper shutdown/real-owner join and a controller mutation lock. This is not merely a read-only observer. |
| `crates/rustusb-daemon/src/physical.rs:114–155` | Distinguish opened FD identity from path observations before/after open | Controller arming must not open a USBFS/block node; it has no reason to delegate a device capability. |
| `crates/rustusb-native/src/export_channel.rs:176–224,535–571` | Exact original generation and attribute identity; metadata is separate from retained operational FD | A copied receipt or duplicated old FD is not recovery after HCD replacement. Avoid introducing an enrollment dependency on export-specific capability types. |
| `crates/rustusb-native/src/channel.rs:699–730` | Persist intent before first side effect; verify original opened object | The new path should use the stronger directory/openat approach rather than copying its pathname-based attribute open. |
| `crates/rustusb-linux/src/storage.rs:440–477` | Verify sysfs/procfs filesystem magic | Its observation-only path resolution is not the complete mutation authority boundary. |

A single Linux controller module with a few private helpers is sufficient: a validated BDF type, a small pure boot parser, trusted directory/attribute opening, one `PinnedController` containing two `PinnedRootHub`s, a bounded snapshot verifier, and a fixed zero-store function. Keep durable policy storage in the helper's existing storage layer. There is no need for a generic filesystem trait, generalized arbitrary-attribute writer, controller plugin framework, or new public path/value inputs.

Possible internal shape (names are recommendations, not existing symbols):

```rust
pub struct PciBdf(String); // validated in TryFrom/FromStr and Deserialize

struct NodeIdentity { filesystem_device: u64, inode: u64 }
struct PinnedRootHub {
    directory: File,
    device_default: File,
    interface_default: File,
    identity: NodeIdentity,
    // immutable original names/attribute identities and checked metadata
}
struct PinnedController {
    pci_directory: File,
    roots: [PinnedRootHub; 2],
    // boot ID, normalized PCI locator, original PCI/driver/root identities
}
```

These owned files live in the actual blocking operation. Public JSON and persistent records carry bounded observations/identity, not raw descriptors or a transferable USB capability. If a later operation wants to use an observation, it must validate it against a new current snapshot under the appropriate mutation lock; the old observation is not continuous authority.

## Validated PCI selector

Use canonical lowercase `dddd:bb:dd.f`, exactly 12 ASCII bytes. Separator offsets are 4, 7 and 10; the remaining positions are lowercase hex, and the final function digit is 0–7. Domain is 16 bits, bus 8 bits, device 0–31, function 0–7. Reject rather than silently lowercase/trim/normalize. This gives one serialization and one per-controller lock key.

Examples: accept `0000:00:06.0`, `abcd:fe:1f.7`; reject empty/short/upper-case, leading/trailing whitespace, NUL, Unicode, slash, `.`/`..`, URL forms, `0000:00:20.0`, `0000:00:1f.8`, and shortened `00:06.0`. No user-supplied sysfs directory, root-hub name, attribute name, driver path, arbitrary integer value, boot path, or shell command belongs in the request.

A BDF is an administrator-selected location, not authenticated hardware. At initial enrollment record the current PCI vendor/device/subsystem identities and actual driver; later reconciliation compares the durable selector contract and produces a new boot/helper/PCI/HCD generation receipt. Same BDF or same vendor/device values do not preserve an old live generation.

## Trusted FD walk without new dependencies

The workspace pins rustix **1.1.5**, checksum `891efababe418670775f199f0d233d84843c227a0949a883ce15b37c78d6629d`, with the fs/process features already present. Its `open`, `openat`, `statat`, `readlinkat`, `Dir::read_from`, `fstatfs`, `OFlags`, `AtFlags` and `FileType` are sufficient. `OwnedFd -> File` is safe Rust. No new `unsafe` or dependency is needed.

1. Open `/` with RDONLY|DIRECTORY|NOFOLLOW|CLOEXEC; validate root ownership/type/non-writable-to-group-or-other. Open fixed `sys` and `proc` children the same way and validate `fstatfs`: SYSFS_MAGIC `0x62656572`, PROC_SUPER_MAGIC `0x9fa0`. Retain the opened anchors through the operation.
2. Walk fixed `bus/pci/devices` and `devices` components under the pinned sysfs FD using openat with DIRECTORY|NOFOLLOW. Verify each opened directory is root owned, has no 0022 write bits, and belongs to the anchored sysfs filesystem. Walk fixed `module/usbcore/parameters` similarly. Walk `sys/kernel/random` beneath the procfs anchor for boot ID; open `cmdline` under procfs.
3. PCI bus entries are legitimate **kernel symlinks**, so applying NOFOLLOW to the selector entry itself and treating every ELOOP as unsafe would reject real sysfs. Resolve only that known alias deliberately. One small implementation reads the link with readlinkat, normalizes its relative components against `bus/pci/devices` inside the pinned `/sys`, rejects escape/absolute/oversized/invalid components, requires the result under `devices`, then walks those normal components with NOFOLLOW. Record/recheck the alias identity and target text before/after the walk. The target basename must be the exact BDF.
4. Follow no other untrusted path component implicitly. Rewalk the normalized physical PCI locator from the same sysfs anchor before/after mutations and compare the resulting directory dev/inode with the retained FD. Re-resolve/recheck the public selector alias too. If either differs or is unreadable, return changed/unconfirmed, never choose the replacement.
5. All attributes are one constant normal component opened beneath retained directories with NOFOLLOW|CLOEXEC|NONBLOCK and RDONLY or RDWR. Validate opened regular-file type, UID0, no 0022 write bits, same sysfs filesystem, and the statat-before/opened/statat-after dev/inode tuple. Use the original open FD for store/readback. No O_CREAT, O_TRUNC, chmod, chown, symlink-following child open, or fsync.
6. Reads use seek-to-zero plus `take(limit+1)` and explicitly reject excess. Suggested local limits: ordinary scalar 64 bytes, boot ID 64, PCI alias/physical locator 4096, command line 64 KiB, uevent 4 KiB, total USB directory entries 4096, non-root devices 256, and bounded traversal depth. Bounds are implementation policy, not kernel guarantees. Report a bound/error as unknown, not empty.

Root/sysfs trust does not defeat a hostile host administrator or mount-namespace substitution by a trusted privileged actor. Initial-root/mount namespace and trusted administrator assumptions remain explicit. In private test-only functions, a fixture anchor/expected UID can substitute for real roots; do not expose arbitrary roots or an owner-check bypass in production APIs.

Alternative: rustix's existing `openat2` can resolve the PCI alias beneath an anchored `/sys` using RESOLVE_BENEATH|NO_MAGICLINKS|NO_XDEV, then NOFOLLOW for ordinary descendants. Do not add a second fallback implementation unless required: supporting both makes a small security path harder to audit. The component-walk approach aligns with existing repository style. A `std::fs::canonicalize` followed by an unrelated pathname open is not equivalent to this anchored chain.

## Boot policy parsing: define a strict supported subset

The actual fixed kernel semantics matter:

- `kernel/params.c:78–100` in v6.8 maps `-` to `_` during parameter-name comparison. `usbcore.authorized-default` is therefore an alias for `usbcore.authorized_default`. Case is not normalized, and a period is not a hyphen alias.
- `parse_args` at `161–210` consumes parameters in order and stops on a standalone parameter `--` with no value. `--=x` is not that delimiter.
- Each matching occurrence invokes the integer setter. The last **successful** setter determines the value; a malformed value can leave an earlier value while recording an error. The integer setter uses base0 conversion (`215–239`), so forms such as `00` or `0x0` may evaluate to zero in the kernel. They need not be supported by this product boundary.
- `lib/cmdline.c:227–275` has double-quote handling. Kernel parsing is not shell `shlex`; shell single-quote/backslash assumptions are not safe substitutes. A simple whitespace search can mistakenly find a policy token inside another argument's quoted value.
- `init/main.c:616–671,909–919` constructs saved/static command lines, prepends bootconfig kernel arguments, and sends post-delimiter arguments to init. A token after the delimiter cannot establish the required kernel boot parameter.

Equivalent paths/functions exist in the retained v5.15 originals. These are source facts; do not copy GPL implementation into the MIT product.

For this increment, a small deliberately strict parser is safer than a partially correct shell parser:

1. Require nonempty bounded bytes, valid ASCII, no NUL. Reject unsupported control bytes. Permit the kernel's ASCII whitespace set as delimiters; do not use Unicode whitespace trimming.
2. Reject the entire command line when it contains double quotes or backslashes. It is reasonable also to reject single quotes to keep the admitted grammar explicit. This intentionally rejects some valid kernel command lines; report `unsupported_boot_command_line_syntax`, not “kernel ignored this valid option.”
3. Split the accepted unquoted subset on ASCII whitespace. Treat the first exact `--` token as the end of kernel arguments. Tokens afterward cannot satisfy or override the kernel prerequisite. The simple conservative implementation may reject any policy-looking token there; alternatively ignore all post-delimiter tokens and document this choice consistently. In either case, a policy present only after `--` fails.
4. For each pre-delimiter token, split once at the first `=`. Normalize only `-` to `_` in the **key** for recognition. Count every matching normalized policy key, including a missing/empty/invalid value.
5. Require exactly one matching key and the original entire token to be exactly `usbcore.authorized_default=0`. Thus aliases, multiple identical occurrences, conflicts, missing `=`, empty values, +0/-0/00/0x0, and trailing junk are rejected, even where Linux could accept them.
6. Read the actual pinned `/sys/module/usbcore/parameters/authorized_default` and require exactly the canonical scalar zero (`0\n`; allowing exactly `0` as a fixture convenience is a documented parser choice). Recheck it before first store and after final topology/readback checks. Do not write it. A `-1`, `1`, `2`, unknown, missing or changed value denies arming.
7. Read and validate boot ID before/after through the procfs anchor; compare to the operation's original boot. Do not log full boot command lines, which can contain unrelated sensitive arguments. Log bounded reasons and the policy observation required by the receipt.

A canonical boot token plus current runtime zero is a trusted deployment prerequisite, not attestation that no root ever changed the value. A root can switch 0→1→0 between samples. Detected drift must invalidate the observation; restoring zero afterward does not erase that interval. An explicit reconcile operation can form a new limited receipt after verifying the deployment contract, but must not silently revive the old receipt or its device leases.

Loadable usbcore is another trust limit: kernel command-line module options normally reach modprobe, but a manually overridden module load can ignore/override that historical intent. The product should state its supported trusted boot/module-loading profile and check the actual global value. These reads alone do not reconstruct the initial load history.

## Whole xHCI root set and descendants

Support the audited narrow PCI xHCI profile first: class `0x0c0330`, actual PCI driver `xhci_hcd`, root-owned physical PCI object, and exactly the complete two-root set. Driver label and PCI class are both checks; neither by itself is a generation receipt.

Fixed Linux evidence:

- v6.8 `drivers/usb/host/xhci-pci.c:601–621` creates the primary USB2 HCD then a shared HCD with the **same `&dev->dev` controller**, and adds that HCD. v5.15's corresponding sequence is `404–424`.
- v6.8 `drivers/usb/core/usb.c:692–697` assigns root hub parent `bus->controller` and name `usb%d`; non-root USB devices instead have their USB parent's device as parent (`716–717`).
- v6.8 `core/hcd.c:89,902` allocates bus IDs in 1..63 for this fixed implementation. A product may use that audited range or a separately documented bounded wider parse, but must reject ambiguous names such as `usb01`.
- Root hubs are always authorized (`core/usb.c:611–612`). Device default0 is for non-root devices; do not reject a clean root merely because its own authorized attribute is 1.
- `usb_add_hcd` initializes device default from the global parameter at v6.8 `hcd.c:2821`, sets interface default1 at `2840`, then creates/registers roots. The root-hub sysfs device-default store changes only current `hcd->dev_policy` (`sysfs.c:917`); interface-default changes the current HCD flag (`963`).

Practical enumeration:

1. Enumerate **all direct `usbN` real directories** below the pinned physical PCI directory using `Dir::read_from`, bounded and rejecting malformed candidates. Under this supported driver contract both roots share that parent. Require exactly two distinct names/dev+inode/bus numbers; 0/1/3 is incomplete/unsupported, not permission to use whichever appeared first.
2. For each root pin the directory and both attribute FDs. Verify busnum equals N, devnum1, devpath0, USB device class09 and expected root role. Role is determined by actual USB speed/version: USB2 root speed480; SS root speed5000/10000/20000 in fixed v6.8 sysfs (`sysfs.c:145–176`). **Do not infer primary from smaller bus number.** A narrower speed5000-only first product profile is valid if reported as such, but do not mistake it for all audited xHCI hardware.
3. Cross-check the kernel USB bus alias `bus/usb/devices/usbN` against the same physical root FD identity. Verify driver/subsystem associations using deliberately handled kernel links, not arbitrary following. Root-hub interfaces and USB port sysfs children are normal; don't classify all directories as unauthorized device targets.
4. Enumerate the USB devices under those roots with a bounded traversal (or a bounded global USB alias inventory cross-checked against the pinned physical ancestry). Use real device type/subsystem evidence to distinguish `usb_device`, `usb_interface`, root-hub/port metadata, and ordinary attribute directories. Resolve no arbitrary symlink subtrees. A pure filename regex that silently ignores an unexpected USB device is insufficient.
5. For every **non-root USB device**, require `authorized=0`, no active configuration/interface publication inconsistent with that, and no local interface driver. An authorized non-root device of any class is a refusal, not only storage. No force-deauthorization, unmount, reset, PCI unbind, stock usbip unbind, or “repair then continue.” A source peer or another product owner already using the controller is also a refusal.
6. The initial narrow profile can reject external-hub/nested-device topology rather than implement a recursive ownership policy. If supporting unauthorized external hubs as inert attached devices, label that exact case and still reject any already published descendants. A deep branch implies a hub was authorized at some point; current root-default0 does not erase that history.
7. Capture a sorted set of root identities and relevant child identities before writes, immediately before the first write, after each store, and at final observation. Re-enumerate the entire root set, not just known names. If roots/descendants appear, disappear, change identity or become unreadable, return changed/unconfirmed with no armed receipt. A fresh retry/reconcile must take a new complete snapshot.

Requiring stable unauthorized-device sets may conservatively reject harmless concurrent arrivals under global0; that is preferable to issuing a mixed-generation receipt. This is an availability tradeoff, not proof that every transient kernel state was sampled.

### Recommended initial arming predicate

Require existing root **device defaults already zero** as well as boot/global zero. Interface defaults may be zero or one; one is the normal new-HCD state and may be lowered to zero. A root device default1/2 indicates a policy discrepancy; do not quietly write it to zero and present prior isolation as verified. If the broader parent API deliberately permits lowering device default on an empty controller, record that as a separate explicitly weaker initial policy operation, with no historical target-isolation claim. It should not be the same “fresh boot-denied generation” success path.

For the stronger predicate, the only necessary stores are interface-default1→0 on each root. Device-default FDs can remain read-only, or fixed zero stores may be skipped because the value is already zero. Either way the helper must never write 1/2 or change the global parameter/device authorization. Final success requires both defaults zero on both roots.

## Store, readback, partial failure and owner lifetime

The sysfs store sequence should be short and explicit:

1. Authenticate UID0; validate selector and bounded input; acquire the actual operation quota and controller mutation ownership.
2. Open all anchors, PCI/root/attribute FDs; read boot/global prerequisites and full current topology; validate the durable administrator intent. Reject all preconditions before writes.
3. Persist the prepared operation identity through the helper's existing durable store before first sysfs side effect. Retain the same actual blocking owner while committing/readback completes.
4. Recheck original boot/global/PCI/driver/root set/descendant state immediately before first store. For each permitted nonzero interface default, seek the original FD to zero and call `write(b"0\n")` once. Require return2. A short write or Interrupted/error may have effects: do not write the suffix, reopen a path and retry, or claim no mutation.
5. Seek/read the same FD and require the exact zero value. Verify all original attribute identities against the current pinned parent entries, then the whole controller/boot/global/topology again. If any check fails, preserve any achieved denial and record a partial/unknown outcome; never roll back to an allow value.
6. Commit the completed observation only after these checks. If that durable write is uncertain, return Unconfirmed and preserve the original operation identity for query/reconciliation. A successful sysfs readback is not evidence that the durable completion was committed.
7. Actually finish/join the owner and release its lock/permit only when all accepted operations are done. Dropping the RPC future or reaching a soft timeout does not cancel a blocked sysfs or fsync call. No synthetic “cleanup verified” based on a new helper/process.

Pre-opened sysfs FDs protect the **target** of a store from alias replacement; they do not pin an HCD as the current active controller indefinitely. If a root is removed/recreated, the old FD belongs to the old generation. Never use its readable metadata, success/failure, dup, or close as proof that the new HCD is armed or that an old USB data owner ended. Any fresh open during reconciliation produces a new current-generation receipt; retain unresolved old device/session records independently.

No kernel-wide transaction holds the global parameter, PCI topology, two HCD defaults and daemon WAL stable across all these operations. The helper mutation lock serializes cooperating product callers. External privileged changes remain outside prevention guarantees and invalidate any observed current receipt. The final state is a bounded checked observation, not a perpetual hardware grant.

## Meaningful negative tests

These tests are proposed, not run by this agent. Keep filesystem parser/identity tests separate from actual QEMU/sysfs results. Private fixture injection at named boundaries is sufficient; don't add a generic mock framework.

### Pure input/boot tests

- Canonical BDF edges and all rejected path/format/range cases above; serde deserialization must use the validated constructor, not bypass it.
- Accept a simple pre-delimiter `usbcore.authorized_default=0` plus ordinary unrelated tokens; accept it before a trailing `--` under the documented policy.
- Reject missing flag, only post-`--` flag, `usbcore.authorized-default=0`, alias conflict after canonical0, two canonical0 values, canonical0 plus canonical1, missing `=`, empty value, `00`, `0x0`, +0/-0, and suffix junk.
- Reject quoted-value and whole-token quoted forms, a policy-looking string inside another quoted argument, unmatched quote, NUL/nonASCII/oversized command line. These are explicitly unsupported grammar, even if Linux accepts some.
- Verify `--=x` is not treated as the delimiter, and a key with a different period/case is not silently normalized into the real key. A canonical key appearing only in another token's value does not count.
- Boot parser passes but runtime global is1/-1/2/invalid/missing/oversized → no store. Runtime global0 without boot evidence → no store.

### Filesystem/ownership/topology tests

- Reject wrong filesystem magic, non-root owner, group/other-writable ancestor, symlinked ordinary component/attribute, FIFO/device/socket attribute, missing attribute, and oversized value. Test-only fake roots must never be injectable through a production request.
- PCI alias escape, wrong physical basename, changed alias between readlink/walk, same-looking replacement with new inode, foreign PCI class/driver/vendor contract, and PCI removal/rescan all fail without writing the replacement.
- 0/1/3 roots, duplicate busnum, same directory aliased twice, malformed usbN, wrong parent/busnum/devnum/devpath/class/role, unexpected nested USB device, and read/enumeration failure are refusal/unknown, never empty success.
- Clean root authorized1 is accepted; any non-root authorized1 is refused before writes, regardless of storage class. Root-hub interface/port metadata is not falsely treated as a non-root USB target.
- Missing shared root at first snapshot, newly arriving shared root later, root set changed during enumeration, or same names with different inode after HCD replacement → no success.
- Every current root device default must meet the selected initial predicate; interface1→0 is the intended store. An unrelated controller's files stay byte-identical.

### Actual mutation-boundary tests

- Swap PCI/root alias immediately after final pre-store check: only the retained original attribute may be changed, replacement stays unchanged, final result cannot be success.
- Replace an attribute itself after open; either write affects the original fixture object or fails, but final identity mismatch must prevent success.
- First interface store succeeds; second store fails/short-writes/is interrupted/readback differs. Record partial/unknown; first root remains denied; never restore1 or return both armed.
- Assert exactly one `write` call on short/error. Test real readback length/type checks rather than simply mocking a returned “success” boolean.
- Global parameter or boot ID changes at pre-store/post-store hook → refuse before store or partial/unknown afterward, with no replacement receipt.
- Actual blocking worker remains held after caller cancellation/EOF; a conflicting operation cannot enter until the original worker completes. Shutdown waits the real owner.
- Persist-prepared fails → no sysfs store. Persist-completed fails after verified stores → unknown durable outcome with same operation identity, no rollback/automatic new UUID.

### Real QEMU acceptance to pair with these tests

Use the already validated E67 dedicated guest controller and boot0 profile; both Ubuntu source versions must be exercised if both are claimed. Require actual product API/installed ELF evidence, real two-root0/0 readback, original owner completion, and unchanged unrelated controller. Recreate the fixture HCD: same PCI object plus replacement root identities must invalidate the old product receipt; new interface defaults1 can be re-armed only by explicit checked reconciliation. A fresh boot requires a new helper/boot receipt. In a separate authorized negative, set runtime global1 while boot text stays0 and require product refusal without restoring it or altering devices. Preserve any existing storage-export rejection; stock Native I/O under product-established controller denial is a split mechanism regression, not integrated RustUSB storage support.

## Provenance and limits

`manifest.json` records the exact baseline Git blobs and SHA-256, selected reused E67 Linux originals with their source URLs/fixed commits/original receipt hashes, and the locked local rustix source/license files. No sources were downloaded again. Fixed Linux identities remain v5.15 `8bb7eca972ad531c9b149c0a51ab43a417385813` and v6.8 `e8f897f4afef0031fe618a8e94127a0934896aba`; their COPYING/GPL originals are retained. Existing E67 fetch failures remain in the reused receipts when present; the source-capture script's first failed attempt selected a failure row without a hash, was corrected to select a successful receipt, and is recorded in `method-notes.txt`.

Primary links: [v6.8 kernel parameter parsing](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/kernel/params.c#L78), [command-line tokenization](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/lib/cmdline.c#L227), [xHCI two-HCD construction](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/host/xhci-pci.c#L601), [root USB parent assignment](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/usb.c#L692), [HCD defaults](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/hcd.c#L2821), [per-HCD default stores](https://github.com/torvalds/linux/blob/e8f897f4afef0031fe618a8e94127a0934896aba/drivers/usb/core/sysfs.c#L917).

The upstream originals are not asserted byte-identical to Ubuntu downstream kernels. No new runtime result, release acceptance, USBFS revocation, general storage handoff, power-loss guarantee or hardware support follows from this review.

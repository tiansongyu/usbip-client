# E68 initial Native implementation review

Reviewed the uncommitted `crates/rustusb-native/src/controller.rs` and `controller/tests.rs` supplied by the parent. Exact input bytes are saved under `implementation-originals/` and hashed in `implementation-review-inputs.json`. Review is read-only: no repository modifications, compilation, test execution, QEMU or host device/process inspection. Parent reports its initial fixture-permission failure and subsequent five-test pass; those are not reclassified or counted as reviewer executions.

The current implementation has a sound basic store target: NOFOLLOW attribute opens, original-directory handles, writer-vs-original dev/inode comparison, one `write(b"0\n")`, same-writer readback, and no allow-value rollback. The important remaining problems are the prepared-state contract, snapshot completion, trust-chain revalidation, and root-interface ownership. This review does not assert that an unprivileged process can mutate real kernel sysfs topology; permission/alias findings below concern the stated fail-closed trust contract and observable administrator/topology changes.

## Findings

### R1 — arm can mutate without a successful explicit prepare; a failed prepare leaves usable state

Priority: **P1**, API/state-machine correctness. Locations: `controller.rs:214`, `269–279`, `291`.

`pin()` sets `initial=Some(observed)` as soon as open succeeds. `arm()` treats that value as prepared and calls `prepare` itself using the selector/boot it captured. Consequently:

1. `open(address)` followed directly by `arm()` can write defaults without any explicit successful `prepare(expected_selector, expected_boot)`.
2. `prepare(wrong_selector, boot)` or `prepare(selector, wrong_boot)` returns an error without clearing the earlier `initial`. A later `arm()` silently chooses the originally observed selector/boot and can write anyway.
3. `arm()`'s internal successful `prepare` replaces `initial` **before** its equality check at line279. If that later check fails because state changed, the failed arm has still changed the next retry's baseline. A caller can get a different result on the next arm without a new explicit prepare. This is especially confusing after a partial prior arm.

This is not a claim that the existing correctly written daemon caller necessarily continues after a prepare error; the public Native API currently permits it, contrary to its preparation contract. Prepared state also cannot by itself prove the helper's durable intent was committed: the helper must retain its own prepared/WAL gate.

**Fix:** distinguish the initial observation from `prepared: Option<Inspection>`. Start with no prepared value. Clear prepared at the beginning of every `prepare`, then set it only after all expected-selector/boot/preconditions pass. `arm` should `take()` the original prepared value and perform pure revalidation against it; do not call the state-mutating prepare method internally. On any arm failure, require explicit preparation/reconciliation before another mutation attempt. The helper determines whether that is permitted under the original durable operation identity.

**Meaningful tests:** direct open→arm fails with both interfaces unchanged; failed selector/boot prepare followed by arm fails; successful prepare followed by failing prepare does not retain the earlier grant; failed pre-store equality check does not silently establish a new baseline; failure/partial store cannot re-enter arm without explicit new preparation.

### R2 — observe returns before its original boot/global/root/arrival snapshot is sealed

Priority: **P1**, stale success during an in-flight lifecycle change. Locations: `controller.rs:225–264`, `281`, `289–290`.

`observe` reads boot/global at its start, then validates PCI/root names, then visits roots in sequence. It returns immediately after collecting arrivals. There is no trailing recheck of the original anchors, PCI/root set, original attributes, original arrival identities, or boot/global values. The final arm check therefore treats early observations from that final scan as if they were a completed after-observation.

Concrete source-derived schedule: during the final `observe` called at line289, root A's identity/defaults are read; then root A is removed/replaced while root B is being read. If root B's reads still complete, the returned data still contains A's old zeros and the comparisons at line290 pass. The analogous gap exists for runtime global0 read at the start and changed before the scan completes. Real HCD teardown has multiple steps, so a complete-two-root before-snapshot is not a complete-two-root after-snapshot.

This is a missing bounded consistency check, not a demand for impossible atomicity against every change immediately after return. Even a corrected implementation must expose a checked observation, not claim perpetual authority.

**Fix:** before returning, revalidate the same retained anchors and full current PCI/root name+dev/inode set, original attribute identities, and collected arrival identities/allowed owner state against the pinned physical parents and bus aliases. Re-read boot/global and require equality with the beginning of this observation. Make the operation's actual finalizer perform this check after all root reads/stores; do not infer it from an early read inside the same scan. A changed/disappeared object yields changed/unconfirmed, with no armed receipt. Preserve the original worker/partial-outcome rules.

**Meaningful tests:** add a narrow test-only hook after the first root is captured or just before observation finalization; replace/remove that already captured root, add an extra root, replace an arrival, and change the global parameter. All must deny completion, while the retained FD targeting test remains separate. These are fixture consistency tests, not claims of real kernel-race execution.

### R3 — the complete trusted alias/ancestor chain is checked only during initial opening

Priority: **P2**, trust-chain/permission drift acceptance. Locations: `controller.rs:167–194`, `225–241`.

The `_pci_aliases` and `_usb_aliases` handles are local to `pin` and are dropped when it returns. `resolve` and subsequent checks use pathname `canonicalize` / `identity_path`, which follow intermediate symlinks. `observe` rechecks PCI/root directory permissions and opens attributes through retained parents, but it does not rewalk or revalidate all original `bus/pci/devices`, `bus/usb/devices`, physical PCI ancestors, or sys/proc anchor permissions. `boot` checks mountpoint dev/inode only, not their current trusted metadata.

A deterministic filesystem fixture can replace `sys/bus/pci/devices` with a symlink to an alternate directory whose BDF alias still points at the original PCI object; later identity comparisons still succeed. Likewise, chmod of a physical ancestor to group/other-writable preserves object identities and is not rejected by the current observations. The same-generation store remains aimed at its retained original attribute, so this is **not** a demonstrated store redirection to a replacement device. It does mean the declared NOFOLLOW/complete trusted-ancestor invariant is no longer checked at use.

**Fix:** retain or reconstruct the trusted directory chain from the original sysfs/procfs FD and validate it before and after an observation/store phase. Every ordinary component must be reopened with NOFOLLOW and compared to its original dev/inode/type/owner/mode. Deliberately resolve only the known kernel PCI/USB/driver alias components through checked alias directories; do not let arbitrary intermediate symlinks become implicitly accepted. Recheck anchor metadata as well as dev/inode. A small private chain verifier is sufficient; this does not require a generic FS abstraction.

**Meaningful tests:** after prepare, replace each alias directory or physical ancestor with a symlink leading to the same original object; chmod/alter fixture-owner metadata on sys/proc and an intermediate physical ancestor. Arm/inspect must reject as specified, and the replacement attributes must remain unchanged. Keep initial symlink-attribute tests, but they do not cover this ancestor case.

### R4 — root-hub interface is skipped wholesale, so an abnormal root-interface owner is invisible

Priority: **P2**, incomplete topology/owner rejection. Location: `controller.rs:247–260`.

The exact `{bus}-0:1.0` entry is skipped before even checking its type, existence contract, interface class or bound driver. Root authorized1 and its normal hub interface must be allowed, but the implementation currently also accepts an absent/unbound root interface or one with a different owner such as USBFS. The controller/root directory and defaults can still satisfy the remaining checks. An active or unexpected owner of the root hub interface is therefore not represented by the “non-generic USB owner blocks enrollment” test, which only runs for direct non-root arrivals.

Other entries that do not start with the current `{bus}-` prefix are ignored without checking whether they describe an unexpected USB device/interface. For fixed normal Linux topology the valid device names follow that prefix, but the implementation promises to reject unknown topology rather than assume every ignored entry is harmless.

**Fix:** explicitly validate the expected root interface under the pinned root: normal directory, current parent identity, expected hub class09, trusted current `hub` driver association, and allowed normal port metadata. Distinguish ordinary sysfs support directories from USB device/interface objects using their kernel metadata; reject unexpected USB objects rather than silently skipping them by name. Do not recursively reject legitimate `power`/port metadata or classify the normal root authorized1 as an unsafe non-root target.

**Meaningful tests:** give root interface realistic fixture metadata; remove it, make it a symlink, change its class/driver to a non-hub owner, and add an unexpected USB-marked object outside the accepted naming/layout. These must fail without stores. Keep a positive fixture with normal hub interface/port children.

## Existing owner boundary that must be handled in the daemon

This Native module correctly rejects visible direct non-root targets with authorized1, non-generic device driver, published interface directories, block descendants, and downstream hubs. An unauthorized target still bound to `usbip-host` is refused by the current driver check. No defect is claimed for that normal visible-owner case.

It cannot establish absence of an existing **product** owner that is still prepared, has not bound a kernel driver, or is represented by an unresolved prior journal. A generic-bound unauthorized device can coexist with such pending metadata. The daemon needs to serialize enrollment with the same existing mutation domain (`App.state`, whose baseline comment says it serializes helper mutations), and check relevant Native active registrations/intents, physical actual handoffs, and unresolved durable records before preparing/arming. `App.native_exports`, `App.native_state`, and the physical journal/handoffs are distinct structures; an empty kernel snapshot or PID death cannot substitute for them.

Map scope using retained generation/controller ancestry where recorded; old USB bus number alone is not a stable controller selector. If an unresolved legacy record cannot safely be excluded from the selected controller's scope, return a conservative conflict/unknown rather than dropping it or declaring recovery. Keep fixed lock ordering and avoid holding a store mutex across arbitrary blocked sysfs calls; the actual operation still needs a mutation owner covering the safe sequence.

External or already-delegated USBFS FDs remain a separate E67 deployment-policy limitation. No root-interface check or daemon journal scan turns this controller receipt into general USBFS revocation or storage release proof.

## Additional checks and accurate limits

- PCI address parsing short-circuits before slicing invalid/non-ASCII input; no panic path was found there in this review. Canonical slot/function bounds and serde validation are present.
- Boot parser intentionally rejects quotes/backslashes/control whitespace and treats only literal space as delimiter. This is a strict supported subset, not full kernel parsing. It recognizes hyphen/underscore key aliases and rejects duplicate/noncanonical policy values before the true `--` delimiter. Its acceptance of canonical0 before `--` and ignoring later policy-like init arguments matches the documented choice. Do not label the tab rejection a kernel behavior.
- Attribute writers are newly opened from the retained root and compared with the original attribute FD identity. That is a useful check. Current tests only replace attributes before `arm`; add a last-moment hook after writable open to verify actual FD-target behavior and final mismatch rejection.
- Current writes include `authorized_default=0` even though prepare requires it already0. This is redundant but stays inside fixed-denial scope. Skipping that store reduces side effects and failure points; it is not a safety blocker by itself.
- `Inspection` is metadata and the module does not claim to authorize callers. The daemon must check root UID before reads/quota and must retain the actual blocking owner. Public Native methods should document that requirement consistently rather than duplicate a separate authentication layer.
- Five tests aggregate several cases, but do not cover prepare bypass, failed-prepare invalidation, final-scan mutation, complete ancestor drift, last-moment writer targeting, interrupted write, or abnormal root-interface ownership. Add these targeted invariant tests; no broad random test expansion is requested.
- No claim is made here about downstream-kernel compatibility, QEMU success, persistence or safe media ownership. Fixes need the parent's normal software gate and actual guest validation with original failures retained.

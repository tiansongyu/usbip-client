import pathlib,json,hashlib,subprocess,shutil
out=pathlib.Path('/tmp/rustusb-controller-enrollment-linux-20261026');repo=pathlib.Path('/home/ubuntu/github/usbip-client')
base=subprocess.check_output(['git','rev-parse','0c3dd04c'],cwd=repo,text=True).strip()
repo_paths=['Cargo.toml','Cargo.lock','crates/rustusb-native/src/import_power.rs','crates/rustusb-native/src/import_power_tests.rs','crates/rustusb-native/src/channel.rs','crates/rustusb-native/src/export_channel.rs','crates/rustusb-daemon/src/physical.rs','crates/rustusb-daemon/src/native_state.rs','crates/rustusb-daemon/src/storage.rs','crates/rustusb-daemon/src/native_export.rs','crates/rustusb-daemon/src/physical_lifecycle.rs','crates/rustusb-logging/src/storage/linux.rs','crates/rustusb-linux/src/storage.rs','docs/research/storage-controller-enrollment-design.md','docs/research/storage-controller-enrollment-validation.md']
rows=[]
for p in repo_paths:
 b=subprocess.check_output(['git','show',base+':'+p],cwd=repo);d=out/'project'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 rows.append({'kind':'project','commit':base,'path':'project/'+p,'git_blob':subprocess.check_output(['git','rev-parse',base+':'+p],cwd=repo,text=True).strip(),'sha256':hashlib.sha256(b).hexdigest()})
old=pathlib.Path('/tmp/rustusb-storage-policy-linux-20261026');manifest=json.loads((old/'manifest.json').read_text())
paths=['kernel/params.c','lib/cmdline.c','init/main.c','drivers/usb/host/xhci-pci.c','drivers/pci/pci-sysfs.c','drivers/usb/core/hcd.c','drivers/usb/core/sysfs.c','drivers/usb/core/usb.c','drivers/usb/core/devio.c','drivers/usb/core/generic.c','Documentation/usb/authorization.rst','COPYING','LICENSES/preferred/GPL-2.0']
usbfs=pathlib.Path('/tmp/rustusb-storage-policy-usbfs-20261026');um=json.loads((usbfs/'ORIGINALS.json').read_text())
for ver in ['v5.15','v6.8']:
 for p in paths:
  original=old/'sources'/ver/p;entry=next((v for v in manifest['sources'] if v['version']==ver and v['path']==p and 'sha256' in v),None)
  if not original.is_file():original=usbfs/f'linux-{ver}'/p;entry=next((v for v in um if v['path']==f'linux-{ver}/{p}'),None)
  if not original.is_file() or not entry:raise RuntimeError((ver,p))
  b=original.read_bytes();actual=hashlib.sha256(b).hexdigest()
  if actual!=entry['sha256']:raise RuntimeError(('hash mismatch',str(original)))
  d=out/'sources'/ver/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
  rows.append({'kind':'reused-fixed-linux','path':str(d.relative_to(out)),'reused_from':str(original),'sha256':actual,'original_receipt':entry})
for p in ['src/fs/openat2.rs','Cargo.toml','LICENSE-MIT','LICENSE-APACHE']:
 original=pathlib.Path('/home/ubuntu/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustix-1.1.5')/p
 if not original.is_file():continue
 b=original.read_bytes();d=out/'rustix-1.1.5'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 rows.append({'kind':'locked-local-crate-source','path':str(d.relative_to(out)),'version':'1.1.5','registry_checksum':'891efababe418670775f199f0d233d84843c227a0949a883ce15b37c78d6629d','reused_from':str(original),'sha256':hashlib.sha256(b).hexdigest()})
(out/'manifest.json').write_text(json.dumps({'baseline':base,'method':'Only git-show snapshots, existing E67 fixed source originals and locked local crate source; no network download/build/host device/process inspection.','files':rows},indent=2)+'\n')
print(base,len(rows))

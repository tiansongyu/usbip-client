# E68 controller implementation review

Reviewed commit: `b7ff08f267aeda14f9de0575b647d688e2948a79`.

Method: read-only source review of the committed controller service/store, CLI/helper dispatch, Native export scope helpers, Linux conflict integration, and the controller source methods called by those paths. All reads used the fixed commit for the review. No repository edits, build, test execution, QEMU, or host USB/block/module/service operation was performed. This review does not certify the parent's concurrently running software gate or later commits.

## Finding requiring correction

### Default helper builds omit existing physical grant ownership from controller admission

Relevant code:

- `crates/rustusb-daemon/src/lib.rs:31-33`: the controller module is available on Linux independently of `physical-usb`.
- `crates/rustusb-daemon/src/linux.rs:1377-1389`: controller state is enabled whenever the explicit controller-state option is present.
- `linux.rs` physical journal initialization remains under `#[cfg(feature = "physical-usb")]`; the non-feature path merely ignores `physical_state`.
- `linux.rs:2184-2201`: the physical-owner part of `controller_conflicts` is also compiled only with `physical-usb`.

Consequently, a default Linux helper can accept controller operations without even checking whether the configured physical state directory contains unresolved grants left by an earlier helper built with `physical-usb`. Disabling the current adapter does not revoke previously delegated USBFS descriptors or remove their durable owner records. The selected-controller preflight may see an unauthorized/generic target and no local driver, but the purpose of the new scope check is explicitly to reject retained owners even in that state.

A reproducible integration setup is:

1. Use a helper with `physical-usb` to create an unresolved grant and its legitimate physical journal. Preserve the original grant/record; a current target may subsequently be deauthorized while its prior writable descriptor remains separately held, as distinguished by E67.
2. Stop that helper and start a default-feature helper using the same `--physical-state-dir` and an explicit `--controller-state-dir`.
3. Satisfy the new controller's ordinary boot/topology prerequisites and request enrollment/reconciliation of the source controller.
4. The default build never loads the existing physical journal and never invokes `contains_physical_generation`. The retained physical owner does not participate in the decision. This follows directly from the `cfg` branches; no new runtime reproduction was executed in this review.

A focused software regression does not need real USB: create an existing controller-independent physical-state path in the startup fixture, compile the default branch, and assert that opting into controller management refuses initialization before opening/creating controller state. With the feature enabled, existing scope fixtures can demonstrate that a selected-controller physical record reaches the conflict check.

Minimal conservative fix: when `controller_state` is supplied and `physical-usb` is absent, check the configured physical-state path with `symlink_metadata`. Any existing path, or any observation error other than genuine NotFound, must refuse controller feature startup with an explicit message requiring a helper capable of reading/reconciling the physical journal. Do not delete, reset, or assume an empty directory is safe. Perform this check before creating the controller store. A larger alternative is to make read-only physical journal scope support independent of the adapter feature; this is unnecessary for the narrow fix.

The limitation is owner accounting, not a demonstrated storage data-loss exploit: this increment still writes only denial defaults and supplies no product USB storage admission. Nevertheless, the implementation contract currently claims original physical owners are checked, and the default build violates that contract.

## Ownership and persistence paths inspected

The following paths match the intended contract at the reviewed commit; these are source conclusions, not fresh test results.

- `controller.rs:502-550`: root mutations acquire the sole controller permit and an owned common helper mutation guard. `run_owned` moves both into the actual blocking closure. Dropping the waiter cannot drop that closure's guard/permit. There is no timeout or abort around accepted kernel/filesystem work. The 30-second timeout applies only to acquiring the mutation guard.
- The existing helper request `JoinSet` is unchanged and waits accepted requests during shutdown. Controller service dispatch awaits its worker before responding. This retains the existing permanently blocked syscall limitation; it does not create a cancellation or USB release proof.
- `controller.rs:373-384`: a retained request is checked before CAS; selection and pinned controller preparation are read-only; owner conflicts are checked before `Store::begin`. No fixed-zero sysfs write precedes the durable Pending commit.
- `controller.rs:394-414`: arm/retire work follows Pending. A successful completion must be durably committed before the pin enters `inner.pins`. Kernel failures can leave partial denial, and the failed outcome is separately recorded; there is no write-1 rollback.
- `store.rs:114-164`: protected-file operations, retained flock, exact cached bytes, inode checks, temporary sync, rename, directory sync, and final destination identity checks are separate from the USBFS/Native disk schemas. I/O/rename/sync uncertainty poisons the store; a failed commit does not install a new committed cache. Predictable validation/size errors before the transaction do not themselves poison the store.
- `store.rs:247-256`: Pending encoding reserves 4 KiB before any sysfs side effect. The completed observation stores exactly two bounded root observations and no arrival list. The existing completion-size test samples the expected form; it does not constitute a proof about every future schema extension.
- `controller.rs:313-320,345-357`: restart publishes the loaded disk as historical, generates a new helper epoch, and creates no current pins. A poisoned store clears published verified IDs and marks the writer unconfirmed without presenting its candidate as a committed new state.
- `controller.rs:332-359,469-485`: list/query use a separate short in-memory view lock, not the store lock or disk reads. The view lock is not held across fsync/sysfs work. Retained results are explicitly historical, absence is unknown/expired rather than no effect, and the reply states `current_kernel_authority:false`.
- A query of a reopened Pending record can show `writer:idle` and `settled_writer:true`; the record's outcome remains Pending. The current field means only no in-process writer, not a settled mutation. Consumers and documentation must retain this distinction. Renaming it `writer_idle` would reduce ambiguity but is not required for correctness if that meaning remains explicit.
- `store.rs:166-181`: retained UUID replay compares the full `Change`, including policy ID, expected revision, and operation payload. Changed input fails. Exact replay returns historical data without rerunning the conflict or kernel callback, including a Pending result after restart.
- `store.rs:183-257`: new requests require the global revision; `checked_add` rejects exhausted revision before sysfs writes. Retired slots retain history, and re-enrollment advances global revision. Forgotten original payloads have stale expected revisions. The implementation does not promise detection of arbitrary reuse of a forgotten UUID with new input, matching the documented retention boundary.
- `controller.rs:380-401`: retirement requires the controller to remain empty and matching. It writes no allow value, does not retire original Native/physical grants, and supplies no broker cleanup proof. Its stronger empty-controller precondition is documented.

## Owner scope integration inspected

- `native_state.rs:284-292` adds `export_scopes` over `self.exports` only after `healthy()`. It includes registering entries with `bound == None`. It does not include Native import records.
- `native_export.rs:343-350` copies original paths from the actual Registry, without filtering failed/closing entries or acquiring live capability locks. Together with the durable table this covers the short durable-retired/actual-registry-not-yet-removed interval conservatively.
- `linux.rs:2150-2183` takes Native/registry metadata, checks original paths with the pinned controller, and separately checks saved legacy export topology. It never examines `ManagedState.ports`, `released_ports`, or Native import records to block a physical source controller.
- `controller.rs` in `rustusb-native`, lines 948-982, uses path components and the original USB-root boundary. It does not map an old Native owner through a replacement BusID. Well-formed paths under a different original controller compare false; malformed scope is an error.
- The physical scope helper at `rustusb-native/src/controller.rs:818-865` requires same boot, exact saved sysfs dev/inode, fixed BusID alias identity, canonical path, and saved bus/address. It does not use export eligibility or the current USBFS node to erase an owner. A verified other controller returns false; missing/replaced/old-boot scope returns the explicit unknown-historical-scope error. This is the correct conservative behavior for the old schema that omitted controller paths, when that helper is actually compiled and called.
- Store/registry locks are taken separately, copied metadata is used outside those locks, and the outer actual mutation guard remains held. No new cross-store lock nesting is apparent in this path.

The default-build omission above is the exception to this otherwise deliberate integration.

## CLI and helper dispatch inspected

- Helper `--controller-state-dir` is optional and administrator-only. Existing public serve wrappers pass `None`; the new wrapper accepts the option. The RPC contains no state path, file name, shell command, attribute name, or arbitrary value.
- The new request is represented in public `Request`, strict `RequestWire`, and their conversion. `Command::List {}` uses an empty struct variant and the added wire test rejects extra fields.
- `linux::serve_connection` uses kernel peer credentials and routes the controller command directly. `controller::handle` rejects `uid != 0` before inspecting the feature option or taking work permits. Existing ordinary/broker socket authorization does not grant controller access.
- The CLI constructs an explicit policy/request UUID and global expected revision from caller arguments. It does not silently generate a replacement UUID after an uncertain response. Selector parsing has a 1 KiB CLI bound and uses the strict typed selector. The actual daemon still applies its framed and typed validation independently.
- CLI output is the existing response envelope; a successful transport/query envelope must not be interpreted as an Armed result when its nested retained outcome is Pending or Failed.

## Validation coverage to keep explicit

The added tests are meaningful source examples: retained Pending replay, CAS identity mismatch, revision preservation across retire/re-enroll, protected state failures, before/after-rename completion failure, actual guard/permit retention after waiter abort, strict wire, and restart of Pending state.

The following are not demonstrated by those new unit tests alone and should be covered by targeted product integration/QEMU assertions or kept explicitly unverified:

1. The default-helper/old-physical-journal case above, including refusal before controller-state initialization.
2. Restart from a successfully Armed disk result: different helper epoch, empty current pins, exact old replay remains historical and does not open sysfs.
3. Query responsiveness during a real gated persistence operation and while the actual mutation guard remains held; the queried view must stay Pending/InFlight or Unconfirmed as appropriate.
4. A root/nonroot/secure-broker matrix through the actual socket controller dispatch, proving nonroot attempts invoke neither the store nor kernel work.
5. Controller conflict integration with a Native registering export, a known-other Native export, import-only Native state, actual-registry-only metadata, and exact-selected/known-other/unknown physical generations. Component helper tests alone do not show that every service branch calls them.
6. A final persistence failure after successful arm through the actual service, showing no pin publication and a queryable unconfirmed writer; current Store fault tests do not execute the complete service-to-kernel sequence.

These are coverage limits, not additional source-proven defects. No test counts or PASS claims are made by this review. Product enrollment remains a prerequisite layer; target storage admission, checked data/flush/release, USBFS race closure, and full hardware/Phase 0-7 completion remain outside this increment.

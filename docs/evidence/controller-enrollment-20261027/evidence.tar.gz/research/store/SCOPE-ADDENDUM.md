# E68 addendum: controller scope of existing export and USBFS owners

Read-only follow-up at the same reviewed base `0c3dd04cce607e7255382b266ca120a85535c8d8`. No repository edit, build, test, QEMU, or host device action was performed. Seven further exact source snapshots were added to the source manifest. This addendum does not review the parent's concurrent new implementation.

## Finding

An unauthorized current device and an empty local-driver list do not prove the selected controller has no outstanding RustUSB owner. The check must union current helper export ownership with unresolved durable **export** and USBFS grants before preparing a controller intent. An original Native registration exists before bind, so `bound == None` is not an absence of ownership.

Native durable/live export records already contain the original canonical sysfs path. USBFS physical records do not contain the historical path or controller. Their original controller can be recovered from current sysfs only if the exact saved device generation remains present and is checked before and after the lookup. When that generation is absent or replaced, the old schema cannot recover its controller. This gap must be represented explicitly; neither a hash fingerprint nor an old BusID can reconstruct the missing historical path.

Native **import** records are local VHCI receive-side ownership and are not source-controller exports. Do not block every physical source controller merely because `native_state.records`, `ManagedState.ports`, `released_ports`, or an unrelated import intent is nonempty.

## Exact fields and lifecycle windows

| Owner source | Existing source and fields | Correct selected-controller use |
| --- | --- | --- |
| Durable Native export, including registering/unbound/stub phases | `native_state.rs:119-129` `ExportRecord.registration`; `export_channel.rs:27-56,86-99` `RegistrationSnapshot.generation.sysfs_path`, filesystem identity, BusID and address | Match the original path's controller components against the selected canonical PCI function. Include all `exports`, irrespective of `bound`, `stub`, owner process liveness, current drivers, or current USB authorization. |
| Actual Native export/stub capability | `native_export.rs:342-355` `Registry -> Live.registration`; the `State.capability` and stub slot belong to this same source registration | Read a short metadata snapshot of each original registration. Include closing/failed entries. Do not lock live capability state or inspect payloads just to classify controller scope. |
| Legacy helper export | `linux.rs:32-40` `ManagedState.exports: HashMap<String, Device>`; `core/lib.rs:237-240` `Device.topology`; `linux/lib.rs:475-490` topology encoding | The saved topology is the original controller path followed by `/ports/<chain>`. Parse this form by path components; match its controller portion. Do not reread the current BusID and silently attach the old entry to a replacement. |
| Durable physical grant | `journal.rs:55-70,122-136` `Record.baseline`; `core/lib.rs:255-272` `PhysicalDeviceReceipt` | Stored values are fingerprint, BusID, sysfs device/inode, bus/address, usbfs node identity, configuration/interfaces. No stored controller path exists. Use exact generation recovery when possible; otherwise report unknown historical scope. |
| Actual physical handoff | `linux.rs:120-136` `Handoff`, `HandoffTracking`; `physical.rs:25-36` `PhysicalGrant.device` and `.receipt` | A current handoff has an in-memory original `Device.topology`, but the central `handoffs` registry currently stores only lease IDs. Durable grant reservation precedes insertion and delivery, so the physical journal covers ordinary handoffs while present. A tiny metadata scope entry can improve direct actual-owner inspection without changing disk schema. |

The public Native `pending()` page (`native_state.rs:635-670`) drops registration paths and mixes imports with exports. It is a presentation API, not the right internal source for a scope check. `Store::snapshot()` (`native_state.rs:592-596`) is test-only and returns imports, not exports. `journal::Store::records()` (`journal.rs:914-918`) already returns the bounded physical records after `healthy()` and can be reused.

`RegistrationSnapshot::capture` records the original generation before `reserve_export`; the store reserve precedes pre-bind revalidation and the tool bind (`native_export.rs:382-432`). A prepared old export can therefore have no bound receipt while its durable ownership must still block re-enrollment. The actual registry is populated later (`native_export.rs:514`) and removed after cleanup returns (`native_export.rs:523-525`). During cleanup, durable retirement occurs inside the common mutation guard (`native_export.rs:562-591`), while registry removal happens just afterwards. Checking both durable and actual registries covers this short interval conservatively.

## Small maintainable internal helpers

Recommended additions are narrow read-only helpers, with no schema or public wire changes:

1. `native_state::Store::export_scopes(&mut self) -> Result<Vec<ExportScope>>`: call `healthy()`, then return bounded metadata from **only** `self.exports`. Each scope needs lease ID, owner boot, and original `registration.generation.sysfs_path`; optionally retain original sysfs identity for diagnostics. It does not need the full remote descriptor or original interface list. Do not return direct mutable references to the store.
2. `native_export::Registry::export_scopes() -> Result<Vec<ExportScope>>`: briefly lock the registry and copy the same original fields from `Live.registration`. Do not exclude `closing`, `failed`, a busy stub, or entries whose durable record was just retired. Avoid acquiring each `Live.state` lock; scope is immutable metadata.
3. `ManagedState::legacy_export_scopes()`: called while the existing actual owned mutation guard is already held; derive the controller component from each saved `Device.topology`. This method does not examine import maps. Unknown/malformed topology is explicit unknown, not an empty scope.
4. Under `physical-usb`, use `journal::Store::records()` to copy at most the already bounded grant count. Add a small metadata-only physical-generation helper rather than reuse the complete baseline/restoration helper. Optionally change the in-memory handoff registry from lease ID to `{lease_id, original_controller_path, original_generation}`; this has no disk schema impact and must retain its entry until the actual handoff FD has closed, preserving the current field-drop order.

Take each store/registry snapshot and drop its short lock before acquiring another lock or doing kernel filesystem work. Do not introduce nested Native-store, physical-store, or live-capability lock ordering. The actual common `app.state` mutation guard covers the whole conflict check, controller intent commit, and controller arm operation. It serializes the existing producer and retirement paths. A store health error/poison cannot be treated as an empty owner table.

The query/inspection API may return a bounded projection of these conflicts, but controller mutation must use the actual healthy stores and current checked metadata, not the separate historical cached query view proposed in the main report.

## Matching Native and legacy saved scopes

The selected PCI controller must first have been resolved and verified by the Linux controller component. Use its canonical `/sys/devices/.../<PCI function>` path as a typed internal input; never accept an RPC-provided arbitrary prefix.

For a saved Native canonical device path:

- Compare `Path` components, not a string substring or textual BDF occurrence. `/0000:00:05.0` must not match `/0000:00:05.00`, and an upstream bridge BDF is not the selected xHCI function.
- Validate the expected relationship between controller and USB root segment (`usb` plus digits) and descendants. A stored path merely sharing `/sys/devices` is not sufficient. Where the controller implementation supports a platform-child HCD form, use that explicit observed form; do not silently widen to arbitrary path descendants.
- The saved path determines historical policy scope even when the target no longer exists. A new device at the same BusID is never substituted for the old registration.
- A pending original selected-controller export remains a conflict until the existing Native reconciliation path resolves it. Do not call `gone()` or `owner_ended()` and retire it as a side effect of enrollment. A record under a different, well-formed saved PCI controller does not block this controller merely because it remains pending.
- If a controller object at the same canonical PCI address has been replaced, a saved path match is a conservative historical-scope conflict, not a claim that the old and new PCI generations are identical. The new controller receipt still needs its own actual generation checks.

For a legacy `Device.topology`, its concrete encoding is `devices/<controller components>/ports/<port chain>` (`physical_topology`, `rustusb-linux/src/lib.rs:475-490`). Parse the `ports` boundary exactly, reconstruct only the conceptual `/sys/devices/...` controller identity, and compare components. Never open the synthetic `/ports/` path. Keep an unknown topology as an explicit limitation. Because `ManagedState.exports` is helper-local, this only addresses that helper's actual legacy ownership; unknown external exports are still the Linux preflight's responsibility.

## Physical records: what can be resolved without changing the schema

`PhysicalDeviceReceipt` deliberately stores generation/node identities rather than a path. `journal::Baseline` stores no `Device.topology`. The fingerprint is a digest over vendor/product/serial/topology (`rustusb-linux/src/lib.rs:493` onwards); serial is not stored in the baseline, and there is no supported inverse mapping. The saved numeric bus alone is not a controller identity.

For an existing exact same-boot generation, a new bounded helper can recover the current original-controller scope without USB I/O:

1. Validate the already-loaded record and use only the fixed `/sys/bus/usb/devices/<validated original BusID>` entry. No supplied path is opened.
2. Check current boot against the record boot. Verify the current directory's filesystem device/inode against `baseline.receipt.sysfs_device/sysfs_inode`, and check `busnum` and `devnum` against the saved receipt.
3. Resolve the canonical sysfs device path and derive its parent USB-controller scope using the same strict topology rules as the Linux component. Prefer a retained directory FD with relative metadata reads and a before/after link-target identity check so a replacement cannot inherit the observation.
4. Recheck the exact sysfs directory identity, bus/address, and canonical path after obtaining scope. If anything changed, return unknown/retry-required with no controller mutation. This is a bounded observation under the cooperative helper mutation lock, not exclusion of an external host root or physical hotplug.
5. A matching current generation under the selected controller is a conflict. A matching current generation under another fully identified controller can be classified `OtherController` and need not block the selected controller.

The private `physical_lifecycle::generation_at` (`physical_lifecycle.rs:117-142`) already shows the saved sysfs dev/inode/bus/address comparisons. It could be factored or narrowly reused, but its Boolean result alone does not return a verified scope. Avoid reusing `observe_current_device` (`178-234`) for this purpose: it runs whole-device discovery, fingerprint lookup, eligibility checks, node identity checks, and full baseline observation. A deauthorized or intentionally reconfigured old grant is precisely when scope still matters; export eligibility or a recreated device node must not cause that owner to disappear from scope accounting.

Checking the USBFS node inode is not necessary to classify the controller of a still-matching USB generation. An old open FD can outlive unlink/recreation of its device node; a node mismatch should not make the matching original sysfs generation look unrelated.

### Missing, replaced, old-boot, and inaccessible generations

When exact generation recovery fails because the original object is gone or belongs to an earlier boot, the old disk schema cannot identify its historical controller. When metadata is inaccessible or races, even current scope is unknown. Neither condition is `OtherController`.

A precise result should distinguish:

- `SelectedControllerConflict` with an exact retained scope;
- `OtherController` with exact scope evidence;
- `UnknownHistoricalScope` because the old record never stored the missing controller;
- `UnknownObservation` because current metadata could not be verified.

For the conservative E68 requirement to reject outstanding selected-controller/potentially-selected owners without rewriting legacy schemas, unknown historical scope means enrollment cannot prove the absence of a conflicting old grant. Return a reconciliation-required result and retain all original records. This differs from rejecting whenever *any* known other-controller record exists: matching old/live records on another proven controller are excluded precisely.

If the product requirement instead insists that an unlocated old physical record must never block an unrelated controller, that cannot be proved from this old schema alone. The options are explicit existing administrator reconciliation of the original record, or an additional durable original-controller scope captured by future grants in a separate schema/sidecar. A transient in-memory scope cache helps only same-helper actual owners and does not repair preexisting crash-surviving records. Do not conceal this information gap with a current global scan or by classifying an empty scan as no owner.

The existing `physical_lifecycle::verify` and root `ReconcilePhysical` path can establish the defined original-generation-gone/restored criterion and retire the original record with its existing proof. Enrollment should not call that retirement implicitly. This preserves the user's separate lifecycle acknowledgment and avoids turning this metadata check into general USBFS FD revocation or media-release proof. A durable old record remaining unlocated is not proof it currently controls every PCI controller; it is insufficient evidence for precise exclusion.

## Required focused tests

All are proposed; this agent ran none.

- Native `bound == None`, target now unauthorized/generic, original selected-controller path: conflict.
- Native stub prepared/intent/observed, closing or failed actual registry entry: conflict through original registration scope.
- Native record under a different proven controller: no selected-controller conflict, even if its old BusID now appears beneath the selected controller.
- Empty Native export table with import `Prepared`/`Intent`/`Observed` entries and VHCI ports: no source-controller conflict solely from those imports.
- Durable export retired while actual registry still contains the live entry: conflict until actual registry removal; no reliance on store-empty alone.
- Legacy saved export topology selected/other/malformed, plus unrelated imports: classify selected/other/unknown; imports do not change it.
- Physical exact sysfs generation selected vs other controller: correct result without eligibility or current local-driver assumptions.
- Physical device node replaced while the same original sysfs generation remains: owner still maps to its original controller; no mistaken clearance from node identity drift.
- Physical old BusID reused by a new generation on another controller: never attribute the old grant from the replacement. Return unknown historical scope.
- Physical old boot, absent original generation, unreadable metadata, and before/after identity race: explicit unknown/reconciliation-required, no automatic retirement, no fixed-zero write before conflict resolution.
- Known-other Native and physical records coexist: selected controller remains available when every scope is precisely other and there are no selected/unknown owners. This is the regression against blanket all-controller blocking.
- Poisoned Native or physical store: unknown/error, never empty owner list. Missing opt-in physical support and no physical journal is different from an enabled but unreadable/poisoned journal.
- Concurrent export/grant preparation waits for or holds the same mutation guard. Controller preflight cannot run between its permission decision and durable/actual owner publication. The actual guard stays held through the controller operation.
- Keep legacy disk bytes/schemas and broker proof variants unchanged. Scope metadata is not a new cleanup proof or a storage admission capability.

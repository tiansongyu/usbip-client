# E68: root-only controller enrollment persistence

Status: implementation proposal and read-only review, not completed product behavior. The reviewed repository is clean commit `0c3dd04cce607e7255382b266ca120a85535c8d8`. This research ran no build, test, QEMU, USB, block, mount, module, process-control, or service command. It changed no repository file. Exact source snapshots, Git blob IDs, and SHA-256 hashes are in `manifest.json`.

This report answers the parent's proposed first product increment: an explicit helper `--controller-state-dir`, root-only `controller inspect/enroll/reconcile/retire/query`, at most 16 controller records, a strict 64 KiB private store, and an actual blocking worker that retains the common mutation mutex across preparation, sysfs work, and completion. The existing helper APIs should delegate to a new API with an optional administrator-selected controller-state path. No RPC accepts that path.

## Recommendation

Use an independent controller store and request/result types. Reuse the existing Native store's small protected-file primitives, the common helper mutation mutex, the real request task lifetime, and `application::RequestId`. Do not reinterpret a Native or USBFS resource record, cleanup proof, or application correlation as a controller enrollment.

The durable record expresses administrator intent. A completed mutation result describes a historical operation. A current controller receipt is valid only for the helper's current epoch and the exact current boot/PCI/HCD generation verified by the Linux component. None of these is a USB storage lease, USBFS revocation, local-driver restoration, or a permit to export media.

The E67 mechanism remains the prerequisite: boot/module `usbcore.authorized_default=0` protects new HCD generations, while every recreated HCD's interface default initially returns to 1 and must be explicitly set to 0 before authorizing a target. E67 is reused without another public-source download. The original E67 manifest and receipt are copied to `prior-e67/`.

## Existing APIs and their limits

| Existing source at the reviewed commit | Reuse | Do not infer or reuse |
| --- | --- | --- |
| `crates/rustusb-core/src/application.rs:8-60,80-83` | Canonical bounded lowercase UUID parser and `RequestId`; compare typed identity, not unchecked strings. | `RequestId` itself promises only a bounded deduplication window. It does not provide persistence, global uniqueness, authorization, or historical rejection of every reused UUID. |
| `application.rs:96-120,122-220` | Existing distinction between operation progress and actual cleanup evidence is a useful model. | `BrokerCorrelation`, `BrokerResourceKind`, `BrokerTerminal`, and `BrokerCleanupProof` are device-session capability contracts. Do not add a fake USBFS/native resource to represent controller policy. |
| `crates/rustusb-daemon/src/native_state.rs:132-258` | `validate_directory`, `open_directory`, `validate_file`, `identity_at`, and `open_file`, with narrowly scoped `pub(crate)` visibility. | These functions do not acquire a store lock, decide schema, perform a transaction, or enforce controller identities. They are not the `Store` lifecycle. |
| `native_state.rs:284-330,456-553` | Independent store constructor pattern; retained flock; final directory 0700 check; exact bytes/identity checks; write-temp/sync/rename/dir-sync/identity check; poisoned uncertain writer. | Native `Store`, `Record`, `Owner`, `owner_ended`, and `reconcile` have channel-specific meanings. A dead caller or prior boot does not retire administrator enrollment. |
| `crates/rustusb-daemon/src/journal.rs:293-327,512-641,659-813,974-1085` | Bounded-sequence decoding; conservative commit poisoning; immutable cache installation only after successful commit; capacity reserved for eventual terminal information. | The physical journal is gated by `physical-usb`, has disk schemas 1/2/3, and stores exact USBFS grants. Its schema and migration rules should stay unchanged. |
| `crates/rustusb-daemon/src/linux.rs:103-117,670-689` | `App.state: Arc<tokio::sync::Mutex<ManagedState>>`; move `OwnedMutexGuard` into the actual `spawn_blocking` closure. Existing `locked_recovery` demonstrates the ownership pattern. | The async function's continued existence alone is not the lock guarantee. The blocking closure must own the guard. Do not wrap accepted mutation work in an aborting timeout. |
| `linux.rs:967-1040,1436-1507` | Kernel `SO_PEERCRED`, dedicated request dispatch, bounded connection ownership, `JoinSet` and shutdown joining. | The outer socket gate permits root, configured brokers, and ordinary allowed users. Each new controller branch still needs an explicit `uid == 0` check before state access, queueing, or work. |
| `crates/rustusb-daemon/src/storage.rs:6-30,33-61` | Root-only dedicated dispatch and a permit moved into the actual blocking closure. | Read-only inspection is not an enrollment permit; its storage inspection slot is not a mutation coordinator. |
| `crates/rustusb-daemon/src/lib.rs:55-61,205-213,326-420,422-470,1031-1051` | Existing 64 KiB framing, strict wire mirror, sanitized response envelope, and compatible public serve wrappers. | New variants must be added to both `Request` and `RequestWire` plus conversion. Internally tagged unit variants need empty wire structs to reject extra fields. Error text is not a machine-readable durable decision. |
| `crates/rustusb-service/src/automation.rs:123-153` | Checked positive revision concept, excluding exhausted maximum before a revision advance. | Do not introduce a daemon-to-application-service dependency just to import `ExpectedRevision`. The daemon should own an equivalent small type or put an actually shared neutral type in core. |
| `crates/rustusb-service/src/rules.rs:68-84,114-124` | Exact retained request lookup and separate mutation construction are useful examples. | The rules table is profile/operator/job state, not a root controller ledger. Do not run a self-RPC as another UID or share its transaction schema. |

The exact line numbers above refer to copied source at `0c3dd04c`, not subsequent implementation work.

## Safe reuse of file helpers

The five Native helpers are reasonable narrow reuse points for this increment. They already use fd-relative traversal and opens, `O_NOFOLLOW`, fixed file identities, `O_EXCL` creation, regular-file checks, exact 0600, owner checks, and `nlink == 1`. A second generic persistence framework is unnecessary. Exposing these helpers does not require changing old Native store behavior or schemas.

The new controller store must still supply the following invariants itself:

1. The administrator gives one absolute path at helper startup. RPCs accept only typed controller selectors/IDs, never a directory, file name, command, or traversal component. Calls to reused `open_file`/`identity_at` use constants such as `lock`, `controllers.json`, and `.controllers.tmp`.
2. `open_directory` checks owner and absence of group/other write permission on ancestors. It does not impose final 0700; explicitly check final mode 0700, including on every health check. Protected 0755 ancestors remain acceptable. Keep the actual final directory FD for the store lifetime.
3. Retain one exclusively flocked 0600 lock file for the helper lifetime. Never delete or recreate it while another store may exist. An existing final directory missing its original lock or data file is an error, not a fresh empty installation. A second opener must fail without creating a second lock domain.
4. On each durable mutation, verify the retained lock inode, current data inode, exact expected bytes, file modes/owner/link counts, and directory mode. An in-place same-length rewrite must be detected. No decision may use an old healthy cache after an observation failure.
5. Parse at most 64 KiB plus one overflow byte before decoding. Reject unknown/duplicate fields, unknown enum tags and schema versions, invalid UUIDs/revisions/selectors, duplicate controller identity, duplicate retained request IDs, and array counts over 16 before growing an unbounded collection. Bound nested strings and HCD arrays as well.
6. Pre-encode and validate the proposed update before filesystem mutation. Remove only a valid fixed private stale temporary under the held lifetime lock. Write all bytes, sync temporary, rename into the fixed destination, sync directory, and verify destination identity. Install the new in-memory committed snapshot only after all required steps succeed.
7. After an uncertain filesystem write/rename/sync or failed health observation, poison the store. Do not make a compensating state write, report a settled rejection, initialize an empty table, or resume from the old cache. A controlled helper restart can reopen the actual file and expose its persisted state; an error in the old process is not proof that the old state stayed on disk.
8. Reserve the worst-case completion/result bytes before preparing intent or writing sysfs. Sixteen entries must not fill the file so completely that an already-executed operation cannot record its bounded outcome. The physical journal's explicit reserved-terminal budget at `journal.rs:1063-1068` is the relevant precedent. Test exact boundary sizes.

The helpers do not defend against an adversarial host root renaming privileged ancestor directories or changing kernel policy. The retained FD anchors the actual directory even if its pathname later changes. An RPC must not turn a pathname string into authority. Claiming that the original absolute path remains reachable forever would require extra policy; it is not supplied by these helpers.

A final health check is filesystem I/O and may itself block. `try_lock` avoids waiting for another thread but cannot make a successful lock followed by `read_bytes()` nonblocking.

## Minimal durable model and CAS contract

A minimal schema can contain a positive store-wide policy revision, at most 16 controller entries including retained retirement tombstones, and an explicitly bounded retained request result. A separate internal commit sequence is optional; if used, do not confuse it with the caller's policy CAS revision. Keep controller policy identity separate from canonical PCI selector and current HCD identities.

Suggested conceptual fields, not a required public API spelling:

- `schema_version`.
- `policy_revision`: strictly increasing, checked before advancing; never reset by controller retirement or re-enrollment.
- `controllers`: `policy_id`, normalized selector, desired state (`enrolled` or `retired`), and the revision at which intent changed. Any persisted last observation includes its original boot/helper/controller epoch and is explicitly historical.
- `last_mutation` or a bounded per-controller equivalent: exact request UUID, complete normalized payload including operation/selector/policy ID/expected revision, prepared revision, and `prepared`, `completed`, or `incomplete` result.

There are two distinct commits for an operation that writes sysfs. The first commits intent and the reserved request at a newly advanced policy revision. The second records the outcome for that same logical revision. Completion need not consume another public policy revision; changing an immutable result is not a new administrator mutation. A store-wide revision makes the minimal single-writer CAS contract simple and prevents ABA after record deletion or across different selectors. Per-controller revision is also possible, but then retirement tombstones and selector/policy-ID reuse need equally strict rules.

Validate root authorization and the syntactic request before looking up request history. Under the actual mutation guard, check retained replay first, then CAS:

- Same retained UUID and identical complete payload: return the original recorded result. Do not repeat sysfs writes, refresh its observation epoch, or replace its reported outcome with today's controller state. This order permits successful replay after the store revision has advanced.
- Same retained UUID but any different payload: reject identity reuse. Including expected revision in the comparison is essential.
- New UUID with wrong expected revision: reject before preparing intent or writing sysfs. No silent rebase, implicit retry, or partial CAS.
- New UUID and correct revision: reserve storage capacity, commit intent/request, and only then begin kernel changes.
- Exhausted revision or capacity: reject before side effects. A predictable validation/capacity error before any write should not poison an otherwise healthy store.
- Unknown durable result: return unconfirmed or a transport/storage error that requires querying the same original UUID. Do not label it a settled `Rejected`, manufacture `NotStarted`, or retry under a new UUID.

### Last-request retention is a real limitation

If only the last request globally or per controller is retained, explicitly document that one-entry replay window. An older query returns `Unknown`/`Expired`, not `NotStarted`. The old *original payload* remains safe against re-execution because it carries the old expected revision and the store revision never decreases. However, one retained entry cannot detect arbitrary reuse of a forgotten UUID with a newly supplied expected revision. Do not promise all-history UUID uniqueness.

If all historical UUID reuse must be rejected, use a separately bounded request/tombstone table without silent eviction and refuse new mutations at capacity, or specify an explicit generation/window protocol. That is more work than last-request semantics and should not be implied by the `RequestId` type.

Retirement must not erase the only revision/tombstone protecting a previously accepted enroll. Otherwise a delayed old enroll with an initial/absent revision can look new again. Keeping retired entries within the 16-entry limit is a conservative first increment; reaching the lifetime limit is explicit, not an invitation to delete the state directory.

## Blocking owner, query responsiveness, and shutdown

Use a dedicated controller dispatch branch before legacy `App::handle`. The generic handler's authorization and borrowed mutex path are not the intended new transaction contract. For a mutation:

1. Check `uid == 0`, feature opt-in, strict input, bounded admission, and stop state.
2. Acquire `app.state.clone().lock_owned()` with a queue-only timeout. A timeout before acquiring the guard proves only that this request started no mutation; it does not settle another pending request with the same UUID.
3. Move that owned guard, an actual-worker permit, and required store/runtime references into one blocking closure. The closure runs replay/CAS checks, the first durable commit, fixed-zero sysfs operations and postconditions, and final outcome commit. No asynchronous gap may drop the mutation guard while a filesystem or sysfs call continues.
4. Never timeout-and-abort the accepted closure. A soft interval may report that work remains in progress; it must neither return the worker slot nor unlock the mutation guard. A lost client cannot cause a second worker to enter.
5. Return structured mutation/query data through the existing response envelope. Do not rely on parsing `Response::failure` strings to decide whether a durable request completed.
6. On shutdown, stop accepting new work and join every accepted request and actual blocking worker. Preserve the existing `JoinSet` path. Do not add `abort_all`, a timeout that drops the only worker handle, rollback-to-1, or deletion of prepared intent. Permanent kernel/filesystem blocking remains an admitted limitation, not a completed cleanup.

The current helper retains its ordinary request task after the request has been parsed; client disconnection is only discovered when a later write fails. This is useful, but the actual blocking closure still owns the mutex/permit so correctness does not depend on a connected socket. The existing test `cancelling_recovery_wait_does_not_unlock_actual_blocking_work` at `linux.rs:1706` is the right ownership regression model. The storage observer's lost-waiter permit test is another relevant pattern.

### Query must not wait behind fsync

Holding the single `Store` mutex across `fsync` and then acquiring it for query will stall query. Moving query to `spawn_blocking` just moves the stall to another worker. Even a successful `try_lock` followed by `healthy()` can block in disk reads.

Use a separate immutable published view under a short in-memory lock, plus the writer's state (`idle`, `in_flight` with request identity, or `unconfirmed`). No sysfs or filesystem call occurs while holding this publication lock. The actual writer marks in-flight before an uncertain durable step and installs a new committed view only after that commit is known successful. On error it publishes unconfirmed without replacing the old committed history with an uncommitted candidate. Publish view and writer state together under that short lock to avoid torn combinations.

A root query can then return promptly:

- the exact retained historical committed result when present;
- that an exact request is in flight or prepared;
- unknown/expired when outside the retained window;
- unconfirmed current store health after uncertain I/O;
- separately, the last observed controller epoch and the fact it is not a live authorization.

A known historical result does not become false because a later write failed, but it must not be advertised as the current state of a poisoned store. If the simple DTO cannot represent both, return unconfirmed and withhold a fresh success response. This read view is metadata only; no mutation or target admission may rely on it instead of the actual store/current Linux checks. Current-disk integrity verification and fresh sysfs inspection are separate bounded actual workers and may block; label their scope instead of promising query checks them.

The first store open currently occurs before the listener and signal-handling loop in `linux::serve`. Adding a second startup store must not claim new cancellation guarantees for a permanently blocked initialization. Keep its actual blocking task owned and report this existing boundary.

## Restart, controller replacement, and retire

A new helper starts with no current armed receipt, even if the loaded file contains a historical successful arm and today's defaults happen to be zero. The persisted result still answers the old request, but current status is `reconcile_required` until a fresh operation verifies boot policy, root/PCI/HCD identities, expected topology, and both defaults.

After a crash, a prepared request means execution may have started. Do not replay its sysfs action merely because its outcome is absent. A root `reconcile` with a new UUID and current CAS can perform the explicitly authorized fixed-zero re-arm under the same real mutation owner. It must first obtain a healthy reopened store and current kernel evidence. It does not adopt an old target, resurrect an old storage lease, infer writes were flushed, or turn a missing outcome into `NotStarted`.

For the first product increment, explicit reconcile is sufficient and easier to audit than automatic startup writes. If automatic reconcile is added later, its loaded policy authorization, actual-worker lifetime, fresh receipts, and failure reporting must be specified separately; a background loop is not implied by persisted enrollment intent.

A recreated HCD can share the same PCI object and BDF while having new USB buses and defaults. A reboot changes the boot identity; a new helper changes its runtime epoch; target removal/reinsertion changes a further identity. Every corresponding live receipt is invalidated independently. Neither bus number nor PCI path alone is a generation receipt. Reconcile is permitted to reuse the administrator's selected-controller intent, not an old live handle.

Retire means: commit that no further re-arm/admission may be performed under this enrollment, invalidate any current in-memory controller receipt, and retain the revision/replay tombstone. It does not write any default or target authorization to 1, disconnect a live device, unbind a controller, release USBFS descriptors, restore a driver, or emit a `BrokerCleanupProof`. The existing defaults may remain zero after retirement. Releasing a device for local use is a separate later operation.

If a future version can have storage leases beneath a controller, retirement must either reject while exact active/unresolved dependents exist or become a two-stage `retiring` state which blocks new work and waits for the original owners. It cannot erase those owners. For E68 with no storage-transfer admission implemented, state that dependency set is absent by construction, rather than pretend a generic resource count proves release.

Omitting `--controller-state-dir` disables this feature. It does not retire previously persisted intent, undo boot policy, or restore local devices. Invalid existing state is not replaced by an empty store. Root startup configuration must preserve the opt-in across deployment changes when continued management is intended.

## Proposed API shape

The names below express contracts, not a demand to create a generic framework:

- `inspect_controller(selector)`: root-only current bounded metadata from Linux, no persistence mutation and no permission to export.
- `enroll_controller(request_id, expected_revision, selector)`: first durable intent, then actual fixed-zero arm and observed outcome. Fresh receipt is helper-issued, never supplied by the caller.
- `reconcile_controller(request_id, expected_revision, policy_id)`: fresh generation checks and fixed-zero re-arm of an existing active intent. No old-target/session adoption.
- `retire_controller(request_id, expected_revision, policy_id)`: durable intent retirement and current receipt invalidation, no enabling writes.
- `query_controller_request(request_id)`: metadata-only retained history/in-flight/unconfirmed/unknown result, with explicit retention limits.
- `controller_status`: enrolled/retired intent and last observation with original epoch, clearly distinguished from current verification.

An additive public helper API can take `Option<&Path>` for startup, while current `serve_with_state` and older wrappers pass `None`. Default and all-features builds should expose the root-only controller policy capability on Linux independently of the experimental `physical-usb` USBFS adapter. Non-Linux paths return the existing explicit unsupported result. Existing legacy, Native, broker, storage inspection, public wire schemas, and root proof formats keep their meanings.

## Minimum test matrix for implementation

These are recommended tests, not tests executed by this research agent.

| Area | Cases and required observation |
| --- | --- |
| Strict wire | Every new op rejects extra/duplicate/missing fields; canonical UUID and selector; forbidden arbitrary path; exact numeric revision bounds; malformed query; frame bound. Test both `RequestWire` and public conversion. |
| Root authorization | UID 0 succeeds through the dedicated branch; configured ordinary allowed UID and configured secure broker UID both fail before worker/store/kernel callbacks. Counter remains zero. Socket root peer verification remains unchanged. |
| Opt-in | Old public serve wrapper and missing option create no controller state. Explicit option creates only new private state. Existing malformed/missing-lock/missing-data state fails closed. Linux default build and all-features build both preserve original behavior. |
| Protected storage | Wrong owner/mode, writable ancestor, symlink at each relevant component, hardlinks, nonregular node, same-size rewrite, replaced/removed lock, second opener, invalid temporary, missing existing data, unknown schema, duplicate records, bounded nested allocation, 16-entry and 64 KiB limits. |
| Commit outcomes | Fault before first rename, after rename/before directory sync, before final completion rename, and after completion rename; old cache is not installed as new, store becomes unconfirmed, new writes stop. Reopen reads whichever actual complete record exists; no implicit authorization on reopen. Include exact byte reservations for completion. |
| Replay/CAS | Same UUID/same payload returns the original result with zero kernel writes; same UUID/different op, selector, ID, or expected revision rejects; new UUID/stale CAS rejects; revision overflow rejects; two concurrent requests with same expected revision admit at most one. |
| Retention | Query last request succeeds; after a later mutation old query is explicitly unknown/expired; replay original forgotten payload is CAS-rejected; retired tombstone cannot reset revision or permit old enroll replay; no claim that forgotten UUID with altered payload is detected unless a retained history actually provides it. |
| Worker cancellation | Gate the actual closure before persistence, inside simulated sync, before/after each sysfs write, and before final commit. Drop the client/waiter and send helper stop; the same actual mutex/permit remains held until the closure truly exits. A second mutation cannot pass it. Query remains responsive and reports in-flight/unconfirmed, without claiming complete state. |
| Publication | During a gated first commit, candidate is not reported committed. During final commit, current receipt is not advertised as valid before the required durability boundary. On poison, current success is withheld; historical result retains its epoch and scope. No read lock is held across I/O. |
| Partial arm | Failure after one HCD/default write preserves the durable intent, records incomplete/uncertain result if possible, publishes no completed current receipt, and never writes 1 to compensate. New generation during pre/post checks is rejected without adopting replacement. |
| Restart | Reopen a successful historical result in a new helper epoch: original request replay remains historical, current receipt invalid. Reopen a prepared operation: unknown execution, no automatic repeat. Explicit new reconcile can create a fresh receipt only after current source checks. |
| Retirement | Retire waits behind the actual mutation owner, changes only desired intent, clears current runtime receipt, retains replay/CAS state, and performs zero enabling/USB/PCI writes. Existing future dependent session receipt must not be erased. |
| QEMU product integration | Each Ubuntu kernel: ordinary nonroot denied; boot policy mismatch denied; real product enroll under boot deny; helper restart with stale historical receipt; explicit product reconcile; HCD rebind then stale receipt rejection/fresh reconcile; real reboot with current receipt invalid; retire leaves defaults denied; original E66 data fixture remains separately labeled if it uses stock tools. Preserve positive-default-1 control and exact current identities. |
| Regression | Original full required software gates, old Native/USBFS journal formats and recovery, signal/backpressure/actual cleanup ownership, and appropriate prior Native storage-mechanism regression. Do not count unrelated old evidence as new product coverage. |

E68 enrollment alone still does not implement safe U-disk forwarding: early USBFS access/delegation history and in-flight open/control races, target admission, checked all-LUN data/flush/release, existing media-use handoff, and fault recovery remain separate original requirements. The E67 source and QEMU evidence support the prerequisite, not completion of those requirements.

use super::*;
use std::os::unix::fs::{PermissionsExt,symlink};

struct Fixture { _temp:tempfile::TempDir, sys:PathBuf, proc:PathBuf, pci:PathBuf, uid:u32 }
impl Fixture {
    fn new()->Result<Self>{
        let temp=tempfile::tempdir()?;let sys=temp.path().join("sys");let proc=temp.path().join("proc");
        let pci=sys.join("devices/pci0000:00/0000:00:06.0");
        for p in [&pci,&sys.join("bus/pci/devices"),&sys.join("bus/pci/drivers/xhci_hcd"),&sys.join("bus/usb/devices"),&sys.join("bus/usb/drivers/usb"),&sys.join("module/usbcore/parameters"),&proc.join("sys/kernel/random")]{fs::create_dir_all(p)?;}
        symlink(&pci,sys.join("bus/pci/devices/0000:00:06.0"))?;symlink(sys.join("bus/pci/drivers/xhci_hcd"),pci.join("driver"))?;
        for (n,v) in [("vendor","0x1234"),("device","0x000d"),("subsystem_vendor","0x1af4"),("subsystem_device","0x1100"),("class","0x0c0330")]{fs::write(pci.join(n),format!("{v}\n"))?;}
        fs::write(proc.join("cmdline"),"root=/dev/vda1 usbcore.authorized_default=0 console=ttyS0\n")?;
        fs::write(proc.join("sys/kernel/random/boot_id"),"11111111-2222-3333-4444-555555555555\n")?;
        fs::write(sys.join("module/usbcore/parameters/authorized_default"),"0\n")?;
        for (bus,speed) in [(1,10000),(2,480)]{
            let root=pci.join(format!("usb{bus}"));fs::create_dir(&root)?;symlink(&root,sys.join(format!("bus/usb/devices/usb{bus}")))?;
            for (n,v) in [("busnum",bus.to_string()),("devnum","1".into()),("devpath","0".into()),("bDeviceClass","09".into()),("authorized","1".into()),("speed",speed.to_string()),("authorized_default","0".into()),("interface_authorized_default","1".into())]{fs::write(root.join(n),v+"\n")?;}
            fs::create_dir(root.join(format!("{bus}-0:1.0")))?;
        }
        let uid=fs::metadata(&sys)?.uid();Ok(Self{_temp:temp,sys,proc,pci,uid})
    }
    fn open(&self)->Result<PinnedController>{Environment::open(&self.sys,&self.proc,self.uid,false)?.pin(&PciAddress::new("0000:00:06.0")?)}
    fn arrival(&self)->Result<PathBuf>{
        let p=self.pci.join("usb2/2-1");fs::create_dir(&p)?;symlink(&p,self.sys.join("bus/usb/devices/2-1"))?;symlink(self.sys.join("bus/usb/drivers/usb"),p.join("driver"))?;
        for(n,v) in [("authorized","0\n"),("bDeviceClass","00\n"),("bConfigurationValue","\n")]{fs::write(p.join(n),v)?;}Ok(p)
    }
}
#[test]
fn strict_addresses_and_boot_parameter_scope()->Result<()>{
    for s in ["0000:00:00.0","ffff:ff:1f.7"]{PciAddress::new(s)?;}
    for s in ["0000:00:20.0","0000:00:06.8","0000:00:0A.0","../0000:00:06.0","0000:00:6.0","0000:00:06.0/","é000:00:06.0"]{assert!(PciAddress::new(s).is_err(),"{s}");}
    assert!(boot_default("a=b usbcore.authorized_default=0 -- usbcore.authorized_default=1")?);
    assert!(!boot_default("a=b -- usbcore.authorized_default=0")?);
    assert!(!boot_default("root=/dev/vda1")?);
    for s in ["usbcore.authorized_default=0 usbcore.authorized_default=0","usbcore.authorized-default=0","usbcore.authorized_default=00","usbcore.authorized_default=1","usbcore.authorized_default","usbcore.authorized_default=\"0\"","root='foo' usbcore.authorized_default=0","usbcore.authorized_default=0\t", "usbcore.authorized_default=0\\"]{assert!(boot_default(s).is_err(),"{s}");}Ok(())
}
#[test]
fn actual_two_root_writes_and_retained_readback()->Result<()>{
    let f=Fixture::new()?;f.arrival()?;let mut pin=f.open()?;let before=pin.inspect()?;
    assert_eq!(before.roots.iter().map(|r|r.speed).collect::<Vec<_>>(),vec![10000,480]);
    pin.prepare(&before.selector,&before.boot_id)?;let after=pin.arm()?;
    assert_eq!(after.arrivals,before.arrivals);assert!(after.roots.iter().all(|r|r.device_default==0&&r.interface_default==0));
    assert_eq!(fs::read(f.pci.join("usb2/2-1/authorized"))?,b"0\n");
    assert_eq!(pin.inspect()?,after);Ok(())
}
#[test]
fn boot_drift_and_selection_errors_precede_writes()->Result<()>{
    for field in ["boot","global","default","selector","epoch"]{
        let f=Fixture::new()?;let mut pin=f.open()?;let mut s=pin.inspect()?;
        match field {
            "boot"=>fs::write(f.proc.join("cmdline"),"root=/dev/vda1\n")?,
            "global"=>fs::write(f.sys.join("module/usbcore/parameters/authorized_default"),"1\n")?,
            "default"=>fs::write(f.pci.join("usb1/authorized_default"),"1\n")?,
            "selector"=>s.selector.vendor_id^=1,
            _=>s.boot_id="00000000-0000-0000-0000-000000000000".into(),
        }
        assert!(pin.prepare(&s.selector,&s.boot_id).is_err(),"{field}");
        assert_eq!(fs::read(f.pci.join("usb1/interface_authorized_default"))?,b"1\n");
    }Ok(())
}
#[test]
fn rejects_incomplete_extra_replaced_and_unsafe_topologies()->Result<()>{
    for cause in ["missing","extra","root_replaced","attribute_replaced","authorized","hub","configured","interface","descendant","non_generic","permissions","symlink"]{
        let f=Fixture::new()?;let target=f.arrival()?;let mut pin=f.open()?;let s=pin.inspect()?;pin.prepare(&s.selector,&s.boot_id)?;
        match cause{
            "missing"=>fs::rename(f.pci.join("usb1"),f.pci.join("old-root"))?,
            "extra"=>fs::create_dir(f.pci.join("usb3"))?,
            "root_replaced"=>{fs::rename(f.pci.join("usb1"),f.pci.join("old-root"))?;fs::create_dir(f.pci.join("usb1"))?;},
            "attribute_replaced"=>{fs::rename(f.pci.join("usb1/interface_authorized_default"),f.pci.join("old-attr"))?;fs::write(f.pci.join("usb1/interface_authorized_default"),"1\n")?;},
            "authorized"=>fs::write(target.join("authorized"),"1\n")?,
            "hub"=>fs::write(target.join("bDeviceClass"),"09\n")?,
            "configured"=>fs::write(target.join("bConfigurationValue"),"1\n")?,
            "interface"=>fs::create_dir(target.join("2-1:1.0"))?,
            "descendant"=>fs::create_dir(target.join("unexpected"))?,
            "non_generic"=>{fs::remove_file(target.join("driver"))?;symlink(&f.pci,target.join("driver"))?;},
            "permissions"=>fs::set_permissions(f.pci.join("usb1/interface_authorized_default"),fs::Permissions::from_mode(0o666))?,
            _=>{fs::remove_file(f.pci.join("usb1/interface_authorized_default"))?;symlink(f.pci.join("usb2/interface_authorized_default"),f.pci.join("usb1/interface_authorized_default"))?;},
        }
        assert!(pin.arm().is_err(),"{cause}");assert_eq!(fs::read(f.pci.join("usb2/interface_authorized_default"))?,b"1\n","{cause}");
    }Ok(())
}
#[test]
fn short_store_is_not_retried(){
    struct Short(usize);impl Write for Short {fn write(&mut self,_:&[u8])->std::io::Result<usize>{self.0+=1;Ok(1)}fn flush(&mut self)->std::io::Result<()>{Ok(())}}
    let mut s=Short(0);assert!(write_zero(&mut s).is_err());assert_eq!(s.0,1);
}

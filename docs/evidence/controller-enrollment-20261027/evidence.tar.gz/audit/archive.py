import gzip,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
ROOT=Path('/home/ubuntu/github/usbip-client');OUT=ROOT/'docs/evidence/controller-enrollment-20261027';OUT.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();members={};payload={};excluded=[]
def add(name,data,origin):
 assert name not in members
 assert not data.startswith(b'\x7fELF'),name
 assert not re.search(rb'(?m)^-----BEGIN OPENSSH PRIVATE KEY-----\r?$',data),name
 members[name]={'bytes':len(data),'sha256':sha(data),'origin':origin};payload[name]=data
folders={
 'development':'/tmp/rustusb-controller-enrollment-development-20261026',
 'software/first':'/tmp/rustusb-controller-enrollment-software-20261026',
 'software/final':'/tmp/rustusb-controller-enrollment-software-final-20261026',
 'research/store':'/tmp/rustusb-controller-enrollment-store-20261026',
 'research/kernel':'/tmp/rustusb-controller-enrollment-linux-20261026',
 'audit':'/tmp/rustusb-controller-enrollment-audit-20261027',
 'qemu/jammy':'/tmp/rustusb-controller-enrollment-jammy-20261026',
 'qemu/noble':'/tmp/rustusb-controller-enrollment-noble-20261026',
}
for prefix,folder in folders.items():
 base=Path(folder)
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base)
  if '.private' in rel.parts or '__pycache__' in rel.parts:continue
  if p.is_symlink():excluded.append({'path':str(p),'reason':'symlink not followed'});continue
  if not p.is_file():continue
  add(prefix+'/'+rel.as_posix(),p.read_bytes(),str(p))
for release in ['jammy','noble']:
 p=Path('/tmp/rustusb-controller-enrollment-'+release+'-20261026.host.log');add('qemu/'+release+'/host.log',p.read_bytes(),str(p))
head='26faa7903fabb0720b5be778271f045a45181658'
files=subprocess.check_output(['git','diff','--name-only','0c3dd04c',head],cwd=ROOT,text=True).splitlines()
files+=['scripts/qemu_installed_usb/vm.py','scripts/qemu_storage_arrival/guest.py','scripts/qemu/run-physical-qemu.py','scripts/check.sh','scripts/check-gui.sh','Cargo.toml','Cargo.lock']
for n in sorted(set(files)):
 data=subprocess.check_output(['git','show',head+':'+n],cwd=ROOT);add('tested-source/'+n,data,'git:'+head+':'+n)
add('exclusions.json',(json.dumps({'omitted':'all .private trees, pycache, private keys, disk/backing images and ELF uploads; none are acceptance evidence payloads','symlinks':excluded},indent=2)+'\n').encode(),'archive method')
archive=OUT/'evidence.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for n,data in sorted(payload.items()):
    info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as tar:
 assert len(tar.getmembers())==len(members)
 for m in tar.getmembers():
  data=tar.extractfile(m).read();assert len(data)==members[m.name]['bytes'] and sha(data)==members[m.name]['sha256']
manifest={'scope':'E68 actual product controller enrollment; two passing QEMU pairings, eight normal QEMU exits; 1211 final software executions; development failures and source reviews retained','archive':'evidence.tar.gz','sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'raw_member_bytes':sum(x['bytes'] for x in members.values()),'members':members}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v if k!='members' else len(v) for k,v in manifest.items()},indent=2))

import hashlib,json,re,subprocess,tarfile
from pathlib import Path
ROOT=Path('/home/ubuntu/github/usbip-client');OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def git_bytes(head,path):return subprocess.check_output(['git','show',head+':'+path],cwd=ROOT)
result={'method':'same-author raw-record and Git-input audit; does not import fixture runners or execute USB','software':{},'runs':{},'passed':False}
for label,folder in [('first','software'),('final','software-final')]:
 d=Path('/tmp/rustusb-controller-enrollment-'+folder+'-20261026');s=json.loads((d/'summary.json').read_text());assert s['passed'] and all(s['guards'].values())
 for n,item in s['inputs'].items():b=git_bytes(s['head'],n);assert len(b)==item['bytes'] and sha(b)==item['sha256'],n
 counts={}
 for kind in ['core','gui']:
  text=(d/(kind+'.log')).read_text();rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',text);assert rows and all(int(r[1])==int(r[2])==0 for r in rows)
  counts[kind]=sum(int(r[0]) for r in rows)
 result['software'][label]={'head':s['head'],'inputs':len(s['inputs']),'counts':counts,'commands':s['commands']}
for release in ['jammy','noble']:
 d=Path('/tmp/rustusb-controller-enrollment-'+release+'-20261026');r=json.loads((d/'result.json').read_text());p=json.loads((d/'provenance.json').read_text());o=json.loads((d/'observations.json').read_text());assert r['passed'] and all(r['guards'].values()) and r['kernel_integrity'] and r['readonly_backing_unchanged']
 assert len(r['actual_qemu_exits'])==4 and all(x['exit']==0 for x in r['actual_qemu_exits']);assert r['server_collection_exit']==r['client_collection_exit']==0
 assert r['head']==p['head']==result['software']['final']['head']
 for n,h in p['inputs'].items():assert sha(git_bytes(p['head'],n))==h,n
 frozen=p['frozen'];cli_hash=frozen[str(ROOT/'target/release/rustusb')];helper_hash=frozen[str(ROOT/'target/release/rustusb-helper')]
 boots=[o['server-setup-server-boot'+str(i)]['boot_id'] for i in [1,2,3]];assert len(set(boots))==3
 enrollment=o['server-enroll-boot2'];old=enrollment['result']['record'];assert old['revision']==1 and old['outcome']['state']=='armed';assert enrollment['query']['retained_historical_result']==old
 assert enrollment['before']['generation']==enrollment['after']['generation'];assert enrollment['after']['authorized']=='0' and enrollment['after']['blocks']==[]
 restart=o['server-restart-state-boot2'];assert restart['verified_in_this_helper']==[] and restart['helper_epoch']!=enrollment['view']['helper_epoch']
 for key,revision in [('same-boot-1-boot2',2),('new-hcd-2-boot2',3),('new-boot-3-boot3',4)]:
  s=o['server-reconcile-'+key];record=s['result']['record'];assert record['revision']==revision and record['outcome']['state']=='armed';assert s['device']['blocks']==[] and s['device']['authorized']=='0'
  assert all(x['device_default']==x['interface_default']==0 for x in record['outcome']['verification']['roots'])
 recreated=o['server-recreate-boot2'];assert recreated['before']['generation']!=recreated['after']['generation'];assert {tuple(x['identity']) for x in recreated['old_roots'].values()}.isdisjoint({tuple(x['identity']) for x in recreated['new_roots'].values()})
 history=o['server-restart-state-boot3'];assert history['verified_in_this_helper']==[] and history['historical']['records'][0]['outcome']['verification']['boot_id']==boots[1]
 retired=o['server-retire-boot3'];assert retired['view']['historical']['revision']==5 and retired['result']['record']['retired'];assert all(x['authorized_default']==x['interface_authorized_default']=='0' for x in retired['roots'].values())
 io=next(v for k,v in o.items() if k.startswith('client-stock-io-'));assert io['read_bytes']==1048576 and io['sha256']==sha(bytes(1048576)) and io['sg_sync_exit']==0
 assert len(io['state']['blocks'])==1 and io['state']['blocks'][0]['ro']=='1';assert o['client-stock-detach-boot3']['target_gone']
 members={};cli=[];child_exits=[]
 for role in ['server','client']:
  with tarfile.open(d/(role+'-evidence.tar')) as t:
   for m in t.getmembers():
    assert m.isdir() or m.isfile(),m.name
    if m.isdir():continue
    path=Path(m.name);assert not path.is_absolute() and '..' not in path.parts
    b=t.extractfile(m).read();members[role+'/'+m.name]={'bytes':len(b),'sha256':sha(b)}
    if path.name.startswith('commands-') and path.suffix=='.json':
     for c in json.loads(b):
      if c['argv'][0]=='/opt/rustusb-e68/rustusb' or (c['argv'][:4]==['runuser','-u','nobody','--'] and c['argv'][4]=='/opt/rustusb-e68/rustusb'):
       assert c['executable_file_sha256']==cli_hash and c['pid']>0 and c['exit'] in (0,1);cli.append(c)
    if path.name.endswith('-exit.json'):
     e=json.loads(b);child_exits.append({'file':role+'/'+m.name,'exit':e['exit'],'pid':e['identity']['pid']})
     if path.name.startswith('helper-'):assert e['exit']==0 and e['identity']['exe_sha256']==helper_hash
    if path.name=='actual-controller-history.json':assert json.loads(b)==retired['view']['historical']
 assert len(child_exits)==5 and len([c for c in cli if c['exit']==1])==6
 assert any(c['argv'][0]=='runuser' and c['exit']==1 for c in cli)
 assert len([c for c in child_exits if 'helper-' in c['file']])==4
 result['runs'][release]={'head':r['head'],'inputs':len(p['inputs']),'qemu':r['actual_qemu_exits'],'boot_ids':boots,'child_exits':child_exits,'cli_waits':len(cli),'cli_denials':sum(c['exit']==1 for c in cli),'guest_members':members,'io_bytes':io['read_bytes'],'io_sha256':io['sha256'],'helper_sha256':helper_hash,'cli_sha256':cli_hash}
result['passed']=True;(OUT/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v if k!='runs' else {n:{a:b for a,b in row.items() if a!='guest_members'} for n,row in v.items()} for k,v in result.items()},indent=2))

import hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path('/home/ubuntu/github/usbip-client');OUT=Path(__file__).resolve().parent

def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def inputs():
    names=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
    return {n:{'bytes':(ROOT/n).stat().st_size,'sha256':hashlib.sha256((ROOT/n).read_bytes()).hexdigest()} for n in names if n and not n.startswith('docs/evidence/')}
def save(d): (OUT/'summary.json').write_text(json.dumps(d,indent=2)+'\n')
assert not git('status','--porcelain')
result={'head':git('rev-parse','HEAD'),'inputs':inputs(),'commands':[],'passed':False};save(result)
for name,command in [('core',['bash','scripts/check.sh']),('gui',['bash','scripts/check-gui.sh'])]:
    start=time.monotonic()
    with (OUT/(name+'.log')).open('wb') as log:p=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    result['commands'].append({'command':command,'exit':p.returncode,'seconds':time.monotonic()-start});save(result)
    print(name+': actual exit '+str(p.returncode),flush=True)
    if p.returncode:break
result['guards']={'head':git('rev-parse','HEAD')==result['head'],'clean':not git('status','--porcelain'),'inputs':inputs()==result['inputs']}
result['passed']=len(result['commands'])==2 and all(r['exit']==0 for r in result['commands']) and all(result['guards'].values());save(result)
print(json.dumps({k:v for k,v in result.items() if k!='inputs'}),flush=True)
raise SystemExit(0 if result['passed'] else 1)
